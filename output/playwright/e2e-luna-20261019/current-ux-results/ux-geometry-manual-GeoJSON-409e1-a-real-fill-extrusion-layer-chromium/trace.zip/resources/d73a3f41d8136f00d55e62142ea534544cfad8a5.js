import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/RiskMap.svelte");import "/node_modules/.vite/deps/svelte_internal_disclose-version.js?v=f498b382";

RiskMap[$.FILENAME] = 'src/components/RiskMap.svelte';

import * as $ from "/node_modules/.vite/deps/svelte_internal_client.js?v=f498b382";
import { onMount } from "/node_modules/.vite/deps/svelte.js?v=f498b382";
import { zoneLabel } from "/src/lib/scoring.ts";

import {
	hasCoordinates,
	summarizeMap,
	buildingShapes,
	worldPoint,
	worldCoordinates,
	relatedMapPlaces,
	UNKNOWN_COLOR
} from "/src/lib/map-model.ts";

import "/node_modules/maplibre-gl/dist/maplibre-gl.css";

var root = $.add_locations($.from_html(`<button class="s-QEJqXNvtCF_z"> </button>`), RiskMap[$.FILENAME], [[190, 95]]);
var root_1 = $.add_locations($.from_html(`<img class="tile s-QEJqXNvtCF_z" alt="" width="256" height="256" draggable="false"/>`), RiskMap[$.FILENAME], [[194, 40]]);
var root_2 = $.add_locations($.from_html(`<button class="fallback-point s-QEJqXNvtCF_z"></button>`), RiskMap[$.FILENAME], [[195, 50]]);

var root_3 = $.add_locations($.from_html(`<div class="fallback-map s-QEJqXNvtCF_z" aria-label="Двумерная карта без WebGL"><!> <!> <nav class="fallback-controls s-QEJqXNvtCF_z" aria-label="Перемещение карты"><button aria-label="Приблизить" class="s-QEJqXNvtCF_z">+</button><button aria-label="Отдалить" class="s-QEJqXNvtCF_z">−</button><button aria-label="На север" class="s-QEJqXNvtCF_z">↑</button><button aria-label="На запад" class="s-QEJqXNvtCF_z">←</button><button aria-label="На восток" class="s-QEJqXNvtCF_z">→</button><button aria-label="На юг" class="s-QEJqXNvtCF_z">↓</button></nav> <a class="attribution s-QEJqXNvtCF_z" href="https://www.openstreetmap.org/copyright" target="_blank" rel="noreferrer">© OpenStreetMap contributors</a></div>`), RiskMap[$.FILENAME], [
	[
		193,
		6,
		[
			[
				196,
				8,
				[
					[196, 70],
					[196, 142],
					[196, 213],
					[196, 282],
					[196, 351],
					[196, 420]
				]
			],
			[197, 8]
		]
	]
]);

var root_4 = $.add_locations($.from_html(`<p class="map-status s-QEJqXNvtCF_z" role="status">Загрузка карты…</p>`), RiskMap[$.FILENAME], [[200, 30]]);
var root_5 = $.add_locations($.from_html(`<p class="map-status s-QEJqXNvtCF_z" role="status"> </p>`), RiskMap[$.FILENAME], [[201, 17]]);

var root_6 = $.add_locations($.from_html(`<div class="preview-model s-QEJqXNvtCF_z"><strong class="s-QEJqXNvtCF_z"> </strong> <dl class="s-QEJqXNvtCF_z"><div class="s-QEJqXNvtCF_z"><dt class="s-QEJqXNvtCF_z">Высота</dt><dd class="s-QEJqXNvtCF_z"> </dd></div> <div class="s-QEJqXNvtCF_z"><dt class="s-QEJqXNvtCF_z">Контур</dt><dd class="s-QEJqXNvtCF_z"> </dd></div> <div class="s-QEJqXNvtCF_z"><dt class="s-QEJqXNvtCF_z">Источник</dt><dd class="s-QEJqXNvtCF_z"> </dd></div></dl> <button class="text-button s-QEJqXNvtCF_z">Смотреть прогресс в хронологии →</button></div>`), RiskMap[$.FILENAME], [
	[
		217,
		8,
		[
			[218, 10],
			[
				219,
				10,
				[
					[220, 12, [[220, 17], [220, 32]]],
					[221, 12, [[221, 17], [221, 32]]],
					[222, 12, [[222, 17], [222, 34]]]
				]
			],
			[224, 10]
		]
	]
]);

var root_7 = $.add_locations($.from_html(`<p class="preview-meta s-QEJqXNvtCF_z"> </p>`), RiskMap[$.FILENAME], [[227, 145]]);
var root_8 = $.add_locations($.from_html(`<button class="text-button s-QEJqXNvtCF_z">Открыть хронологию →</button>`), RiskMap[$.FILENAME], [[229, 38]]);
var root_9 = $.add_locations($.from_html(`<button class="text-button s-QEJqXNvtCF_z">Открыть публикации →</button>`), RiskMap[$.FILENAME], [[230, 37]]);
var root_10 = $.add_locations($.from_html(`<p class="preview-meta s-QEJqXNvtCF_z"> </p>`), RiskMap[$.FILENAME], [[231, 24]]);

var root_11 = $.add_locations($.from_html(`<aside class="map-preview s-QEJqXNvtCF_z" aria-label="Предпросмотр ЖК"><div class="preview-top s-QEJqXNvtCF_z"><span class="preview-eyebrow s-QEJqXNvtCF_z"> </span><button class="close-preview s-QEJqXNvtCF_z" aria-label="Закрыть предпросмотр">×</button></div> <h3 class="s-QEJqXNvtCF_z"> </h3> <p class="preview-sub s-QEJqXNvtCF_z"> </p> <div class="preview-score s-QEJqXNvtCF_z"><strong class="s-QEJqXNvtCF_z"> </strong><span class="s-QEJqXNvtCF_z"> </span></div> <dl class="preview-facts s-QEJqXNvtCF_z"><div class="s-QEJqXNvtCF_z"><dt class="s-QEJqXNvtCF_z">Застройщик</dt><dd class="s-QEJqXNvtCF_z"> </dd></div> <div class="s-QEJqXNvtCF_z"><dt class="s-QEJqXNvtCF_z">БИН</dt><dd class="s-QEJqXNvtCF_z"> </dd></div> <div class="s-QEJqXNvtCF_z"><dt class="s-QEJqXNvtCF_z">Источник</dt><dd class="s-QEJqXNvtCF_z"> </dd></div> <div class="s-QEJqXNvtCF_z"><dt class="s-QEJqXNvtCF_z">Проверено</dt><dd class="s-QEJqXNvtCF_z"> </dd></div> <div class="s-QEJqXNvtCF_z"><dt class="s-QEJqXNvtCF_z">Публикации</dt><dd class="s-QEJqXNvtCF_z"> </dd></div></dl> <p class="key-fact s-QEJqXNvtCF_z"><span class="legend-dot s-QEJqXNvtCF_z"></span> </p> <!> <!> <div class="preview-actions s-QEJqXNvtCF_z"><button class="s-QEJqXNvtCF_z">Открыть досье</button><button class="secondary s-QEJqXNvtCF_z">Показать связи</button></div> <!> <!> <!></aside>`), RiskMap[$.FILENAME], [
	[
		203,
		6,
		[
			[204, 8, [[204, 33], [204, 165]]],
			[205, 8],
			[206, 8],
			[207, 8, [[207, 76], [207, 109]]],
			[
				208,
				8,
				[
					[209, 10, [[209, 15], [209, 34]]],
					[210, 10, [[210, 15], [210, 27]]],
					[211, 10, [[211, 15], [211, 32]]],
					[212, 10, [[212, 15], [212, 33]]],
					[213, 10, [[213, 15], [213, 34]]]
				]
			],
			[215, 8, [[215, 28]]],
			[228, 8, [[228, 37], [228, 90]]]
		]
	]
]);

var root_12 = $.add_locations($.from_html(`<button><span class="s-QEJqXNvtCF_z"> </span><small class="s-QEJqXNvtCF_z"> </small></button>`), RiskMap[$.FILENAME], [[237, 68, [[237, 144], [237, 168]]]]);
var root_13 = $.add_locations($.from_html(`<p class="s-QEJqXNvtCF_z">Объектов по выбранным условиям нет.</p>`), RiskMap[$.FILENAME], [[237, 211]]);
var root_14 = $.add_locations($.from_html(`<aside class="map-list-panel s-QEJqXNvtCF_z" aria-label="Список объектов"><div class="map-list-head s-QEJqXNvtCF_z"><strong class="s-QEJqXNvtCF_z"> </strong><button class="small s-QEJqXNvtCF_z" aria-label="Закрыть список">×</button></div> <div class="map-list-body s-QEJqXNvtCF_z"></div></aside>`), RiskMap[$.FILENAME], [[235, 6, [[236, 8, [[236, 35], [236, 78]]], [237, 8]]]]);
var root_15 = $.add_locations($.from_html(`<div class="map-about-float s-QEJqXNvtCF_z" role="dialog" aria-label="О карте и данных"><div class="map-list-head s-QEJqXNvtCF_z"><strong class="s-QEJqXNvtCF_z">О карте и данных</strong><button class="small s-QEJqXNvtCF_z" aria-label="Закрыть сведения">×</button></div> <p class="map-disclosure s-QEJqXNvtCF_z"> </p></div>`), RiskMap[$.FILENAME], [[241, 6, [[242, 8, [[242, 35], [242, 68]]], [243, 8]]]]);
var root_16 = $.add_locations($.from_html(`<button class="small s-QEJqXNvtCF_z">Все объекты</button>`), RiskMap[$.FILENAME], [[246, 139]]);
var root_17 = $.add_locations($.from_html(`<span class="s-QEJqXNvtCF_z">Базовая зона: зелёная / жёлтая / красная — по подтверждённым факторам</span>`), RiskMap[$.FILENAME], [[248, 25]]);

var root_18 = $.add_locations($.from_html(`<span class="s-QEJqXNvtCF_z"><i style="background:#388068" class="s-QEJqXNvtCF_z"></i> Проверенное основание</span><span class="s-QEJqXNvtCF_z"><i style="background:#bf453e" class="s-QEJqXNvtCF_z"></i> Проверенное отсутствие</span><span class="s-QEJqXNvtCF_z"><i class="s-QEJqXNvtCF_z"></i> Требует проверки</span>`, 1), RiskMap[$.FILENAME], [
	[249, 32, [[249, 38]]],
	[249, 101, [[249, 107]]],
	[249, 171, [[249, 177]]]
]);

var root_19 = $.add_locations($.from_html(`<span class="s-QEJqXNvtCF_z"><i style="background:#388068" class="s-QEJqXNvtCF_z"></i> Подтверждённая готовность</span><span class="s-QEJqXNvtCF_z"><i style="background:#b47b11" class="s-QEJqXNvtCF_z"></i> Разрыв ≥20 п.п.</span><span class="s-QEJqXNvtCF_z"><i class="s-QEJqXNvtCF_z"></i> Нет измеренной готовности</span>`, 1), RiskMap[$.FILENAME], [
	[250, 39, [[250, 45]]],
	[250, 112, [[250, 118]]],
	[250, 175, [[250, 181]]]
]);

var root_20 = $.add_locations($.from_html(`<span class="s-QEJqXNvtCF_z"><i style="background:#bf453e" class="s-QEJqXNvtCF_z"></i> Проверено предложение денег</span><span class="s-QEJqXNvtCF_z"><i class="s-QEJqXNvtCF_z"></i> Не подтверждено / нет данных</span>`, 1), RiskMap[$.FILENAME], [[251, 11, [[251, 17]]], [251, 86, [[251, 92]]]]);

var root_21 = $.add_locations($.from_html(`<section class="map-shell s-QEJqXNvtCF_z" aria-label="Карта объектов"><div class="map-wrap s-QEJqXNvtCF_z"><div class="map s-QEJqXNvtCF_z" aria-label="Карта объектов Өскемена"></div> <div class="map-tools map-float-top s-QEJqXNvtCF_z"><button class="small map-list-toggle s-QEJqXNvtCF_z"> </button> <input class="map-search s-QEJqXNvtCF_z" aria-label="Поиск ЖК, БИН или адреса на карте" placeholder="Поиск ЖК, БИН, адреса"/> <select aria-label="Базовая зона риска" class="s-QEJqXNvtCF_z"><option class="s-QEJqXNvtCF_z">Все зоны риска</option><option class="s-QEJqXNvtCF_z">Зелёная</option><option class="s-QEJqXNvtCF_z">Жёлтая</option><option class="s-QEJqXNvtCF_z">Красная</option></select> <div class="segmented s-QEJqXNvtCF_z" aria-label="Подложка"><button class="s-QEJqXNvtCF_z">Карта</button><button class="s-QEJqXNvtCF_z">Спутник</button></div> <div class="segmented s-QEJqXNvtCF_z" aria-label="Размерность карты"><button title="Плоская карта: метки и контуры" class="s-QEJqXNvtCF_z">2D</button><button title="2.5D: условные объёмные коробки корпусов" class="s-QEJqXNvtCF_z">2.5D</button><button title="Настоящий 3D-город: реальные дома, рельеф и небо" class="s-QEJqXNvtCF_z">3D</button></div> <div class="segmented xray s-QEJqXNvtCF_z" aria-label="Тема X-Ray"><span class="s-QEJqXNvtCF_z">X-Ray</span><!></div></div> <!> <!> <!> <!> <!> <!> <div class="map-caption s-QEJqXNvtCF_z"><span class="s-QEJqXNvtCF_z"> </span><!><button class="small map-about-toggle s-QEJqXNvtCF_z">О данных</button></div> <div class="map-legend map-legend-float s-QEJqXNvtCF_z" aria-live="polite"><!></div></div></section>`), RiskMap[$.FILENAME], [
	[
		181,
		0,
		[
			[
				182,
				2,
				[
					[183, 4],
					[
						184,
						4,
						[
							[185, 6],
							[186, 6],
							[187, 6, [[187, 64], [187, 107], [187, 145], [187, 183]]],
							[188, 6, [[188, 51], [188, 145]]],
							[189, 6, [[189, 60], [189, 214], [189, 387]]],
							[190, 6, [[190, 58]]]
						]
					],
					[246, 4, [[246, 29], [246, 220]]],
					[247, 4]
				]
			]
		]
	]
]);

function RiskMap($$anchor, $$props) {
	$.check_target(new.target);
	$.push($$props, true, RiskMap);

	let geometry = $.prop($$props, 'geometry', 19, () => []),
		relations = $.prop($$props, 'relations', 19, () => []),
		liveRegistryAvailable = $.prop($$props, 'liveRegistryAvailable', 3, false);

	let container;
	let map;
	let loaded = $.tag($.state(false), 'loaded');
	let markersReady = $.tag($.state(false), 'markersReady');
	let fallback = $.tag($.state(false), 'fallback');
	let warning = $.tag($.state(''), 'warning');
	let satellite = $.tag($.state(false), 'satellite');
	let dimensional = $.tag($.state(false), 'dimensional');
	let city3d = $.tag($.state(false), 'city3d');
	let theme = $.tag($.state('off'), 'theme');
	let query = $.tag($.state(''), 'query');
	let zone = $.tag($.state('all'), 'zone');
	let selectedId = $.tag($.state(''), 'selectedId');
	let selectedPhase = $.tag($.state(void 0), 'selectedPhase');
	let relatedIds = $.tag($.state(null), 'relatedIds');
	let camera = $.tag($.state($.proxy({ lng: 82.614, lat: 49.984, zoom: 12, bearing: 0 })), 'camera');
	let width = $.tag($.state(800), 'width');
	let listOpen = $.tag($.state(false), 'listOpen');
	let aboutOpen = $.tag($.state(false), 'aboutOpen');
	let height = $.tag($.state(520), 'height');

	const themes = [
		{ id: 'off', title: 'Выкл' },
		{ id: 'legal', title: 'Правовой' },
		{ id: 'construction', title: 'Стройка' },
		{ id: 'advertising', title: 'Реклама' }
	];

	const summaries = $.tag($.derived(() => $$props.complexes.filter(hasCoordinates).map((z) => summarizeMap(z, $.get(theme), $$props.ads))), 'summaries');
	const visible = $.tag($.derived(() => $.get(summaries).filter((z) => ($.strict_equals($.get(zone), 'all') || $.strict_equals(z.zone, $.get(zone))) && (!$.get(relatedIds) || $.get(relatedIds).includes(z.id)) && `${z.name} ${z.address} ${z.bin ?? ''}`.toLocaleLowerCase().includes($.get(query).trim().toLocaleLowerCase()))), 'visible');
	const selected = $.tag($.derived(() => $.get(summaries).find((z) => $.strict_equals(z.id, $.get(selectedId)))), 'selected');

	const geojson = $.tag(
		$.derived(() => ({
			type: 'FeatureCollection',
			features: $.get(visible).map((z) => ({
				type: 'Feature',
				geometry: { type: 'Point', coordinates: [z.lng, z.lat] },
				properties: { id: z.id, color: z.color }
			}))
		})),
		'geojson'
	);

	const footprints = $.tag($.derived(() => buildingShapes($.get(visible), geometry())), 'footprints');
	const selectedBox = $.tag($.derived(() => $.get(footprints).features.find((f) => $.strict_equals(f.properties.id, $.get(selectedId)) && (!$.get(selectedPhase) || $.strict_equals(f.properties.phaseId, $.get(selectedPhase))))), 'selectedBox');
	const selectedGeom = $.tag($.derived(() => geometry().find((g) => $.strict_equals(g.complexId, $.get(selected)?.id) && (!$.get(selectedPhase) || !g.phaseId || $.strict_equals(g.phaseId, $.get(selectedPhase))))), 'selectedGeom');
	const center = $.tag($.derived(() => worldPoint($.get(camera).lng, $.get(camera).lat, Math.floor($.get(camera).zoom))), 'center');

	const tiles = $.tag(
		$.derived(() => {
			const zoom = Math.floor($.get(camera).zoom);
			const count = 2 ** zoom;
			const result = [];

			for (let x = Math.floor(($.get(center)[0] - $.get(width) / 2) / 256); x <= Math.floor(($.get(center)[0] + $.get(width) / 2) / 256); x++) {
				for (let y = Math.floor(($.get(center)[1] - $.get(height) / 2) / 256); y <= Math.floor(($.get(center)[1] + $.get(height) / 2) / 256); y++) {
					if (y >= 0 && y < count) result.push({
						key: `${zoom}/${x}/${y}`,
						url: `https://tile.openstreetmap.org/${zoom}/${(x % count + count) % count}/${y}.png`,
						x: x * 256 - $.get(center)[0] + $.get(width) / 2,
						y: y * 256 - $.get(center)[1] + $.get(height) / 2
					});
				}
			}

			return result;
		}),
		'tiles'
	);

	const fallbackPoints = $.tag(
		$.derived(() => $.get(visible).map((z) => {
			const p = worldPoint(z.lng, z.lat, Math.floor($.get(camera).zoom));

			return {
				...z,
				x: p[0] - $.get(center)[0] + $.get(width) / 2,
				y: p[1] - $.get(center)[1] + $.get(height) / 2
			};
		}).filter((p) => p.x >= 0 && p.x <= $.get(width) && p.y >= 0 && p.y <= $.get(height))),
		'fallbackPoints'
	);

	function select(id, phase) {
		$.set(selectedId, id, true);
		$.set(selectedPhase, phase || undefined, true);
	}

	function open(tab) {
		if (!$.get(selected)) return;

		if ($$props.onOpenDossier && !tab) $$props.onOpenDossier($.get(selected).id, $.get(selectedPhase)); else location.hash = `/complexes/${encodeURIComponent($.get(selected).id)}${$.get(selectedPhase) || tab
			? `?${new URLSearchParams({
				...$.get(selectedPhase) ? { phase: $.get(selectedPhase) } : {},
				...tab ? { tab } : {}
			})}`
			: ''}`;
	}

	function related() {
		if (!$.get(selected)) return;

		const ids = relatedMapPlaces($.get(selected).id, relations(), $.get(summaries));

		$.set(relatedIds, [$.get(selected).id, ...ids], true);
		$$props.onShowRelatedPlaces?.($.get(selected).id);
	}

	function pan(dx, dy) {
		const p = worldCoordinates($.get(center)[0] + dx, $.get(center)[1] + dy, Math.floor($.get(camera).zoom));

		$.set(camera, { ...$.get(camera), lng: p[0], lat: p[1] }, true);
	}

	function changeZoom(delta) {
		$.set(
			camera,
			{
				...$.get(camera),
				zoom: Math.max(3, Math.min(19, Math.floor($.get(camera).zoom) + delta))
			},
			true
		);
	}

	function releaseWebGL(message) {
		if (map) {
			const c = map.getCenter();

			$.set(
				camera,
				{
					lng: c.lng,
					lat: c.lat,
					zoom: map.getZoom(),
					bearing: map.getBearing()
				},
				true
			);
		}

		$.set(loaded, false);
		$.set(fallback, true);
		$.set(dimensional, false);
		$.set(warning, message, true);
		map?.remove();
		map = undefined;
	}

	$.user_effect(() => {
		const data = $.get(geojson);

		if ($.get(loaded)) {
			$.set(markersReady, false);
			(map?.getSource('complexes'))?.setData(data);
		}
	});

	$.user_effect(() => {
		const data = $.get(footprints);

		if ($.get(loaded)) (map?.getSource('footprints'))?.setData(data);
	});

	function ensureSatellite() {
		if (!map || map.getSource('esri')) return;

		try {
			map.addSource('esri', {
				type: 'raster',
				tiles: [
					'https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}'
				],
				tileSize: 256,
				attribution: 'Esri World Imagery'
			});

			const raster = { id: 'satellite', type: 'raster', source: 'esri' };

			try {
				map.addLayer(raster, 'clusters');
			} catch {
				map.addLayer(raster);
			}
		} catch {
			/* Спутник недоступен — базовая карта продолжает работать. */
		}
	}

	$.user_effect(() => {
		if ($.get(loaded) && map) {
			if ($.get(satellite)) ensureSatellite();
			if (map.getLayer('satellite')) map.setLayoutProperty('satellite', 'visibility', $.get(satellite) ? 'visible' : 'none');
		}
	});

	function ensureTerrain() {
		if (!map || map.getSource('terrain-dem')) return;

		try {
			map.addSource('terrain-dem', {
				type: 'raster-dem',
				tiles: [
					'https://s3.amazonaws.com/elevation-tiles-prod/terrarium/{z}/{x}/{y}.png'
				],
				tileSize: 256,
				maxzoom: 15,
				encoding: 'terrarium'
			});
		} catch {
			/* Без рельефа — город остаётся плоским. */
		}
	}

	function ensureCity3D() {
		if (!map || map.getSource('openmaptiles')) return;

		try {
			map.addSource('openmaptiles', { type: 'vector', url: 'https://tiles.openfreemap.org/planet' });

			const city = {
				id: 'city3d-buildings',
				type: 'fill-extrusion',
				source: 'openmaptiles',
				'source-layer': 'building',
				filter: ['>', ['coalesce', ['get', 'render_height'], 0], 0],
				paint: {
					'fill-extrusion-color': '#ccd6cb',
					'fill-extrusion-height': ['coalesce', ['get', 'render_height'], 12],
					'fill-extrusion-base': ['coalesce', ['get', 'render_min_height'], 0],
					'fill-extrusion-opacity': 0.88,
					'fill-extrusion-vertical-gradient': true
				}
			};

			try {
				map.addLayer(city, 'buildings');
			} catch {
				try {
					map.addLayer(city);
				} catch {
					/* Настоящие 3D-дома недоступны — остаются условные коробки. */
				}
			}
		} catch {
			/* Настоящие 3D-дома недоступны — остаются условные коробки. */
		}
	}

	$.user_effect(() => {
		if ($.get(loaded) && map) {
			const reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

			try {
				if ($.get(city3d)) {
					// Настоящий 3D-город: реальные дома, рельеф и небо. Тяжёлые слои — только по первому включению.
					ensureCity3D();

					ensureTerrain();

					try {
						map.setTerrain({ source: 'terrain-dem', exaggeration: 1.2 });
					} catch {
						/* Рельеф недоступен. */
					}

					try {
						map.setSky?.({
							'sky-color': '#8db4dd',
							'horizon-color': '#e8eef0',
							'fog-color': '#dfe6ea',
							'sky-horizon-blend': 0.5,
							'horizon-fog-blend': 0.5,
							'fog-ground-blend': 0.5
						});
					} catch {
						/* Без неба. */
					}

					if (map.getLayer('city3d-buildings')) map.setLayoutProperty('city3d-buildings', 'visibility', 'visible');

					map.easeTo({
						pitch: 65,
						zoom: Math.max(map.getZoom(), 15),
						duration: reduce ? 0 : 600
					});
				} else {
					try {
						map.setTerrain(null);
					} catch {
						/* Рельефа и не было. */
					}

					try {
						map.setSky?.(null);
					} catch {
						/* Неба и не было. */
					}

					if (map.getLayer('city3d-buildings')) map.setLayoutProperty('city3d-buildings', 'visibility', 'none');

					const flat = !$.get(dimensional);

					map.easeTo({
						pitch: $.get(dimensional) ? 55 : 0,
						zoom: flat ? map.getZoom() : Math.max(map.getZoom(), 14.5),
						bearing: flat ? 0 : map.getBearing(),
						duration: reduce ? 0 : 450
					});
				}

				map.setLayoutProperty('buildings', 'visibility', !$.get(dimensional) && !$.get(city3d) ? 'none' : 'visible');

				const pts = !$.get(dimensional) && !$.get(city3d) ? 'visible' : 'none';

				for (const layer of ['points', 'clusters']) map.setLayoutProperty(layer, 'visibility', pts);

				map.setLayoutProperty('footprints-flat', 'visibility', !$.get(dimensional) && !$.get(city3d) ? 'visible' : 'none');
			} catch {
				/* Камера и слои остаются как были. */
			}
		}
	});

	onMount(() => {
		let disposed = false;

		const startupTimer = window.setTimeout(
			() => {
				if (!disposed && !$.get(markersReady) && !$.get(fallback)) releaseWebGL('Основная карта не ответила вовремя. Включена функциональная 2D-карта.');
			},
			8000
		);

		try {
			const saved = JSON.parse(sessionStorage.getItem('saq-map-view-v1') ?? 'null');

			if (saved && Array.isArray(saved.center) && $.strict_equals(saved.center.length, 2) && saved.center.every(Number.isFinite) && Math.abs(saved.center[0]) <= 180 && Math.abs(saved.center[1]) <= 85 && Number.isFinite(saved.zoom)) {
				$.set(
					camera,
					{
						lng: saved.center[0],
						lat: saved.center[1],
						zoom: Math.max(3, Math.min(19, saved.zoom)),
						bearing: Number.isFinite(saved.bearing) ? saved.bearing : 0
					},
					true
				);

				$.set(theme, themes.some((t) => $.strict_equals(t.id, saved.theme)) ? saved.theme : 'off', true);
				$.set(zone, ['all', 'green', 'yellow', 'red'].includes(saved.zone) ? saved.zone : 'all', true);
				$.set(query, $.strict_equals(typeof saved.query, 'string') ? saved.query.slice(0, 200) : '', true);
				$.set(selectedId, $.strict_equals(typeof saved.selectedId, 'string') ? saved.selectedId : '', true);
				$.set(selectedPhase, $.strict_equals(typeof saved.selectedPhase, 'string') ? saved.selectedPhase : undefined, true);
				$.set(satellite, $.strict_equals(saved.satellite, true));
				$.set(dimensional, $.strict_equals(saved.dimensional, true));
				$.set(city3d, $.strict_equals(saved.city3d, true) && $.strict_equals(saved.dimensional, true, false), true);
			}
		} catch {
			/* Storage may be unavailable; the map remains usable. */
		}

		const observer = new ResizeObserver((entries) => {
			$.set(width, entries[0].contentRect.width, true);
			$.set(height, entries[0].contentRect.height, true);
			map?.resize();
		});

		observer.observe(container);

		function visibility() {
			if (document.hidden) map?.stop(); else map?.resize();
		}

		document.addEventListener('visibilitychange', visibility);

		Promise.all([
			import("/node_modules/.vite/deps/maplibre-gl.js?v=f498b382"),
			import("/node_modules/maplibre-gl/dist/maplibre-gl-worker.mjs?worker&url")
		]).then(([ml, worker]) => {
			if (disposed || $.get(fallback)) return;

			try {
				// Vite relocates the main module; its original relative worker URL cannot survive prebundling.
				ml.setWorkerUrl(worker.default);

				map = new ml.Map({
					container,
					center: [$.get(camera).lng, $.get(camera).lat],
					zoom: $.get(camera).zoom,
					bearing: $.get(camera).bearing,
					maxPitch: 68,
					fadeDuration: 100,
					maxTileCacheSize: 80,
					style: {
						version: 8,
						sources: {
							osm: {
								type: 'raster',
								tiles: ['https://tile.openstreetmap.org/{z}/{x}/{y}.png'],
								tileSize: 256,
								attribution: '© OpenStreetMap contributors'
							}
						},
						layers: [{ id: 'osm', type: 'raster', source: 'osm' }]
					}
				});

				map.addControl(new ml.NavigationControl({ visualizePitch: true, showCompass: true }), 'top-right');

				map.on('webglcontextlost', () => {
					if (!disposed) releaseWebGL('WebGL недоступен. Включена функциональная 2D-карта.');
				});

				map.on('error', () => {
					$.set(warning, 'Часть картографических данных недоступна. Маркеры и список объектов работают.');
				});

				map.on('moveend', () => {
					if (map) {
						const c = map.getCenter();

						$.set(
							camera,
							{
								lng: c.lng,
								lat: c.lat,
								zoom: map.getZoom(),
								bearing: map.getBearing()
							},
							true
						);
					}
				});

				map.on('sourcedata', (e) => {
					if ($.strict_equals(e.sourceId, 'complexes') && e.isSourceLoaded) {
						$.set(markersReady, true);
						window.clearTimeout(startupTimer);
					}
				});

				map.on('style.load', () => {
					if (!map || disposed) return;

					map.addSource('complexes', {
						type: 'geojson',
						data: $.get(geojson),
						cluster: true,
						clusterMaxZoom: 14,
						clusterRadius: 45
					});

					map.addSource('footprints', { type: 'geojson', data: $.get(footprints) });

					map.addLayer({
						id: 'footprints-flat',
						type: 'fill',
						source: 'footprints',
						filter: ['==', ['get', 'approximateFootprint'], false],
						paint: { 'fill-color': ['get', 'color'], 'fill-opacity': 0.45 }
					});

					map.addLayer({
						id: 'buildings',
						type: 'fill-extrusion',
						source: 'footprints',
						layout: { visibility: $.get(dimensional) ? 'visible' : 'none' },
						paint: {
							'fill-extrusion-color': ['get', 'color'],
							'fill-extrusion-height': ['get', 'height'],
							'fill-extrusion-opacity': 0.9,
							'fill-extrusion-vertical-gradient': true
						}
					});

					map.addLayer({
						id: 'clusters',
						type: 'circle',
						source: 'complexes',
						filter: ['has', 'point_count'],
						paint: {
							'circle-color': '#183e33',
							'circle-radius': ['step', ['get', 'point_count'], 17, 10, 23],
							'circle-stroke-color': '#fff',
							'circle-stroke-width': 3
						}
					});

					map.addLayer({
						id: 'points',
						type: 'circle',
						source: 'complexes',
						filter: ['!', ['has', 'point_count']],
						paint: {
							'circle-color': ['get', 'color'],
							'circle-radius': 9,
							'circle-stroke-color': '#fff',
							'circle-stroke-width': 3
						}
					});

					for (const layer of ['points', 'footprints-flat', 'buildings']) {
						map.on('click', layer, (e) => {
							const p = e.features?.[0]?.properties;

							if ($.strict_equals(typeof p?.id, 'string')) select(p.id, p.phaseId);
						});

						map.on('mouseenter', layer, () => {
							if (map) map.getCanvas().style.cursor = 'pointer';
						});

						map.on('mouseleave', layer, () => {
							if (map) map.getCanvas().style.cursor = '';
						});
					}

					map.on('click', 'clusters', async (e) => {
						const f = e.features?.[0];
						const active = map;

						if (!active || !f || $.strict_equals(f.geometry.type, 'Point', false)) return;

						try {
							const zoom = (await $.track_reactivity_loss(active.getSource('complexes').getClusterExpansionZoom(Number(f.properties.cluster_id)) /* Map may unmount during cluster expansion. */))();

							if (!disposed && $.strict_equals(map, active)) active.easeTo({ center: f.geometry.coordinates, zoom });
						} catch {
							/* Map may unmount during cluster expansion. */
						}
					});

					$.set(loaded, true);
				});
			} catch {
				releaseWebGL('WebGL недоступен. Включена функциональная 2D-карта.');
			}
		}).catch(() => {
			if (!disposed) releaseWebGL('Картографический модуль недоступен. Включена 2D-карта.');
		});

		return () => {
			try {
				sessionStorage.setItem('saq-map-view-v1', JSON.stringify({
					center: [
						$.get(camera /* Best-effort view persistence, no dossier data. */).lng,
						$.get(camera).lat
					],
					zoom: $.get(camera).zoom,
					bearing: $.get(camera).bearing,
					theme: $.get(theme),
					zone: $.get(zone),
					query: $.get(query),
					selectedId: $.get(selectedId),
					selectedPhase: $.get(selectedPhase),
					satellite: $.get(satellite),
					dimensional: $.get(dimensional),
					city3d: $.get(city3d)
				}));
			} catch {
				/* Best-effort view persistence, no dossier data. */
			}

			disposed = true;
			observer.disconnect();
			document.removeEventListener('visibilitychange', visibility);
			$.set(loaded, false);
			map?.stop();
			map?.remove();
			map = undefined;
			window.clearTimeout(startupTimer);
		};
	});

	var $$exports = { ...$.legacy_api() };
	var section = root_21();
	var div = $.child(section);
	var div_1 = $.child(div);

	$.bind_this(div_1, ($$value) => container = $$value, () => container);

	var div_2 = $.sibling(div_1, 2);
	var button = $.child(div_2);
	var text = $.only_child(button);
	var input = $.sibling(button, 2);

	$.remove_input_defaults(input);

	var select_1 = $.sibling(input, 2);
	var option = $.child(select_1);

	option.value = option.__value = 'all';

	var option_1 = $.sibling(option);

	option_1.value = option_1.__value = 'green';

	var option_2 = $.sibling(option_1);

	option_2.value = option_2.__value = 'yellow';

	var option_3 = $.sibling(option_2);

	option_3.value = option_3.__value = 'red';
	$.reset(select_1);
	$.init_select(select_1);

	var div_3 = $.sibling(select_1, 2);
	var button_1 = $.child(div_3);
	var button_2 = $.sibling(button_1);

	$.reset(div_3);

	var div_4 = $.sibling(div_3, 2);
	var button_3 = $.child(div_4);
	var button_4 = $.sibling(button_3);
	var button_5 = $.sibling(button_4);

	$.reset(div_4);

	var div_5 = $.sibling(div_4, 2);
	var node = $.sibling($.child(div_5));

	$.add_svelte_meta(
		() => $.each(node, 17, () => themes, $.index, ($$anchor, t) => {
			var button_6 = root();
			var text_1 = $.only_child(button_6, true);

			$.template_effect(() => {
				$.set_attribute(button_6, 'aria-pressed', $.strict_equals($.get(theme), $.get(t).id));
				$.set_text(text_1, $.get(t).title);
			});

			$.delegated('click', button_6, function click_6() {
				return $.set(theme, $.get(t).id, true);
			});

			$.append($$anchor, button_6);
		}),
		'each',
		RiskMap,
		190,
		76
	);

	$.reset(div_5);
	$.reset(div_2);

	var node_1 = $.sibling(div_2, 2);

	{
		var consequent = ($$anchor) => {
			var div_6 = root_3();
			let styles;
			var node_2 = $.child(div_6);

			$.add_svelte_meta(
				() => $.each(node_2, 17, () => $.get(tiles), (tile) => tile.key, ($$anchor, tile) => {
					var img = root_1();
					let styles_1;

					$.template_effect(() => {
						$.set_attribute(img, 'src', $.get(tile).url);

						styles_1 = $.set_style(img, '', styles_1, {
							left: `${$.get(tile).x ?? ''}px`,
							top: `${$.get(tile).y ?? ''}px`
						});
					});

					$.append($$anchor, img);
				}),
				'each',
				RiskMap,
				194,
				8
			);

			var node_3 = $.sibling(node_2, 2);

			$.add_svelte_meta(
				() => $.each(node_3, 17, () => $.get(fallbackPoints), (point) => point.id, ($$anchor, point) => {
					var button_7 = root_2();
					let styles_2;

					$.template_effect(() => {
						$.set_attribute(button_7, 'aria-label', `${$.get(point).name}: ${$.get(point).label}`);
						$.set_attribute(button_7, 'title', `${$.get(point).name}: ${$.get(point).label}`);

						styles_2 = $.set_style(button_7, '', styles_2, {
							left: `${$.get(point).x ?? ''}px`,
							top: `${$.get(point).y ?? ''}px`,
							background: $.get(point).color
						});
					});

					$.delegated('click', button_7, function click_7() {
						return select($.get(point).id);
					});

					$.append($$anchor, button_7);
				}),
				'each',
				RiskMap,
				195,
				8
			);

			var nav = $.sibling(node_3, 2);
			var button_8 = $.child(nav);
			var button_9 = $.sibling(button_8);
			var button_10 = $.sibling(button_9);
			var button_11 = $.sibling(button_10);
			var button_12 = $.sibling(button_11);
			var button_13 = $.sibling(button_12);

			$.reset(nav);
			$.next(2);
			$.reset(div_6);
			$.template_effect(() => styles = $.set_style(div_6, '', styles, { height: `${$.get(height) ?? ''}px` }));

			$.delegated('click', button_8, function click_8() {
				return changeZoom(1);
			});

			$.delegated('click', button_9, function click_9() {
				return changeZoom(-1);
			});

			$.delegated('click', button_10, function click_10() {
				return pan(0, -160);
			});

			$.delegated('click', button_11, function click_11() {
				return pan(-160, 0);
			});

			$.delegated('click', button_12, function click_12() {
				return pan(160, 0);
			});

			$.delegated('click', button_13, function click_13() {
				return pan(0, 160);
			});

			$.append($$anchor, div_6);
		};

		$.add_svelte_meta(
			() => $.if(node_1, ($$render) => {
				if ($.get(fallback)) $$render(consequent);
			}),
			'if',
			RiskMap,
			192,
			4
		);
	}

	var node_4 = $.sibling(node_1, 2);

	{
		var consequent_1 = ($$anchor) => {
			var p_1 = root_4();

			$.append($$anchor, p_1);
		};

		$.add_svelte_meta(
			() => $.if(node_4, ($$render) => {
				if (!$.get(loaded) && !$.get(fallback)) $$render(consequent_1);
			}),
			'if',
			RiskMap,
			200,
			4
		);
	}

	var node_5 = $.sibling(node_4, 2);

	{
		var consequent_2 = ($$anchor) => {
			var p_2 = root_5();
			var text_2 = $.only_child(p_2, true);

			$.template_effect(() => $.set_text(text_2, $.get(warning)));
			$.append($$anchor, p_2);
		};

		$.add_svelte_meta(
			() => $.if(node_5, ($$render) => {
				if ($.get(warning)) $$render(consequent_2);
			}),
			'if',
			RiskMap,
			201,
			4
		);
	}

	var node_6 = $.sibling(node_5, 2);

	{
		var consequent_8 = ($$anchor) => {
			var aside = root_11();
			var div_7 = $.child(aside);
			var span = $.child(div_7);
			var text_3 = $.only_child(span);
			var button_14 = $.sibling(span);

			$.reset(div_7);

			var h3 = $.sibling(div_7, 2);
			var text_4 = $.only_child(h3, true);
			var p_3 = $.sibling(h3, 2);
			var text_5 = $.only_child(p_3, true);
			var div_8 = $.sibling(p_3, 2);
			let styles_3;
			var strong = $.child(div_8);
			var text_6 = $.only_child(strong, true);
			var span_1 = $.sibling(strong);
			var text_7 = $.only_child(span_1);

			$.reset(div_8);

			var dl = $.sibling(div_8, 2);
			var div_9 = $.child(dl);
			var dd = $.sibling($.child(div_9));
			var text_8 = $.only_child(dd, true);

			$.reset(div_9);

			var div_10 = $.sibling(div_9, 2);
			var dd_1 = $.sibling($.child(div_10));
			var text_9 = $.only_child(dd_1, true);

			$.reset(div_10);

			var div_11 = $.sibling(div_10, 2);
			var dd_2 = $.sibling($.child(div_11));
			var text_10 = $.only_child(dd_2, true);

			$.reset(div_11);

			var div_12 = $.sibling(div_11, 2);
			var dd_3 = $.sibling($.child(div_12));
			var text_11 = $.only_child(dd_3, true);

			$.reset(div_12);

			var div_13 = $.sibling(div_12, 2);
			var dd_4 = $.sibling($.child(div_13));
			var text_12 = $.only_child(dd_4, true);

			$.reset(div_13);
			$.reset(dl);

			var p_4 = $.sibling(dl, 2);
			var span_2 = $.child(p_4);
			let styles_4;
			var text_13 = $.sibling(span_2, 1, true);

			$.reset(p_4);

			var node_7 = $.sibling(p_4, 2);

			{
				var consequent_3 = ($$anchor) => {
					var div_14 = root_6();
					var strong_1 = $.child(div_14);
					var text_14 = $.only_child(strong_1, true);
					var dl_1 = $.sibling(strong_1, 2);
					var div_15 = $.child(dl_1);
					var dd_5 = $.sibling($.child(div_15));
					var text_15 = $.only_child(dd_5);

					$.reset(div_15);

					var div_16 = $.sibling(div_15, 2);
					var dd_6 = $.sibling($.child(div_16));
					var text_16 = $.only_child(dd_6, true);

					$.reset(div_16);

					var div_17 = $.sibling(div_16, 2);
					var dd_7 = $.sibling($.child(div_17));
					var text_17 = $.only_child(dd_7, true);

					$.reset(div_17);
					$.reset(dl_1);

					var button_15 = $.sibling(dl_1, 2);

					$.reset(div_14);

					$.template_effect(() => {
						$.set_text(text_14, $.get(selectedBox).properties.approximateFootprint || $.get(selectedBox).properties.approximateHeight ? 'Условная 3D-коробка' : 'Модель здания');
						$.set_text(text_15, `${$.get(selectedBox).properties.height ?? ''} м${$.get(selectedBox).properties.approximateHeight ? ' · условная' : ' · измеренная'}`);
						$.set_text(text_16, $.get(selectedBox).properties.approximateFootprint ? 'схема 60 × 44 м' : 'проверенный контур');
						$.set_text(text_17, $.get(selectedGeom)?.source ?? 'схема по координатам');
					});

					$.delegated('click', button_15, function click_15() {
						return open('timeline');
					});

					$.append($$anchor, div_14);
				};

				$.add_svelte_meta(
					() => $.if(node_7, ($$render) => {
						if ($.get(selectedBox)) $$render(consequent_3);
					}),
					'if',
					RiskMap,
					216,
					8
				);
			}

			var node_8 = $.sibling(node_7, 2);

			{
				var consequent_4 = ($$anchor) => {
					var p_5 = root_7();
					var text_18 = $.only_child(p_5, true);

					$.template_effect(() => $.set_text(text_18, $.get(selectedBox).properties.approximateFootprint
						? 'Контур и высота — схема, не обмер.'
						: 'Высота условная, контур проверен.'));

					$.append($$anchor, p_5);
				};

				$.add_svelte_meta(
					() => $.if(node_8, ($$render) => {
						if (($.get(dimensional) || $.get(city3d)) && $.get(selectedBox) && ($.get(selectedBox).properties.approximateFootprint || $.get(selectedBox).properties.approximateHeight)) $$render(consequent_4);
					}),
					'if',
					RiskMap,
					227,
					8
				);
			}

			var div_18 = $.sibling(node_8, 2);
			var button_16 = $.child(div_18);
			var button_17 = $.sibling(button_16);

			$.reset(div_18);

			var node_9 = $.sibling(div_18, 2);

			{
				var consequent_5 = ($$anchor) => {
					var button_18 = root_8();

					$.delegated('click', button_18, function click_17() {
						return open('timeline');
					});

					$.append($$anchor, button_18);
				};

				$.add_svelte_meta(
					() => $.if(node_9, ($$render) => {
						if ($.strict_equals($.get(theme), 'construction')) $$render(consequent_5);
					}),
					'if',
					RiskMap,
					229,
					8
				);
			}

			var node_10 = $.sibling(node_9, 2);

			{
				var consequent_6 = ($$anchor) => {
					var button_19 = root_9();

					$.delegated('click', button_19, function click_18() {
						return open('verification');
					});

					$.append($$anchor, button_19);
				};

				$.add_svelte_meta(
					() => $.if(node_10, ($$render) => {
						if ($.strict_equals($.get(theme), 'advertising')) $$render(consequent_6);
					}),
					'if',
					RiskMap,
					230,
					8
				);
			}

			var node_11 = $.sibling(node_10, 2);

			{
				var consequent_7 = ($$anchor) => {
					var p_6 = root_10();
					var text_19 = $.only_child(p_6);

					$.template_effect(() => $.set_text(text_19, `Связанных ЖК: ${$.get(relatedIds).length - 1}.`));
					$.append($$anchor, p_6);
				};

				$.add_svelte_meta(
					() => $.if(node_11, ($$render) => {
						if ($.get(relatedIds)) $$render(consequent_7);
					}),
					'if',
					RiskMap,
					231,
					8
				);
			}

			$.reset(aside);

			$.template_effect(
				($0) => {
					$.set_text(text_3, `${$.get(selected).demo ? 'Демо · ' : ''}${$.get(selectedPhase) ? `Очередь ${$.get(selectedPhase)}` : 'Жилой комплекс'}`);
					$.set_text(text_4, $.get(selected).name);
					$.set_text(text_5, $.get(selected).address);
					styles_3 = $.set_style(div_8, '', styles_3, { 'border-left-color': $.get(selected).color });
					$.set_text(text_6, $.get(selected).score);
					$.set_text(text_7, `${$0 ?? ''} зона`);
					$.set_text(text_8, $.get(selected).developer);
					$.set_text(text_9, $.get(selected).bin ?? 'Не указан');
					$.set_text(text_10, $.get(selected).source || 'Не зафиксирован');
					$.set_text(text_11, $.get(selected).date || '—');
					$.set_text(text_12, $.get(selected).publications ?? 'нет данных');
					styles_4 = $.set_style(span_2, '', styles_4, { background: $.get(selected).color });
					$.set_text(text_13, $.get(selected).label);
				},
				[() => zoneLabel($.get(selected).zone)]
			);

			$.delegated('click', button_14, function click_14() {
				return $.set(selectedId, '');
			});

			$.delegated('click', button_16, function click_16() {
				return open();
			});

			$.delegated('click', button_17, related);
			$.append($$anchor, aside);
		};

		$.add_svelte_meta(
			() => $.if(node_6, ($$render) => {
				if ($.get(selected)) $$render(consequent_8);
			}),
			'if',
			RiskMap,
			202,
			4
		);
	}

	var node_12 = $.sibling(node_6, 2);

	{
		var consequent_9 = ($$anchor) => {
			var aside_1 = root_14();
			var div_19 = $.child(aside_1);
			var strong_2 = $.child(div_19);
			var text_20 = $.only_child(strong_2);
			var button_20 = $.sibling(strong_2);

			$.reset(div_19);

			var div_20 = $.sibling(div_19, 2);

			$.add_svelte_meta(
				() => $.each(
					div_20,
					21,
					() => $.get(visible),
					(item) => item.id,
					($$anchor, item) => {
						var button_21 = root_12();
						let classes;
						var span_3 = $.child(button_21);
						var text_21 = $.only_child(span_3, true);
						var small = $.sibling(span_3);
						var text_22 = $.only_child(small, true);

						$.reset(button_21);

						$.template_effect(() => {
							classes = $.set_class(button_21, 1, 's-QEJqXNvtCF_z', null, classes, { active: $.strict_equals($.get(item).id, $.get(selectedId)) });
							$.set_text(text_21, $.get(item).name);
							$.set_text(text_22, $.get(item).label);
						});

						$.delegated('click', button_21, function click_20() {
							return select($.get(item).id);
						});

						$.append($$anchor, button_21);
					},
					($$anchor) => {
						var p_7 = root_13();

						$.append($$anchor, p_7);
					}
				),
				'each',
				RiskMap,
				237,
				35
			);

			$.reset(div_20);
			$.reset(aside_1);
			$.template_effect(() => $.set_text(text_20, `Объекты · ${$.get(visible).length ?? ''}`));

			$.delegated('click', button_20, function click_19() {
				return $.set(listOpen, false);
			});

			$.append($$anchor, aside_1);
		};

		$.add_svelte_meta(
			() => $.if(node_12, ($$render) => {
				if ($.get(listOpen)) $$render(consequent_9);
			}),
			'if',
			RiskMap,
			234,
			4
		);
	}

	var node_13 = $.sibling(node_12, 2);

	{
		var consequent_10 = ($$anchor) => {
			var div_21 = root_15();
			var div_22 = $.child(div_21);
			var button_22 = $.sibling($.child(div_22));

			$.reset(div_22);

			var p_8 = $.sibling(div_22, 2);
			var text_23 = $.only_child(p_8);

			$.reset(div_21);

			$.template_effect(() => $.set_text(text_23, `Без координат: ${$$props.complexes.length - $.get(summaries).length}. ${$.get(city3d)
				? '3D — настоящий объёмный город: реальные дома, рельеф и небо. Подсвеченные корпуса те же: проверенные контуры или условная схема 60 × 44 м, высота 36 м.'
				: $.get(dimensional)
					? '2.5D: объёмные коробки вместо точек. Проверенные контуры используются при наличии; остальные коробки условные (60 × 44 м, высота 36 м).'
					: '2D: метки объектов и проверенные контуры.'} ${!liveRegistryAvailable() ? 'Live-сверка реестров недоступна. ' : ''}Координаты приблизительные. Дата спутникового снимка неизвестна. Нулевой балл не подтверждает безопасность.`));

			$.delegated('click', button_22, function click_21() {
				return $.set(aboutOpen, false);
			});

			$.append($$anchor, div_21);
		};

		$.add_svelte_meta(
			() => $.if(node_13, ($$render) => {
				if ($.get(aboutOpen)) $$render(consequent_10);
			}),
			'if',
			RiskMap,
			240,
			4
		);
	}

	var div_23 = $.sibling(node_13, 2);
	var span_4 = $.child(div_23);
	var text_24 = $.only_child(span_4);
	var node_14 = $.sibling(span_4);

	{
		var consequent_11 = ($$anchor) => {
			var button_23 = root_16();

			$.delegated('click', button_23, function click_22() {
				return $.set(relatedIds, null);
			});

			$.append($$anchor, button_23);
		};

		$.add_svelte_meta(
			() => $.if(node_14, ($$render) => {
				if ($.get(relatedIds)) $$render(consequent_11);
			}),
			'if',
			RiskMap,
			246,
			123
		);
	}

	var button_24 = $.sibling(node_14);

	$.reset(div_23);

	var div_24 = $.sibling(div_23, 2);
	var node_15 = $.child(div_24);

	{
		var consequent_12 = ($$anchor) => {
			var span_5 = root_17();

			$.append($$anchor, span_5);
		};

		var consequent_13 = ($$anchor) => {
			var fragment = root_18();
			var span_6 = $.sibling($.first_child(fragment), 2);
			var i = $.child(span_6);
			let styles_5;

			$.next();
			$.reset(span_6);
			$.template_effect(() => styles_5 = $.set_style(i, '', styles_5, { background: UNKNOWN_COLOR }));
			$.append($$anchor, fragment);
		};

		var consequent_14 = ($$anchor) => {
			var fragment_1 = root_19();
			var span_7 = $.sibling($.first_child(fragment_1), 2);
			var i_1 = $.child(span_7);
			let styles_6;

			$.next();
			$.reset(span_7);
			$.template_effect(() => styles_6 = $.set_style(i_1, '', styles_6, { background: UNKNOWN_COLOR }));
			$.append($$anchor, fragment_1);
		};

		var alternate = ($$anchor) => {
			var fragment_2 = root_20();
			var span_8 = $.sibling($.first_child(fragment_2));
			var i_2 = $.child(span_8);
			let styles_7;

			$.next();
			$.reset(span_8);
			$.template_effect(() => styles_7 = $.set_style(i_2, '', styles_7, { background: UNKNOWN_COLOR }));
			$.append($$anchor, fragment_2);
		};

		$.add_svelte_meta(
			() => $.if(node_15, ($$render) => {
				if ($.strict_equals($.get(theme), 'off')) $$render(consequent_12); else if ($.strict_equals($.get(theme), 'legal')) $$render(consequent_13, 1); else if ($.strict_equals($.get(theme), 'construction')) $$render(consequent_14, 2); else $$render(alternate, -1);
			}),
			'if',
			RiskMap,
			248,
			4
		);
	}

	$.reset(div_24);
	$.reset(div);
	$.reset(section);

	$.template_effect(
		($0) => {
			$.set_attribute(div, 'data-map-ready', $.get(fallback) || $.get(markersReady));
			$.set_attribute(button, 'aria-expanded', $.get(listOpen));
			$.set_text(text, `Список · ${$.get(visible).length ?? ''}`);
			$.set_attribute(button_1, 'aria-pressed', !$.get(satellite) || $.get(fallback));
			button_2.disabled = $.get(fallback);
			$.set_attribute(button_2, 'aria-pressed', $.get(satellite) && !$.get(fallback));
			$.set_attribute(button_3, 'aria-pressed', !$.get(dimensional) && !$.get(city3d));
			button_4.disabled = $.get(fallback);
			$.set_attribute(button_4, 'aria-pressed', $.get(dimensional));
			button_5.disabled = $.get(fallback);
			$.set_attribute(button_5, 'aria-pressed', $.get(city3d));
			$.set_text(text_24, `ӨСКЕМЕН · ${$.get(visible).length ?? ''} объектов${$0 ?? ''}`);
			$.set_attribute(button_24, 'aria-expanded', $.get(aboutOpen));
		},
		[() => $.get(summaries).some((s) => s.demo) ? ' · DEMO' : '']
	);

	$.delegated('click', button, function click() {
		return $.set(listOpen, !$.get(listOpen));
	});

	$.bind_value(
		input,
		function get() {
			return $.get(query);
		},
		function set($$value) {
			$.set(query, $$value);
		}
	);

	$.bind_select_value(
		select_1,
		function get() {
			return $.get(zone);
		},
		function set($$value) {
			$.set(zone, $$value);
		}
	);

	$.delegated('click', button_1, function click_1() {
		return $.set(satellite, false);
	});

	$.delegated('click', button_2, function click_2() {
		return $.set(satellite, true);
	});

	$.delegated('click', button_3, function click_3() {
		$.set(dimensional, false);
		$.set(city3d, false);
	});

	$.delegated('click', button_4, function click_4() {
		$.set(dimensional, true);
		$.set(city3d, false);
	});

	$.delegated('click', button_5, function click_5() {
		$.set(city3d, true);
		$.set(dimensional, false);
	});

	$.delegated('click', button_24, function click_23() {
		return $.set(aboutOpen, !$.get(aboutOpen));
	});

	$.append($$anchor, section);

	return $.pop($$exports);
}

if (import.meta.hot) {
	RiskMap = $.hmr(RiskMap);

	import.meta.hot.acceptExports(["default"],(module) => {
		$.cleanup_styles('s-QEJqXNvtCF_z');
		RiskMap[$.HMR].update(module.default);
	});
}

export default RiskMap;

$.delegate(['click']);
import "/src/components/RiskMap.svelte?svelte&type=style&lang.css";

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6Ijs7Ozs7QUFDRSxNQUFNLEdBQUcsT0FBTyxRQUFRLFFBQVEsQ0FBQztBQUdqQyxNQUFNLEdBQUcsU0FBUyxRQUFRLGdCQUFnQixDQUFDOztBQUMzQyxNQUFNO0NBQUcsY0FBYztDQUFFLFlBQVk7Q0FBRSxjQUFjO0NBQUUsVUFBVTtDQUFFLGdCQUFnQjtDQUFFLGdCQUFnQjtDQUFFLGFBQWE7T0FBNEQsa0JBQWtCLENBQUM7O0FBQ25NLE1BQU0sQ0FBQyxrQ0FBa0MsQ0FBQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztvQ0FONUMsQ0FBQzs7OztDQU9DLEdBQUcsQ0FBbUIsUUFBUSx5Q0FBRyxFQUFFO0VBQUUsU0FBUywwQ0FBRyxFQUFFO0VBQUUscUJBQXFCLCtDQUFHLEtBQUssRUFHckU7O0NBQ2IsR0FBRyxDQUFDLFNBQVMsQUFBZ0IsQ0FBQztDQUM5QixHQUFHLENBQUMsR0FBRyxBQUFxQixDQUFDO0NBQzdCLEdBQUcsQ0FBQyxNQUFNLFNBQUcsT0FBTyxBQUFELENBQUMsS0FBSyxhQUFFO0NBQzNCLEdBQUcsQ0FBQyxZQUFZLFNBQUcsT0FBTyxBQUFELENBQUMsS0FBSyxtQkFBRTtDQUNqQyxHQUFHLENBQUMsUUFBUSxTQUFHLE9BQU8sQUFBRCxDQUFDLEtBQUssZUFBRTtDQUM3QixHQUFHLENBQUMsT0FBTyxTQUFHLE9BQU8sQUFBRCxDQUFDLEVBQUUsY0FBRTtDQUN6QixHQUFHLENBQUMsU0FBUyxTQUFHLE9BQU8sQUFBRCxDQUFDLEtBQUssZ0JBQUU7Q0FDOUIsR0FBRyxDQUFDLFdBQVcsU0FBRyxPQUFPLEFBQUQsQ0FBQyxLQUFLLGtCQUFFO0NBQ2hDLEdBQUcsQ0FBQyxNQUFNLFNBQUcsT0FBTyxBQUFELENBQUMsS0FBSyxhQUFFO0NBQzNCLEdBQUcsQ0FBQyxLQUFLLFNBQUcsT0FBTyxBQUFELENBQVksS0FBSyxZQUFFO0NBQ3JDLEdBQUcsQ0FBQyxLQUFLLFNBQUcsT0FBTyxBQUFELENBQUMsRUFBRSxZQUFFO0NBQ3ZCLEdBQUcsQ0FBQyxJQUFJLFNBQUcsT0FBTyxBQUFELENBQUMsS0FBSyxXQUFFO0NBQ3pCLEdBQUcsQ0FBQyxVQUFVLFNBQUcsT0FBTyxBQUFELENBQUMsRUFBRSxpQkFBRTtDQUM1QixHQUFHLENBQUMsYUFBYSxTQUFHLE9BQU8sQUFBRCwyQkFBdUI7Q0FDakQsR0FBRyxDQUFDLFVBQVUsU0FBRyxPQUFPLEFBQUQsQ0FBa0IsSUFBSSxpQkFBRTtDQUMvQyxHQUFHLENBQUMsTUFBTSxTQUFHLE9BQU8sQUFBRCxTQUFDLEVBQUUsR0FBRyxFQUFFLE1BQU0sRUFBRSxHQUFHLEVBQUUsTUFBTSxFQUFFLElBQUksRUFBRSxFQUFFLEVBQUUsT0FBTyxFQUFFLENBQUMsRUFBRSxjQUFFO0NBQ3hFLEdBQUcsQ0FBQyxLQUFLLFNBQUcsT0FBTyxBQUFELENBQUMsR0FBRyxZQUFFO0NBQ3hCLEdBQUcsQ0FBQyxRQUFRLFNBQUcsT0FBTyxBQUFELENBQUMsS0FBSyxlQUFFO0NBQzdCLEdBQUcsQ0FBQyxTQUFTLFNBQUcsT0FBTyxBQUFELENBQUMsS0FBSyxnQkFBRTtDQUM5QixHQUFHLENBQUMsTUFBTSxTQUFHLE9BQU8sQUFBRCxDQUFDLEdBQUcsYUFBRTs7Q0FDekIsS0FBSyxDQUFDLE1BQU0sQUFBb0MsR0FBRztFQUFDLEVBQUUsRUFBRSxFQUFFLEtBQUssRUFBRSxLQUFLLEVBQUUsTUFBTSxFQUFFO0VBQUUsRUFBRSxFQUFFLEVBQUUsT0FBTyxFQUFFLEtBQUssRUFBRSxVQUFVLEVBQUU7RUFBRSxFQUFFLEVBQUUsRUFBRSxjQUFjLEVBQUUsS0FBSyxFQUFFLFNBQVMsRUFBRTtFQUFFLEVBQUUsRUFBRSxFQUFFLGFBQWEsRUFBRSxLQUFLLEVBQUUsU0FBUyxFQUFFO0VBQUMsQ0FBQzs7Q0FDek0sS0FBSyxDQUFDLFNBQVMseUJBQVksa0JBQVUsTUFBTSxDQUFDLGNBQWMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxFQUFDLEtBQUksWUFBWSxDQUFDLENBQUMsUUFBRSxLQUFLLGVBQU0sQ0FBQyxnQkFBRTtDQUNuRyxLQUFLLENBQUMsT0FBTyx5QkFBWSxlQUFTLEVBQUMsTUFBTSxDQUFDLEVBQUMsS0FBSSxBQUFDLDJCQUFJLEdBQUssS0FBSyxxQkFBSSxDQUFDLENBQUMsSUFBSSxRQUFLLElBQUksT0FBTSxFQUFDLGdCQUFVLEtBQUksZ0JBQVUsRUFBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLElBQUksR0FBRyxDQUFDLENBQUMsSUFBSSxJQUFJLENBQUMsQ0FBQyxPQUFPLElBQUksQ0FBQyxDQUFDLEdBQUcsSUFBSSxFQUFFLEVBQUUsQ0FBQyxpQkFBaUIsRUFBRSxDQUFDLFFBQVEsQ0FBQyxXQUFLLEVBQUMsSUFBSSxFQUFFLENBQUMsaUJBQWlCLEVBQUUsQ0FBQyxDQUFDLGNBQUU7Q0FDN08sS0FBSyxDQUFDLFFBQVEseUJBQVksZUFBUyxFQUFDLElBQUksQ0FBQyxFQUFDLHFCQUFJLENBQUMsQ0FBQyxFQUFFLFFBQUssVUFBVSxHQUFDLGVBQUU7O0NBQ3BFLEtBQUssQ0FBQyxPQUFPO2tCQUFZO0dBQUUsSUFBSSxFQUFFLG1CQUFtQixBQUFTO0dBQUUsUUFBUSxFQUFFLGFBQU8sRUFBQyxHQUFHLENBQUMsRUFBQyxLQUFLO0lBQUUsSUFBSSxFQUFFLFNBQVMsQUFBUztJQUFFLFFBQVEsRUFBRSxFQUFFLElBQUksRUFBRSxPQUFPLEFBQVMsRUFBRSxXQUFXLEVBQUUsQ0FBQyxDQUFDLENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBQyxHQUFHLENBQUMsRUFBRTtJQUFFLFVBQVUsRUFBRSxFQUFFLEVBQUUsRUFBRSxDQUFDLENBQUMsRUFBRSxFQUFFLEtBQUssRUFBRSxDQUFDLENBQUMsS0FBSyxFQUFFO0lBQUUsQ0FBQyxDQUFDO0dBQUU7O0dBQUU7O0NBQzFPLEtBQUssQ0FBQyxVQUFVLHlCQUFZLGNBQWMsT0FBQyxPQUFPLEdBQUUsUUFBUSxHQUFDLGlCQUFFO0NBQy9ELEtBQUssQ0FBQyxXQUFXLHlCQUFZLGdCQUFVLEVBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxFQUFDLEtBQUUsaUJBQUMsQ0FBQyxVQUFVLENBQUMsRUFBRSxRQUFHLFVBQVUsTUFBSyxFQUFDLG1CQUFhLHFCQUFJLENBQUMsQ0FBQyxVQUFVLENBQUMsT0FBTyxRQUFHLGFBQWEsR0FBQyxDQUFDLGtCQUFFO0NBQ3BKLEtBQUssQ0FBQyxZQUFZLHlCQUFZLFFBQVEsR0FBQyxJQUFJLENBQUMsRUFBQyxLQUFJLGlCQUFDLENBQUMsU0FBUyxFQUFHLGNBQVEsR0FBRSxFQUFFLEtBQUssRUFBQyxtQkFBYSxLQUFJLENBQUMsQ0FBQyxDQUFDLE9BQU8sb0JBQUksQ0FBQyxDQUFDLE9BQU8sUUFBRyxhQUFhLEdBQUMsQ0FBQyxtQkFBRTtDQUM3SSxLQUFLLENBQUMsTUFBTSx5QkFBWSxVQUFVLENBQUMsWUFBTSxFQUFDLEdBQUcsRUFBRSxZQUFNLEVBQUMsR0FBRyxFQUFFLElBQUksQ0FBQyxLQUFLLENBQUMsWUFBTSxFQUFDLElBQUksQ0FBQyxDQUFDLGFBQUU7O0NBQ3JGLEtBQUssQ0FBQyxLQUFLO1lBQWUsTUFBTSxDQUFDO0dBQy9CLEtBQUssQ0FBQyxJQUFJLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxZQUFNLEVBQUMsSUFBSSxDQUFDLENBQUM7R0FBQyxLQUFLLENBQUMsS0FBSyxHQUFHLENBQUMsSUFBSSxJQUFJLENBQUM7R0FBQyxLQUFLLENBQUMsTUFBTSxHQUFHLEVBQUUsQ0FBQzs7R0FDakYsR0FBRyxFQUFFLEdBQUcsQ0FBQyxDQUFDLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxBQUFDLGFBQU0sRUFBQyxDQUFDLENBQUMsR0FBRyxXQUFLLElBQUcsQ0FBQyxJQUFJLEdBQUcsQ0FBQyxFQUFFLENBQUMsSUFBSSxJQUFJLENBQUMsS0FBSyxDQUFDLEFBQUMsYUFBTSxFQUFDLENBQUMsQ0FBQyxHQUFHLFdBQUssSUFBRyxDQUFDLElBQUksR0FBRyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQztJQUM1RyxHQUFHLEVBQUUsR0FBRyxDQUFDLENBQUMsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLEFBQUMsYUFBTSxFQUFDLENBQUMsQ0FBQyxHQUFHLFlBQU0sSUFBRyxDQUFDLElBQUksR0FBRyxDQUFDLEVBQUUsQ0FBQyxJQUFJLElBQUksQ0FBQyxLQUFLLENBQUMsQUFBQyxhQUFNLEVBQUMsQ0FBQyxDQUFDLEdBQUcsWUFBTSxJQUFHLENBQUMsSUFBSSxHQUFHLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDO0tBQzlHLEVBQUUsRUFBRSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsR0FBRyxLQUFLLEVBQUUsTUFBTSxDQUFDLElBQUksQ0FBQztNQUFFLEdBQUcsRUFBRSxHQUFHLElBQUksSUFBSSxDQUFDLElBQUksQ0FBQyxFQUFFO01BQUUsR0FBRyxFQUFFLGtDQUFrQyxJQUFJLElBQUksQUFBQyxDQUFDLENBQUMsR0FBRyxLQUFLLEdBQUksS0FBSyxJQUFJLEtBQUssSUFBSSxDQUFDLE1BQU07TUFBRSxDQUFDLEVBQUUsQ0FBQyxHQUFHLEdBQUcsR0FBRyxZQUFNLEVBQUMsQ0FBQyxDQUFDLEdBQUcsV0FBSyxJQUFHLENBQUM7TUFBRSxDQUFDLEVBQUUsQ0FBQyxHQUFHLEdBQUcsR0FBRyxZQUFNLEVBQUMsQ0FBQyxDQUFDLEdBQUcsWUFBTSxJQUFHLENBQUM7TUFBRSxDQUFDLENBQUM7SUFDdk8sQ0FBQztHQUNILENBQUM7O0dBQ0QsTUFBTSxDQUFDLE1BQU0sQ0FBQztFQUNoQixDQUFDOztHQUFFOztDQUNILEtBQUssQ0FBQyxjQUFjO2tCQUFZLGFBQU8sRUFBQyxHQUFHLENBQUMsRUFBQyxLQUFJLENBQUM7R0FBQyxLQUFLLENBQUMsQ0FBQyxHQUFHLFVBQVUsQ0FBQyxDQUFDLENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBQyxHQUFHLEVBQUUsSUFBSSxDQUFDLEtBQUssQ0FBQyxZQUFNLEVBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQzs7R0FBQyxNQUFNLENBQUM7SUFBRSxHQUFHLENBQUM7SUFBRSxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLFlBQU0sRUFBQyxDQUFDLENBQUMsR0FBRyxXQUFLLElBQUcsQ0FBQztJQUFFLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsWUFBTSxFQUFDLENBQUMsQ0FBQyxHQUFHLFlBQU0sSUFBRyxDQUFDO0lBQUUsQ0FBQztFQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxFQUFDLEtBQUksQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsVUFBSSxLQUFLLEtBQUksQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsVUFBSSxNQUFNLEVBQUM7O0dBQUU7O0NBQzNRLFNBQVMsTUFBTSxDQUFDLEVBQUUsQUFBUSxFQUFFLEtBQUssQUFBUyxFQUFFLENBQUM7RUFBQyxnQkFBVSxFQUFHLEVBQUUsUUFBQztFQUFDLG1CQUFhLEVBQUcsS0FBSyxJQUFJLFNBQVMsUUFBQztDQUFDLENBQUM7O0NBQ3BHLFNBQVMsSUFBSSxDQUFDLEdBQUcsQUFBUyxFQUFFLENBQUM7RUFDM0IsRUFBRSxFQUFFLENBQUMsY0FBUSxHQUFFLE1BQU0sQ0FBQzs7RUFDdEIsRUFBRSxFQUFFLHlCQUFpQixDQUFDLEdBQUcsRUFBRSxzQkFBYyxjQUFRLEVBQUMsRUFBRSxRQUFFLGFBQWEsRUFBQyxDQUFDLE1BQ2hFLFFBQVEsQ0FBQyxJQUFJLEdBQUcsY0FBYyxrQkFBa0IsQ0FBQyxjQUFRLEVBQUMsRUFBRSxDQUFDLEdBQUcsbUJBQWEsS0FBSSxHQUFHO0tBQUcsSUFBSSxHQUFHLENBQUMsZUFBZSxDQUFDO0lBQUUsR0FBSSxtQkFBYSxJQUFHLEVBQUUsS0FBSyxRQUFFLGFBQWEsR0FBRSxHQUFHLEVBQUUsQUFBQztJQUFFLEdBQUksR0FBRyxHQUFHLEVBQUUsR0FBRyxFQUFFLEdBQUcsRUFBRSxBQUFDO0lBQUUsQ0FBQyxFQUFFO0tBQUcsRUFBRSxFQUFFLENBQUM7Q0FDaE4sQ0FBQzs7Q0FDRCxTQUFTLE9BQU8sR0FBRyxDQUFDO0VBQ2xCLEVBQUUsRUFBRSxDQUFDLGNBQVEsR0FBRSxNQUFNLENBQUM7O0VBQ3RCLEtBQUssQ0FBQyxHQUFHLEdBQUcsZ0JBQWdCLENBQUMsY0FBUSxFQUFDLEVBQUUsRUFBRSxTQUFTLFVBQUUsU0FBUyxFQUFDLENBQUM7O0VBQ2hFLGdCQUFVLEVBQUcsQ0FBQyxjQUFRLEVBQUMsRUFBRSxFQUFFLEdBQUcsR0FBRyxDQUFDLFFBQUM7RUFDbkMsOEJBQXNCLGNBQVEsRUFBQyxFQUFFLENBQUMsQ0FBQztDQUNyQyxDQUFDOztDQUNELFNBQVMsR0FBRyxDQUFDLEVBQUUsQUFBUSxFQUFFLEVBQUUsQUFBUSxFQUFFLENBQUM7RUFBQyxLQUFLLENBQUMsQ0FBQyxHQUFHLGdCQUFnQixDQUFDLFlBQU0sRUFBQyxDQUFDLENBQUMsR0FBRyxFQUFFLEVBQUUsWUFBTSxFQUFDLENBQUMsQ0FBQyxHQUFHLEVBQUUsRUFBRSxJQUFJLENBQUMsS0FBSyxDQUFDLFlBQU0sRUFBQyxJQUFJLENBQUMsQ0FBQyxDQUFDOztFQUFDLFlBQU0sRUFBRyxFQUFFLFNBQUcsTUFBTSxHQUFFLEdBQUcsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsR0FBRyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxRQUFDO0NBQUMsQ0FBQzs7Q0FDM0ssU0FBUyxVQUFVLENBQUMsS0FBSyxBQUFRLEVBQUUsQ0FBQztFQUFDO0dBQUEsTUFBTTtHQUFHO0lBQUUsU0FBRyxNQUFNO0lBQUUsSUFBSSxFQUFFLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxFQUFFLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxFQUFFLElBQUksQ0FBQyxLQUFLLENBQUMsWUFBTSxFQUFDLElBQUksQ0FBQyxHQUFHLEtBQUssQ0FBQyxDQUFDO0lBQUU7O0lBQUM7Q0FBQyxDQUFDOztDQUNoSSxTQUFTLFlBQVksQ0FBQyxPQUFPLEFBQVEsRUFBRSxDQUFDO0VBQ3RDLEVBQUUsRUFBRSxHQUFHLEVBQUUsQ0FBQztHQUFDLEtBQUssQ0FBQyxDQUFDLEdBQUcsR0FBRyxDQUFDLFNBQVMsRUFBRSxDQUFDOztHQUFDO0lBQUEsTUFBTTtJQUFHO0tBQUUsR0FBRyxFQUFFLENBQUMsQ0FBQyxHQUFHO0tBQUUsR0FBRyxFQUFFLENBQUMsQ0FBQyxHQUFHO0tBQUUsSUFBSSxFQUFFLEdBQUcsQ0FBQyxPQUFPLEVBQUU7S0FBRSxPQUFPLEVBQUUsR0FBRyxDQUFDLFVBQVUsRUFBRTtLQUFFOztLQUFDO0VBQUMsQ0FBQzs7RUFDNUgsWUFBTSxFQUFHLEtBQUssRUFBQztFQUFDLGNBQVEsRUFBRyxJQUFJLEVBQUM7RUFBQyxpQkFBVyxFQUFHLEtBQUssRUFBQztFQUFDLGFBQU8sRUFBRyxPQUFPLFFBQUM7RUFBQyxHQUFHLEVBQUUsTUFBTSxFQUFFLENBQUM7RUFBQyxHQUFHLEdBQUcsU0FBUyxDQUFDO0NBQzFHLENBQUM7O0NBQ0QsYUFBYSxBQUFOLENBQUMsTUFBTSxDQUFDO0VBQUMsS0FBSyxDQUFDLElBQUksU0FBRyxPQUFPLEVBQUM7O0VBQUMsRUFBRSxRQUFFLE1BQU0sR0FBRSxDQUFDO0dBQUMsa0JBQVksRUFBRyxLQUFLLEVBQUM7R0FBQyxBQUFDLElBQUcsRUFBRSxTQUFTLENBQUMsV0FBVyxDQUFDLEdBQWdDLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQztFQUFDLENBQUM7Q0FBQyxDQUFDLEVBQUU7O0NBQzFKLGFBQWEsQUFBTixDQUFDLE1BQU0sQ0FBQztFQUFDLEtBQUssQ0FBQyxJQUFJLFNBQUcsVUFBVSxFQUFDOztFQUFDLEVBQUUsUUFBRSxNQUFNLEdBQUUsQUFBQyxJQUFHLEVBQUUsU0FBUyxDQUFDLFlBQVksQ0FBQyxHQUFnQyxPQUFPLENBQUMsSUFBSSxDQUFDLENBQUM7Q0FBQyxDQUFDLEVBQUU7O0NBQ3BJLFNBQVMsZUFBZSxHQUFHLENBQUM7RUFDMUIsRUFBRSxFQUFFLENBQUMsR0FBRyxJQUFJLEdBQUcsQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDLEVBQUUsTUFBTSxDQUFDOztFQUMxQyxHQUFHLENBQUMsQ0FBQztHQUNILEdBQUcsQ0FBQyxTQUFTLENBQUMsTUFBTSxFQUFFO0lBQUUsSUFBSSxFQUFFLFFBQVE7SUFBRSxLQUFLLEVBQUU7S0FBQywrRkFBK0Y7S0FBQztJQUFFLFFBQVEsRUFBRSxHQUFHO0lBQUUsV0FBVyxFQUFFLG9CQUFvQjtJQUFFLENBQUMsQ0FBQzs7R0FDdE0sS0FBSyxDQUFDLE1BQU0sR0FBRyxFQUFFLEVBQUUsRUFBRSxXQUFXLEVBQUUsSUFBSSxFQUFFLFFBQVEsQUFBUyxFQUFFLE1BQU0sRUFBRSxNQUFNLEVBQUUsQ0FBQzs7R0FDNUUsR0FBRyxDQUFDLENBQUM7SUFBQyxHQUFHLENBQUMsUUFBUSxDQUFDLE1BQU0sRUFBRSxVQUFVLENBQUMsQ0FBQztHQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQztJQUFDLEdBQUcsQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLENBQUM7R0FBQyxDQUFDO0VBQzNFLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQzs7RUFBK0QsQ0FBQztDQUMzRSxDQUFDOztDQUNELGFBQWEsQUFBTixDQUFDLE1BQU0sQ0FBQztFQUFDLEVBQUUsRUFBRSxZQUFNLEtBQUksR0FBRyxFQUFFLENBQUM7R0FBQyxFQUFFLFFBQUUsU0FBUyxHQUFFLGVBQWUsRUFBRSxDQUFDO0dBQUMsRUFBRSxFQUFFLEdBQUcsQ0FBQyxRQUFRLENBQUMsV0FBVyxDQUFDLEVBQUUsR0FBRyxDQUFDLGlCQUFpQixDQUFDLFdBQVcsRUFBRSxZQUFZLEVBQUUsZUFBUyxJQUFHLFNBQVMsR0FBRyxNQUFNLENBQUMsQ0FBQztFQUFDLENBQUM7Q0FBQyxDQUFDLEVBQUU7O0NBQzdMLFNBQVMsYUFBYSxHQUFHLENBQUM7RUFDeEIsRUFBRSxFQUFFLENBQUMsR0FBRyxJQUFJLEdBQUcsQ0FBQyxTQUFTLENBQUMsYUFBYSxDQUFDLEVBQUUsTUFBTSxDQUFDOztFQUNqRCxHQUFHLENBQUMsQ0FBQztHQUNILEdBQUcsQ0FBQyxTQUFTLENBQUMsYUFBYSxFQUFFO0lBQUUsSUFBSSxFQUFFLFlBQVk7SUFBRSxLQUFLLEVBQUU7S0FBQyx5RUFBeUU7S0FBQztJQUFFLFFBQVEsRUFBRSxHQUFHO0lBQUUsT0FBTyxFQUFFLEVBQUU7SUFBRSxRQUFRLEVBQUUsV0FBVztJQUFFLENBQUMsQ0FBQztFQUM5TCxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUM7O0VBQTZDLENBQUM7Q0FDekQsQ0FBQzs7Q0FDRCxTQUFTLFlBQVksR0FBRyxDQUFDO0VBQ3ZCLEVBQUUsRUFBRSxDQUFDLEdBQUcsSUFBSSxHQUFHLENBQUMsU0FBUyxDQUFDLGNBQWMsQ0FBQyxFQUFFLE1BQU0sQ0FBQzs7RUFDbEQsR0FBRyxDQUFDLENBQUM7R0FDSCxHQUFHLENBQUMsU0FBUyxDQUFDLGNBQWMsRUFBRSxFQUFFLElBQUksRUFBRSxRQUFRLEVBQUUsR0FBRyxFQUFFLHNDQUFzQyxFQUFFLENBQUMsQ0FBQzs7R0FDL0YsS0FBSyxDQUFDLElBQUksQUFBaUMsR0FBRztJQUFFLEVBQUUsRUFBRSxrQkFBa0I7SUFBRSxJQUFJLEVBQUUsZ0JBQWdCO0lBQUUsTUFBTSxFQUFFLGNBQWM7SUFBRSxjQUFjLEVBQUUsVUFBVTtJQUFFLE1BQU0sRUFBRSxDQUFDLEdBQUcsRUFBRSxDQUFDLFVBQVUsRUFBRSxDQUFDLEtBQUssRUFBRSxlQUFlLENBQUMsRUFBRSxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUM7SUFBRSxLQUFLLEVBQUU7S0FBRSxzQkFBc0IsRUFBRSxTQUFTO0tBQUUsdUJBQXVCLEVBQUUsQ0FBQyxVQUFVLEVBQUUsQ0FBQyxLQUFLLEVBQUUsZUFBZSxDQUFDLEVBQUUsRUFBRSxDQUFDO0tBQUUscUJBQXFCLEVBQUUsQ0FBQyxVQUFVLEVBQUUsQ0FBQyxLQUFLLEVBQUUsbUJBQW1CLENBQUMsRUFBRSxDQUFDLENBQUM7S0FBRSx3QkFBd0IsRUFBRSxJQUFJO0tBQUUsa0NBQWtDLEVBQUUsSUFBSTtLQUFFO0lBQUUsQ0FBQzs7R0FDcmQsR0FBRyxDQUFDLENBQUM7SUFBQyxHQUFHLENBQUMsUUFBUSxDQUFDLElBQUksRUFBRSxXQUFXLENBQUMsQ0FBQztHQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQztJQUFDLEdBQUcsQ0FBQyxDQUFDO0tBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsQ0FBQztJQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQzs7SUFBaUUsQ0FBQztHQUFDLENBQUM7RUFDMUosQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDOztFQUFpRSxDQUFDO0NBQzdFLENBQUM7O0NBQ0QsYUFBYSxBQUFOLENBQUMsTUFBTSxDQUFDO0VBQ2IsRUFBRSxFQUFFLFlBQU0sS0FBSSxHQUFHLEVBQUUsQ0FBQztHQUNsQixLQUFLLENBQUMsTUFBTSxHQUFHLE1BQU0sQ0FBQyxVQUFVLENBQUMsa0NBQWtDLENBQUMsQ0FBQyxPQUFPLENBQUM7O0dBQzdFLEdBQUcsQ0FBQyxDQUFDO0lBQ0gsRUFBRSxRQUFFLE1BQU0sR0FBRSxDQUFDOztLQUVYLFlBQVksRUFBRSxDQUFDOztLQUFDLGFBQWEsRUFBRSxDQUFDOztLQUNoQyxHQUFHLENBQUMsQ0FBQztNQUFDLEdBQUcsQ0FBQyxVQUFVLENBQUMsRUFBRSxNQUFNLEVBQUUsYUFBYSxFQUFFLFlBQVksRUFBRSxHQUFHLEVBQUUsQ0FBQyxDQUFDO0tBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDOztLQUEwQixDQUFDOztLQUN4RyxHQUFHLENBQUMsQ0FBQztNQUFDLEFBQUMsR0FBRyxDQUFpRCxNQUFNLEdBQUc7T0FBRSxXQUFXLEVBQUUsU0FBUztPQUFFLGVBQWUsRUFBRSxTQUFTO09BQUUsV0FBVyxFQUFFLFNBQVM7T0FBRSxtQkFBbUIsRUFBRSxHQUFHO09BQUUsbUJBQW1CLEVBQUUsR0FBRztPQUFFLGtCQUFrQixFQUFFLEdBQUc7T0FBRSxDQUFDLENBQUM7S0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUM7O0tBQWlCLENBQUM7O0tBQzdQLEVBQUUsRUFBRSxHQUFHLENBQUMsUUFBUSxDQUFDLGtCQUFrQixDQUFDLEVBQUUsR0FBRyxDQUFDLGlCQUFpQixDQUFDLGtCQUFrQixFQUFFLFlBQVksRUFBRSxTQUFTLENBQUMsQ0FBQzs7S0FDekcsR0FBRyxDQUFDLE1BQU0sQ0FBQztNQUFFLEtBQUssRUFBRSxFQUFFO01BQUUsSUFBSSxFQUFFLElBQUksQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLE9BQU8sRUFBRSxFQUFFLEVBQUUsQ0FBQztNQUFFLFFBQVEsRUFBRSxNQUFNLEdBQUcsQ0FBQyxHQUFHLEdBQUc7TUFBRSxDQUFDLENBQUM7SUFDM0YsQ0FBQyxNQUFNLENBQUM7S0FDTixHQUFHLENBQUMsQ0FBQztNQUFDLEdBQUcsQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLENBQUM7S0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUM7O0tBQTBCLENBQUM7O0tBQ2hFLEdBQUcsQ0FBQyxDQUFDO01BQUMsQUFBQyxHQUFHLENBQStDLE1BQU0sR0FBRyxJQUFJLENBQVUsQ0FBQztLQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQzs7S0FBdUIsQ0FBQzs7S0FDbkgsRUFBRSxFQUFFLEdBQUcsQ0FBQyxRQUFRLENBQUMsa0JBQWtCLENBQUMsRUFBRSxHQUFHLENBQUMsaUJBQWlCLENBQUMsa0JBQWtCLEVBQUUsWUFBWSxFQUFFLE1BQU0sQ0FBQyxDQUFDOztLQUN0RyxLQUFLLENBQUMsSUFBSSxHQUFHLENBQUMsaUJBQVcsRUFBQzs7S0FDMUIsR0FBRyxDQUFDLE1BQU0sQ0FBQztNQUFFLEtBQUssRUFBRSxpQkFBVyxJQUFHLEVBQUUsR0FBRyxDQUFDO01BQUUsSUFBSSxFQUFFLElBQUksR0FBRyxHQUFHLENBQUMsT0FBTyxFQUFFLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsT0FBTyxFQUFFLEVBQUUsSUFBSSxDQUFDO01BQUUsT0FBTyxFQUFFLElBQUksR0FBRyxDQUFDLEdBQUcsR0FBRyxDQUFDLFVBQVUsRUFBRTtNQUFFLFFBQVEsRUFBRSxNQUFNLEdBQUcsQ0FBQyxHQUFHLEdBQUc7TUFBRSxDQUFDLENBQUM7SUFDNUssQ0FBQzs7SUFDRCxHQUFHLENBQUMsaUJBQWlCLENBQUMsV0FBVyxFQUFFLFlBQVksRUFBRSxBQUFDLENBQUMsaUJBQVcsS0FBSSxDQUFDLFlBQU0sSUFBSSxNQUFNLEdBQUcsU0FBUyxDQUFDLENBQUM7O0lBQ2pHLEtBQUssQ0FBQyxHQUFHLEdBQUcsQUFBQyxDQUFDLGlCQUFXLEtBQUksQ0FBQyxZQUFNLElBQUksU0FBUyxHQUFHLE1BQU0sQ0FBQzs7SUFDM0QsR0FBRyxFQUFFLEtBQUssQ0FBQyxLQUFLLElBQUksQ0FBQyxRQUFRLEVBQUUsVUFBVSxDQUFDLEVBQUUsR0FBRyxDQUFDLGlCQUFpQixDQUFDLEtBQUssRUFBRSxZQUFZLEVBQUUsR0FBRyxDQUFDLENBQUM7O0lBQzVGLEdBQUcsQ0FBQyxpQkFBaUIsQ0FBQyxpQkFBaUIsRUFBRSxZQUFZLEVBQUUsQUFBQyxDQUFDLGlCQUFXLEtBQUksQ0FBQyxZQUFNLElBQUksU0FBUyxHQUFHLE1BQU0sQ0FBQyxDQUFDO0dBQ3pHLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQzs7R0FBd0MsQ0FBQztFQUNwRCxDQUFDO0NBQ0gsQ0FBQyxFQUFFOztDQUNILE9BQU8sQ0FBQyxNQUFNLENBQUM7RUFDYixHQUFHLENBQUMsUUFBUSxHQUFHLEtBQUssQ0FBQzs7RUFDckIsS0FBSyxDQUFDLFlBQVksR0FBRyxNQUFNLENBQUMsVUFBVTtHQUFDLE1BQU0sQ0FBQztJQUFDLEVBQUUsRUFBRSxDQUFDLFFBQVEsSUFBSSxDQUFDLGtCQUFZLEtBQUksQ0FBQyxjQUFRLEdBQUUsWUFBWSxDQUFDLHVFQUF1RSxDQUFDLENBQUM7R0FBQyxDQUFDO0dBQUUsSUFBSTtHQUFDLENBQUM7O0VBQzVMLEdBQUcsQ0FBQyxDQUFDO0dBQ0gsS0FBSyxDQUFDLEtBQUssR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLGNBQWMsQ0FBQyxPQUFPLENBQUMsaUJBQWlCLENBQUMsSUFBSSxNQUFNLENBQUMsQ0FBQzs7R0FDOUUsRUFBRSxFQUFFLEtBQUssSUFBSSxLQUFLLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsb0JBQUksS0FBSyxDQUFDLE1BQU0sQ0FBQyxNQUFNLEVBQUssQ0FBQyxLQUFJLEtBQUssQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsSUFBSSxJQUFJLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxHQUFHLElBQUksSUFBSSxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksRUFBRSxJQUFJLE1BQU0sQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUM7SUFDbk47S0FBQSxNQUFNO0tBQUc7TUFBRSxHQUFHLEVBQUUsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7TUFBRSxHQUFHLEVBQUUsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7TUFBRSxJQUFJLEVBQUUsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQUUsSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLEVBQUUsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDO01BQUUsT0FBTyxFQUFFLE1BQU0sQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxHQUFHLEtBQUssQ0FBQyxPQUFPLEdBQUcsQ0FBQztNQUFFOztNQUFDOztJQUNsSyxXQUFLLEVBQUcsTUFBTSxDQUFDLElBQUksQ0FBQyxFQUFDLHFCQUFJLENBQUMsQ0FBQyxFQUFFLEVBQUssS0FBSyxDQUFDLEtBQUssRUFBQyxHQUFHLEtBQUssQ0FBQyxLQUFLLEdBQUcsS0FBSyxRQUFDO0lBQ3JFLFVBQUksRUFBRyxDQUFDLEtBQUssRUFBRSxPQUFPLEVBQUUsUUFBUSxFQUFFLEtBQUssQ0FBQyxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLEdBQUcsS0FBSyxDQUFDLElBQUksR0FBRyxLQUFLLFFBQUM7SUFDbkYsV0FBSyxFQUFHLHNCQUFNLENBQUMsS0FBSyxDQUFDLEtBQUssRUFBSyxRQUFRLElBQUcsS0FBSyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxHQUFHLEVBQUUsUUFBQztJQUN6RSxnQkFBVSxFQUFHLHNCQUFNLENBQUMsS0FBSyxDQUFDLFVBQVUsRUFBSyxRQUFRLElBQUcsS0FBSyxDQUFDLFVBQVUsR0FBRyxFQUFFLFFBQUM7SUFDMUUsbUJBQWEsRUFBRyxzQkFBTSxDQUFDLEtBQUssQ0FBQyxhQUFhLEVBQUssUUFBUSxJQUFHLEtBQUssQ0FBQyxhQUFhLEdBQUcsU0FBUyxRQUFDO0lBQzFGLGVBQVMsa0JBQUcsS0FBSyxDQUFDLFNBQVMsRUFBSyxJQUFJLEdBQUM7SUFBQyxpQkFBVyxrQkFBRyxLQUFLLENBQUMsV0FBVyxFQUFLLElBQUksR0FBQztJQUFDLFlBQU0sRUFBRyxxQkFBSyxDQUFDLE1BQU0sRUFBSyxJQUFJLHFCQUFJLEtBQUssQ0FBQyxXQUFXLEVBQUssSUFBSSxnQkFBQztHQUMvSSxDQUFDO0VBQ0gsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDOztFQUEyRCxDQUFDOztFQUNyRSxLQUFLLENBQUMsUUFBUSxHQUFHLEdBQUcsQ0FBQyxjQUFjLENBQUMsUUFBTyxLQUFJLENBQUM7R0FBQyxXQUFLLEVBQUcsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxLQUFLLFFBQUM7R0FBQyxZQUFNLEVBQUcsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxNQUFNLFFBQUM7R0FBQyxHQUFHLEVBQUUsTUFBTSxFQUFFLENBQUM7RUFBQyxDQUFDLENBQUMsQ0FBQzs7RUFDakosUUFBUSxDQUFDLE9BQU8sQ0FBQyxTQUFTLENBQUMsQ0FBQzs7RUFDNUIsU0FBUyxVQUFVLEdBQUcsQ0FBQztHQUFDLEVBQUUsRUFBRSxRQUFRLENBQUMsTUFBTSxFQUFFLEdBQUcsRUFBRSxJQUFJLEVBQUUsQ0FBQyxNQUFNLEdBQUcsRUFBRSxNQUFNLEVBQUUsQ0FBQztFQUFDLENBQUM7O0VBQy9FLFFBQVEsQ0FBQyxnQkFBZ0IsQ0FBQyxrQkFBa0IsRUFBRSxVQUFVLENBQUMsQ0FBQzs7RUFDMUQsT0FBTyxDQUFDLEdBQUcsQ0FBQztHQUFDLE1BQU0sQ0FBQyxhQUFhLENBQUM7R0FBRSxNQUFNLENBQUMsb0RBQW9ELENBQUM7R0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxFQUFFLEVBQUUsTUFBTSxDQUFDLEtBQUssQ0FBQztHQUN6SCxFQUFFLEVBQUUsUUFBUSxVQUFJLFFBQVEsR0FBRSxNQUFNLENBQUM7O0dBQ2pDLEdBQUcsQ0FBQyxDQUFDOztJQUVILEVBQUUsQ0FBQyxZQUFZLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxDQUFDOztJQUNoQyxHQUFHLEdBQUcsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLENBQUM7S0FBRSxTQUFTO0tBQUUsTUFBTSxFQUFFLENBQUMsWUFBTSxFQUFDLEdBQUcsRUFBRSxZQUFNLEVBQUMsR0FBRyxDQUFDO0tBQUUsSUFBSSxFQUFFLFlBQU0sRUFBQyxJQUFJO0tBQUUsT0FBTyxFQUFFLFlBQU0sRUFBQyxPQUFPO0tBQUUsUUFBUSxFQUFFLEVBQUU7S0FBRSxZQUFZLEVBQUUsR0FBRztLQUFFLGdCQUFnQixFQUFFLEVBQUU7S0FBRSxLQUFLLEVBQUU7TUFDeEssT0FBTyxFQUFFLENBQUM7TUFBRSxPQUFPLEVBQUU7T0FDbkIsR0FBRyxFQUFFO1FBQUUsSUFBSSxFQUFFLFFBQVE7UUFBRSxLQUFLLEVBQUUsQ0FBQyxnREFBZ0QsQ0FBQztRQUFFLFFBQVEsRUFBRSxHQUFHO1FBQUUsV0FBVyxFQUFFLDhCQUE4QjtRQUFFO09BQy9JO01BQUUsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFLEVBQUUsS0FBSyxFQUFFLElBQUksRUFBRSxRQUFRLEVBQUUsTUFBTSxFQUFFLEtBQUssRUFBRSxDQUFDO01BQzFEO0tBQUUsQ0FBQyxDQUFDOztJQUNMLEdBQUcsQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxpQkFBaUIsQ0FBQyxFQUFFLGNBQWMsRUFBRSxJQUFJLEVBQUUsV0FBVyxFQUFFLElBQUksRUFBRSxDQUFDLEVBQUUsV0FBVyxDQUFDLENBQUM7O0lBQ25HLEdBQUcsQ0FBQyxFQUFFLENBQUMsa0JBQWtCLEVBQUUsTUFBTSxDQUFDO0tBQUMsRUFBRSxFQUFFLENBQUMsUUFBUSxFQUFFLFlBQVksQ0FBQyxxREFBcUQsQ0FBQyxDQUFDO0lBQUMsQ0FBQyxDQUFDLENBQUM7O0lBQzFILEdBQUcsQ0FBQyxFQUFFLENBQUMsT0FBTyxFQUFFLE1BQU0sQ0FBQztLQUFDLGFBQU8sRUFBRywrRUFBK0UsRUFBQztJQUFDLENBQUMsQ0FBQyxDQUFDOztJQUN0SCxHQUFHLENBQUMsRUFBRSxDQUFDLFNBQVMsRUFBRSxNQUFNLENBQUM7S0FBQyxFQUFFLEVBQUUsR0FBRyxFQUFFLENBQUM7TUFBQyxLQUFLLENBQUMsQ0FBQyxHQUFHLEdBQUcsQ0FBQyxTQUFTLEVBQUUsQ0FBQzs7TUFBQztPQUFBLE1BQU07T0FBRztRQUFFLEdBQUcsRUFBRSxDQUFDLENBQUMsR0FBRztRQUFFLEdBQUcsRUFBRSxDQUFDLENBQUMsR0FBRztRQUFFLElBQUksRUFBRSxHQUFHLENBQUMsT0FBTyxFQUFFO1FBQUUsT0FBTyxFQUFFLEdBQUcsQ0FBQyxVQUFVLEVBQUU7UUFBRTs7UUFBQztLQUFDLENBQUM7SUFBQyxDQUFDLENBQUMsQ0FBQzs7SUFDMUosR0FBRyxDQUFDLEVBQUUsQ0FBQyxZQUFZLEVBQUUsRUFBQyxLQUFJLENBQUM7S0FBQyxFQUFFLEVBQUUsaUJBQUMsQ0FBQyxRQUFRLEVBQUssV0FBVyxLQUFJLENBQUMsQ0FBQyxjQUFjLEVBQUUsQ0FBQztNQUFDLGtCQUFZLEVBQUcsSUFBSSxFQUFDO01BQUMsTUFBTSxDQUFDLFlBQVksQ0FBQyxZQUFZLENBQUMsQ0FBQztLQUFDLENBQUM7SUFBQyxDQUFDLENBQUMsQ0FBQzs7SUFDL0ksR0FBRyxDQUFDLEVBQUUsQ0FBQyxZQUFZLEVBQUUsTUFBTSxDQUFDO0tBQzFCLEVBQUUsRUFBRSxDQUFDLEdBQUcsSUFBSSxRQUFRLEVBQUUsTUFBTSxDQUFDOztLQUM3QixHQUFHLENBQUMsU0FBUyxDQUFDLFdBQVcsRUFBRTtNQUFFLElBQUksRUFBRSxTQUFTO01BQUUsSUFBSSxRQUFFLE9BQU87TUFBRSxPQUFPLEVBQUUsSUFBSTtNQUFFLGNBQWMsRUFBRSxFQUFFO01BQUUsYUFBYSxFQUFFLEVBQUU7TUFBRSxDQUFDLENBQUM7O0tBQ3JILEdBQUcsQ0FBQyxTQUFTLENBQUMsWUFBWSxFQUFFLEVBQUUsSUFBSSxFQUFFLFNBQVMsRUFBRSxJQUFJLFFBQUUsVUFBVSxHQUFFLENBQUMsQ0FBQzs7S0FDbkUsR0FBRyxDQUFDLFFBQVEsQ0FBQztNQUFFLEVBQUUsRUFBRSxpQkFBaUI7TUFBRSxJQUFJLEVBQUUsTUFBTTtNQUFFLE1BQU0sRUFBRSxZQUFZO01BQUUsTUFBTSxFQUFDLENBQUMsSUFBSSxFQUFDLENBQUMsS0FBSyxFQUFDLHNCQUFzQixDQUFDLEVBQUMsS0FBSyxDQUFDO01BQUUsS0FBSyxFQUFFLEVBQUUsWUFBWSxFQUFFLENBQUMsS0FBSyxFQUFFLE9BQU8sQ0FBQyxFQUFFLGNBQWMsRUFBRSxJQUFJLEVBQUU7TUFBRSxDQUFDLENBQUM7O0tBQ2pNLEdBQUcsQ0FBQyxRQUFRLENBQUM7TUFBRSxFQUFFLEVBQUUsV0FBVztNQUFFLElBQUksRUFBRSxnQkFBZ0I7TUFBRSxNQUFNLEVBQUUsWUFBWTtNQUFFLE1BQU0sRUFBRSxFQUFFLFVBQVUsRUFBRSxpQkFBVyxJQUFHLFNBQVMsR0FBRyxNQUFNLEVBQUU7TUFBRSxLQUFLLEVBQUU7T0FBRSxzQkFBc0IsRUFBRSxDQUFDLEtBQUssRUFBRSxPQUFPLENBQUM7T0FBRSx1QkFBdUIsRUFBRSxDQUFDLEtBQUssRUFBRSxRQUFRLENBQUM7T0FBRSx3QkFBd0IsRUFBRSxHQUFHO09BQUUsa0NBQWtDLEVBQUMsSUFBSTtPQUFFO01BQUUsQ0FBQyxDQUFDOztLQUNuVCxHQUFHLENBQUMsUUFBUSxDQUFDO01BQUUsRUFBRSxFQUFFLFVBQVU7TUFBRSxJQUFJLEVBQUUsUUFBUTtNQUFFLE1BQU0sRUFBRSxXQUFXO01BQUUsTUFBTSxFQUFFLENBQUMsS0FBSyxFQUFFLGFBQWEsQ0FBQztNQUFFLEtBQUssRUFBRTtPQUFFLGNBQWMsRUFBRSxTQUFTO09BQUUsZUFBZSxFQUFFLENBQUMsTUFBTSxFQUFFLENBQUMsS0FBSyxFQUFFLGFBQWEsQ0FBQyxFQUFFLEVBQUUsRUFBRSxFQUFFLEVBQUUsRUFBRSxDQUFDO09BQUUscUJBQXFCLEVBQUUsTUFBTTtPQUFFLHFCQUFxQixFQUFFLENBQUM7T0FBRTtNQUFFLENBQUMsQ0FBQzs7S0FDcFEsR0FBRyxDQUFDLFFBQVEsQ0FBQztNQUFFLEVBQUUsRUFBRSxRQUFRO01BQUUsSUFBSSxFQUFFLFFBQVE7TUFBRSxNQUFNLEVBQUUsV0FBVztNQUFFLE1BQU0sRUFBRSxDQUFDLEdBQUcsRUFBRSxDQUFDLEtBQUssRUFBRSxhQUFhLENBQUMsQ0FBQztNQUFFLEtBQUssRUFBRTtPQUFFLGNBQWMsRUFBRSxDQUFDLEtBQUssRUFBRSxPQUFPLENBQUM7T0FBRSxlQUFlLEVBQUUsQ0FBQztPQUFFLHFCQUFxQixFQUFFLE1BQU07T0FBRSxxQkFBcUIsRUFBRSxDQUFDO09BQUU7TUFBRSxDQUFDLENBQUM7O0tBQ3JPLEdBQUcsRUFBRSxLQUFLLENBQUMsS0FBSyxJQUFJLENBQUMsUUFBUSxFQUFFLGlCQUFpQixFQUFFLFdBQVcsQ0FBQyxFQUFFLENBQUM7TUFDL0QsR0FBRyxDQUFDLEVBQUUsQ0FBQyxPQUFPLEVBQUUsS0FBSyxFQUFFLEVBQUMsS0FBSSxDQUFDO09BQUMsS0FBSyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsUUFBUSxHQUFHLENBQUMsQ0FBQyxFQUFFLFVBQVUsQ0FBQzs7T0FBQyxFQUFFLGtCQUFFLE1BQU0sQ0FBQyxDQUFDLEVBQUUsRUFBRSxFQUFLLFFBQVEsR0FBRSxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUM7TUFBQyxDQUFDLENBQUMsQ0FBQzs7TUFDaEksR0FBRyxDQUFDLEVBQUUsQ0FBQyxZQUFZLEVBQUUsS0FBSyxFQUFFLE1BQU0sQ0FBQztPQUFDLEVBQUUsRUFBRSxHQUFHLEVBQUUsR0FBRyxDQUFDLFNBQVMsRUFBRSxDQUFDLEtBQUssQ0FBQyxNQUFNLEdBQUcsU0FBUyxDQUFDO01BQUMsQ0FBQyxDQUFDLENBQUM7O01BQzFGLEdBQUcsQ0FBQyxFQUFFLENBQUMsWUFBWSxFQUFFLEtBQUssRUFBRSxNQUFNLENBQUM7T0FBQyxFQUFFLEVBQUUsR0FBRyxFQUFFLEdBQUcsQ0FBQyxTQUFTLEVBQUUsQ0FBQyxLQUFLLENBQUMsTUFBTSxHQUFHLEVBQUUsQ0FBQztNQUFDLENBQUMsQ0FBQyxDQUFDO0tBQ3JGLENBQUM7O0tBQ0QsR0FBRyxDQUFDLEVBQUUsQ0FBQyxPQUFPLEVBQUUsVUFBVSxFQUFFLE9BQU0sQ0FBQyxLQUFJLENBQUM7TUFDdEMsS0FBSyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsUUFBUSxHQUFHLENBQUMsQ0FBQyxDQUFDO01BQUMsS0FBSyxDQUFDLE1BQU0sR0FBRyxHQUFHLENBQUM7O01BQUMsRUFBRSxFQUFFLENBQUMsTUFBTSxJQUFJLENBQUMsQ0FBQyxvQkFBSSxDQUFDLENBQUMsUUFBUSxDQUFDLElBQUksRUFBSyxPQUFPLFVBQUUsTUFBTSxDQUFDOztNQUN4RyxHQUFHLENBQUMsQ0FBQztPQUFDLEtBQUssQ0FBQyxJQUFJLEdBQUcsTUFBSyx5QkFBQyxBQUFDLE1BQU0sQ0FBQyxTQUFTLENBQUMsV0FBVyxDQUFDLENBQW1CLHVCQUF1QixDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDLFVBQVUsQ0FBQyxDQUFDLHFEQUFDOztPQUFDLEVBQUUsRUFBRSxDQUFDLFFBQVEsb0JBQUksR0FBRyxFQUFLLE1BQU0sR0FBRSxNQUFNLENBQUMsTUFBTSxDQUFDLEVBQUUsTUFBTSxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsV0FBVyxBQUFvQixFQUFFLElBQUksRUFBRSxDQUFDLENBQUM7TUFBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUM7O01BQWlELENBQUM7S0FDL1MsQ0FBQyxDQUFDLENBQUM7O0tBQ0gsWUFBTSxFQUFHLElBQUksRUFBQztJQUNoQixDQUFDLENBQUMsQ0FBQztHQUNMLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQztJQUFDLFlBQVksQ0FBQyxxREFBcUQsQ0FBQyxDQUFDO0dBQUMsQ0FBQztFQUNsRixDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDO0dBQUMsRUFBRSxFQUFFLENBQUMsUUFBUSxFQUFFLFlBQVksQ0FBQyx3REFBd0QsQ0FBQyxDQUFDO0VBQUMsQ0FBQyxDQUFDLENBQUM7O0VBQzNHLE1BQU0sQ0FBQyxNQUFNLENBQUM7R0FDWixHQUFHLENBQUMsQ0FBQztJQUFDLGNBQWMsQ0FBQyxPQUFPLENBQUMsaUJBQWlCLEVBQUUsSUFBSSxDQUFDLFNBQVMsQ0FBQztLQUFFLE1BQU0sRUFBRTtNQUFDLFlBQU0sdURBQUMsR0FBRztNQUFFLFlBQU0sRUFBQyxHQUFHO01BQUM7S0FBRSxJQUFJLEVBQUUsWUFBTSxFQUFDLElBQUk7S0FBRSxPQUFPLEVBQUUsWUFBTSxFQUFDLE9BQU87S0FBRSxLQUFLLFFBQUwsS0FBSztLQUFFLElBQUksUUFBSixJQUFJO0tBQUUsS0FBSyxRQUFMLEtBQUs7S0FBRSxVQUFVLFFBQVYsVUFBVTtLQUFFLGFBQWEsUUFBYixhQUFhO0tBQUUsU0FBUyxRQUFULFNBQVM7S0FBRSxXQUFXLFFBQVgsV0FBVztLQUFFLE1BQU0sUUFBTixNQUFNO0tBQUUsQ0FBQyxDQUFDLENBQUM7R0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUM7O0dBQXNELENBQUM7O0dBQ2xTLFFBQVEsR0FBRyxJQUFJLENBQUM7R0FBQyxRQUFRLENBQUMsVUFBVSxFQUFFLENBQUM7R0FBQyxRQUFRLENBQUMsbUJBQW1CLENBQUMsa0JBQWtCLEVBQUUsVUFBVSxDQUFDLENBQUM7R0FBQyxZQUFNLEVBQUcsS0FBSyxFQUFDO0dBQUMsR0FBRyxFQUFFLElBQUksRUFBRSxDQUFDO0dBQUMsR0FBRyxFQUFFLE1BQU0sRUFBRSxDQUFDO0dBQUMsR0FBRyxHQUFHLFNBQVMsQ0FBQztHQUNsSyxNQUFNLENBQUMsWUFBWSxDQUFDLFlBQVksQ0FBQyxDQUFDO0VBQ3BDLENBQUMsQ0FBQztDQUNKLENBQUMsQ0FBQyxDQUFDOzs7S0FFSixPQUFPO0tBQ0wsR0FBRyxXQURMLE9BQU87S0FFSCxLQUFJLEFBQUQsV0FETCxHQUFHOzthQUNELEtBQUksQUFBRCxlQUFZLFNBQVMsa0JBQVQsU0FBUzs7S0FDeEIsS0FBSSxBQUFELGFBREgsS0FBSSxBQUFEO0tBRUQsTUFBTSxXQURSLEtBQUksQUFBRDt5QkFDRCxNQUFNO0tBQ04sS0FBSyxhQURMLE1BQU07O3lCQUNOLEtBQUs7O0tBQ0wsUUFBTyxBQUFELGFBRE4sS0FBSztLQUNxRCxNQUFNLFdBQWhFLFFBQU8sQUFBRDs7Q0FBb0QsTUFBTSxTQUFOLE1BQU07O0tBQXFDLFFBQU8sQUFBRCxhQUFqRCxNQUFNOztDQUFxQyxRQUFPLEFBQUQsU0FBTixRQUFPLEFBQUQ7O0tBQWdDLFFBQU8sQUFBRCxhQUE1QyxRQUFPLEFBQUQ7O0NBQWdDLFFBQU8sQUFBRCxTQUFOLFFBQU8sQUFBRDs7S0FBZ0MsUUFBTyxBQUFELGFBQTVDLFFBQU8sQUFBRDs7Q0FBZ0MsUUFBTyxBQUFELFNBQU4sUUFBTyxBQUFEO1NBQXZMLFFBQU8sQUFBRDtlQUFOLFFBQU8sQUFBRDs7S0FDTixLQUFJLEFBQUQsYUFESCxRQUFPLEFBQUQ7S0FDdUMsUUFBTyxBQUFELFdBQW5ELEtBQUksQUFBRDtLQUF3SSxRQUFPLEFBQUQsYUFBcEcsUUFBTyxBQUFEOztTQUFuRCxLQUFJLEFBQUQ7O0tBQ0gsS0FBSSxBQUFELGFBREgsS0FBSSxBQUFEO0tBQ21ELFFBQU8sQUFBRCxXQUE1RCxLQUFJLEFBQUQ7S0FBNk0sUUFBTyxBQUFELGFBQWhLLFFBQU8sQUFBRDtLQUFpVSxRQUFPLEFBQUQsYUFBbkwsUUFBTyxBQUFEOztTQUF0TixLQUFJLEFBQUQ7O0tBQ0gsS0FBSSxBQUFELGFBREgsS0FBSSxBQUFEOzhCQUNILEtBQUksQUFBRDs7OytCQUF5RSxNQUFNLHNCQUFJLENBQUM7T0FBRSxRQUFPLEFBQUQ7NkJBQU4sUUFBTyxBQUFEOzs7b0JBQU4sUUFBTyxBQUFELHdDQUFlLEtBQUssR0FBSyxPQUFDLEVBQUMsRUFBRTt1QkFBZ0MsT0FBQyxFQUFDLEtBQUs7Ozt3QkFBMUUsUUFBTyxBQUFEO2lCQUE4QyxLQUFLLEVBQUcsT0FBQyxFQUFDLEVBQUU7OztzQkFBaEUsUUFBTyxBQUFEOzs7Ozs7OztTQUEvRixLQUFJLEFBQUQ7U0FOTCxLQUFJLEFBQUQ7O3dCQUFILEtBQUksQUFBRDs7OztPQVNELEtBQUksQUFBRDs7d0JBQUgsS0FBSSxBQUFEOzs7eUNBQ0ssS0FBSyxJQUFJLElBQUksS0FBRSxJQUFJLENBQUMsR0FBRyxhQUFkLElBQUk7U0FBYSxHQUFHOzs7O3NCQUFILEdBQUcsU0FBbUIsVUFBSSxFQUFDLEdBQUc7OzZCQUE5QixHQUFHO2dCQUEwRSxVQUFJLEVBQUMsQ0FBQztlQUFpQixVQUFJLEVBQUMsQ0FBQzs7Ozt3QkFBMUcsR0FBRzs7Ozs7Ozs7Ozs7eUNBQzdCLGNBQWMsSUFBSSxLQUFLLEtBQUUsS0FBSyxDQUFDLEVBQUUsYUFBZixLQUFLO1NBQWEsUUFBTyxBQUFEOzs7O3NCQUFOLFFBQU8sQUFBRCxnQkFBb0gsR0FBRyxXQUFLLEVBQUMsSUFBSSxLQUFLLFdBQUssRUFBQyxLQUFLLEVBQUU7c0JBQXpKLFFBQU8sQUFBRCxXQUE0SixHQUFHLFdBQUssRUFBQyxJQUFJLEtBQUssV0FBSyxFQUFDLEtBQUssRUFBRTs7NkJBQWpNLFFBQU8sQUFBRDtnQkFBcUMsV0FBSyxFQUFDLENBQUM7ZUFBaUIsV0FBSyxFQUFDLENBQUM7bUJBQXVCLFdBQUssRUFBQyxLQUFLOzs7OzBCQUE1RyxRQUFPLEFBQUQ7YUFBNE0sTUFBTSxDQUFDLFdBQUssRUFBQyxFQUFFLENBQUM7Ozt3QkFBbE8sUUFBTyxBQUFEOzs7Ozs7OztPQUNoRCxHQUFHO09BQTJELFFBQU8sQUFBRCxXQUFwRSxHQUFHO09BQW1JLFFBQU8sQUFBRCxhQUE5RSxRQUFPLEFBQUQ7T0FBeUksU0FBTyxBQUFELGFBQTdFLFFBQU8sQUFBRDtPQUFzSSxTQUFPLEFBQUQsYUFBM0UsU0FBTyxBQUFEO09BQW9JLFNBQU8sQUFBRCxhQUEzRSxTQUFPLEFBQUQ7T0FBb0ksU0FBTyxBQUFELGFBQTNFLFNBQU8sQUFBRDs7V0FBN1YsR0FBRzs7V0FITCxLQUFJLEFBQUQ7Z0RBQUgsS0FBSSxBQUFELGlDQUFxQyxNQUFNOzt3QkFHa0IsUUFBTyxBQUFEO1dBQXdDLFVBQVUsQ0FBQyxDQUFDLENBQUM7Ozt3QkFBYSxRQUFPLEFBQUQ7V0FBc0MsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDOzs7d0JBQWEsU0FBTyxBQUFEO1dBQXNDLEdBQUcsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxHQUFHLENBQUM7Ozt3QkFBYSxTQUFPLEFBQUQ7V0FBc0MsR0FBRyxDQUFDLENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBQzs7O3dCQUFhLFNBQU8sQUFBRDtXQUF1QyxHQUFHLENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBQzs7O3dCQUFhLFNBQU8sQUFBRDtXQUFtQyxHQUFHLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQzs7O3NCQUhsZCxLQUFJLEFBQUQ7Ozs7O2NBREQsUUFBUTs7Ozs7Ozs7Ozs7OztPQVFjLEdBQUUsQUFBRDs7c0JBQUQsR0FBRSxBQUFEOzs7OztRQUF2QixDQUFDLFlBQU0sS0FBSSxDQUFDLGNBQVE7Ozs7Ozs7Ozs7Ozs7T0FDWCxHQUFFLEFBQUQ7NkJBQUQsR0FBRSxBQUFEOztvREFBbUMsT0FBTztzQkFBM0MsR0FBRSxBQUFEOzs7OztjQUFWLE9BQU87Ozs7Ozs7Ozs7Ozs7T0FFVCxLQUFLO09BQ0gsS0FBSSxBQUFELFdBREwsS0FBSztPQUNzQixJQUFJLFdBQTdCLEtBQUksQUFBRDs2QkFBc0IsSUFBSTtPQUFnSSxTQUFPLEFBQUQsYUFBMUksSUFBSTs7V0FBN0IsS0FBSSxBQUFEOztPQUNILEVBQUUsYUFERixLQUFJLEFBQUQ7NkJBQ0gsRUFBRTtPQUNGLEdBQUUsQUFBRCxhQURELEVBQUU7NkJBQ0YsR0FBRSxBQUFEO09BQ0QsS0FBSSxBQUFELGFBREgsR0FBRSxBQUFEOztPQUNtRSxNQUFNLFdBQTFFLEtBQUksQUFBRDs2QkFBaUUsTUFBTTtPQUEyQixNQUFNLEFBQUYsYUFBckMsTUFBTTs2QkFBMkIsTUFBTSxBQUFGOztXQUF6RyxLQUFJLEFBQUQ7O09BQ0gsRUFBRSxhQURGLEtBQUksQUFBRDtPQUVELEtBQUssQUFBRixXQURMLEVBQUU7T0FDd0IsRUFBRSxxQkFBMUIsS0FBSyxBQUFGOzZCQUFxQixFQUFFOztXQUExQixLQUFLLEFBQUY7O09BQ0gsTUFBSyxBQUFGLGFBREgsS0FBSyxBQUFGO09BQ2MsSUFBSSxBQUFGLHFCQUFuQixNQUFLLEFBQUY7NkJBQWMsSUFBSSxBQUFGOztXQUFuQixNQUFLLEFBQUY7O09BQ0gsTUFBSyxBQUFGLGFBREgsTUFBSyxBQUFGO09BQ21CLElBQUksQUFBRixxQkFBeEIsTUFBSyxBQUFGOzhCQUFtQixJQUFJLEFBQUY7O1dBQXhCLE1BQUssQUFBRjs7T0FDSCxNQUFLLEFBQUYsYUFESCxNQUFLLEFBQUY7T0FDb0IsSUFBSSxBQUFGLHFCQUF6QixNQUFLLEFBQUY7OEJBQW9CLElBQUksQUFBRjs7V0FBekIsTUFBSyxBQUFGOztPQUNILE1BQUssQUFBRixhQURILE1BQUssQUFBRjtPQUNxQixJQUFJLEFBQUYscUJBQTFCLE1BQUssQUFBRjs4QkFBcUIsSUFBSSxBQUFGOztXQUExQixNQUFLLEFBQUY7V0FMTCxFQUFFOztPQU9GLEdBQUUsQUFBRCxhQVBELEVBQUU7T0FPa0IsTUFBSyxBQUFELFdBQXhCLEdBQUUsQUFBRDs7MkJBQW1CLE1BQUssQUFBRDs7V0FBeEIsR0FBRSxBQUFEOzswQkFBRCxHQUFFLEFBQUQ7Ozs7U0FFRCxNQUFJLEFBQUQ7U0FDRCxRQUFRLEFBQUYsV0FEUixNQUFJLEFBQUQ7Z0NBQ0QsUUFBUSxBQUFGO1NBQ04sSUFBRyxBQUFELGFBREYsUUFBUSxBQUFGO1NBRUosTUFBSyxBQUFGLFdBREwsSUFBRyxBQUFEO1NBQ29CLElBQUksQUFBRixxQkFBdEIsTUFBSyxBQUFGO2dDQUFpQixJQUFJLEFBQUY7O2FBQXRCLE1BQUssQUFBRjs7U0FDSCxNQUFLLEFBQUYsYUFESCxNQUFLLEFBQUY7U0FDaUIsSUFBSSxBQUFGLHFCQUF0QixNQUFLLEFBQUY7Z0NBQWlCLElBQUksQUFBRjs7YUFBdEIsTUFBSyxBQUFGOztTQUNILE1BQUssQUFBRixhQURILE1BQUssQUFBRjtTQUNtQixJQUFJLEFBQUYscUJBQXhCLE1BQUssQUFBRjtnQ0FBbUIsSUFBSSxBQUFGOzthQUF4QixNQUFLLEFBQUY7YUFITCxJQUFHLEFBQUQ7O1NBS0YsU0FBTyxBQUFELGFBTE4sSUFBRyxBQUFEOzthQUZKLE1BQUksQUFBRDs7OzBCQUNPLGlCQUFXLEVBQUMsVUFBVSxDQUFDLG9CQUFvQixJQUFJLGlCQUFXLEVBQUMsVUFBVSxDQUFDLGlCQUFpQixHQUFHLHFCQUFxQixHQUFHLGVBQWU7NkJBRS9HLGlCQUFXLEVBQUMsVUFBVSxDQUFDLE1BQU0sV0FBSSxpQkFBVyxFQUFDLFVBQVUsQ0FBQyxpQkFBaUIsR0FBRyxhQUFhLEdBQUcsZUFBZTswQkFDM0csaUJBQVcsRUFBQyxVQUFVLENBQUMsb0JBQW9CLEdBQUcsaUJBQWlCLEdBQUcsb0JBQW9COzBCQUNwRixrQkFBWSxHQUFFLE1BQU0sSUFBSSxzQkFBc0I7OzswQkFFMUUsU0FBTyxBQUFEO2FBQW9DLElBQUksQ0FBQyxVQUFVLENBQUM7Ozt3QkFQNUQsTUFBSSxBQUFEOzs7OztnQkFEQyxXQUFXOzs7Ozs7Ozs7Ozs7O1NBVzBILEdBQUUsQUFBRDtnQ0FBRCxHQUFFLEFBQUQ7O2lEQUF1QixpQkFBVyxFQUFDLFVBQVUsQ0FBQyxvQkFBb0I7UUFBRyxvQ0FBb0M7UUFBRyxtQ0FBbUM7O3dCQUFoSixHQUFFLEFBQUQ7Ozs7O1VBQXRJLEFBQUMsa0JBQVcsV0FBSSxNQUFNLFlBQUssV0FBVyxLQUFLLGtCQUFXLEVBQUMsVUFBVSxDQUFDLG9CQUFvQixJQUFJLGlCQUFXLEVBQUMsVUFBVSxDQUFDLGlCQUFpQixDQUFDOzs7Ozs7Ozs7T0FDdkksTUFBSSxBQUFEO09BQTBCLFNBQU8sQUFBRCxXQUFuQyxNQUFJLEFBQUQ7T0FBK0UsU0FBTyxBQUFELGFBQTNELFNBQU8sQUFBRDs7V0FBbkMsTUFBSSxBQUFEOzswQkFBSCxNQUFJLEFBQUQ7Ozs7U0FDMkIsU0FBTyxBQUFEOzswQkFBTixTQUFPLEFBQUQ7YUFBb0MsSUFBSSxDQUFDLFVBQVUsQ0FBQzs7O3dCQUExRCxTQUFPLEFBQUQ7Ozs7O2dDQUFoQyxLQUFLLEdBQUssY0FBYzs7Ozs7Ozs7Ozs7OztTQUNDLFNBQU8sQUFBRDs7MEJBQU4sU0FBTyxBQUFEO2FBQW9DLElBQUksQ0FBQyxjQUFjLENBQUM7Ozt3QkFBOUQsU0FBTyxBQUFEOzs7OztnQ0FBL0IsS0FBSyxHQUFLLGFBQWE7Ozs7Ozs7Ozs7Ozs7U0FDWCxHQUFFLEFBQUQ7Z0NBQUQsR0FBRSxBQUFEOztrRUFBcUMsZ0JBQVUsRUFBQyxNQUFNLEdBQUcsQ0FBQzt3QkFBM0QsR0FBRSxBQUFEOzs7OztnQkFBYixVQUFVOzs7Ozs7Ozs7V0E1QmhCLEtBQUs7Ozs7MkJBQ29ELGNBQVEsRUFBQyxJQUFJLEdBQUcsU0FBUyxHQUFHLEVBQUUsR0FBRSxtQkFBYSxJQUFHLGlCQUFXLGFBQWEsR0FBRSxHQUFHLGdCQUFnQjt3QkFDaEosY0FBUSxFQUFDLElBQUk7d0JBQ00sY0FBUSxFQUFDLE9BQU87NEJBQ3ZDLEtBQUksQUFBRCx1Q0FBZ0QsY0FBUSxFQUFDLEtBQUs7d0JBQVcsY0FBUSxFQUFDLEtBQUs7O3dCQUU1RCxjQUFRLEVBQUMsU0FBUzt3QkFDekIsY0FBUSxFQUFDLEdBQUcsSUFBSSxXQUFXO3lCQUN0QixjQUFRLEVBQUMsTUFBTSxJQUFJLGlCQUFpQjt5QkFDbkMsY0FBUSxFQUFDLElBQUksSUFBSSxHQUFHO3lCQUNuQixjQUFRLEVBQUMsWUFBWSxJQUFJLFlBQVk7NEJBRS9DLE1BQUssQUFBRCw4QkFBc0MsY0FBUSxFQUFDLEtBQUs7eUJBQVUsY0FBUSxFQUFDLEtBQUs7O1dBUk8sU0FBUyxDQUFDLGNBQVEsRUFBQyxJQUFJLENBQUM7Ozt3QkFIMEIsU0FBTyxBQUFEO2lCQUF3RSxVQUFVLEVBQUcsRUFBRTs7O3dCQXdCN04sU0FBTyxBQUFEO1dBQWdCLElBQUksRUFBRTs7O3dCQUF5QixTQUFPLEFBQUQsRUFBNEIsT0FBTztzQkF6QjdILEtBQUs7Ozs7O2NBREgsUUFBUTs7Ozs7Ozs7Ozs7OztPQWlDVixPQUFNLEFBQUQ7T0FDSCxNQUFJLEFBQUQsV0FETCxPQUFNLEFBQUQ7T0FDd0IsUUFBUSxBQUFGLFdBQWpDLE1BQUksQUFBRDs4QkFBd0IsUUFBUSxBQUFGO09BQXFDLFNBQU8sQUFBRCxhQUFqRCxRQUFRLEFBQUY7O1dBQWpDLE1BQUksQUFBRDs7T0FDSCxNQUFJLEFBQUQsYUFESCxNQUFJLEFBQUQ7Ozs7S0FDSCxNQUFJLEFBQUQ7O2lCQUE4QixPQUFPO01BQUksSUFBSSxLQUFFLElBQUksQ0FBQyxFQUFFO2dCQUFiLElBQUk7VUFBWSxTQUFPLEFBQUQ7O1VBQXNFLE1BQU0sQUFBRixXQUFoRixTQUFPLEFBQUQ7aUNBQXNFLE1BQU0sQUFBRjtVQUFvQixLQUFLLGFBQTdCLE1BQU0sQUFBRjtpQ0FBb0IsS0FBSzs7Y0FBekcsU0FBTyxBQUFEOzs7NkJBQU4sU0FBTyxBQUFELGdFQUFlLFVBQUksRUFBQyxFQUFFLFFBQUcsVUFBVTsyQkFBeUMsVUFBSSxFQUFDLElBQUk7MkJBQWdCLFVBQUksRUFBQyxLQUFLOzs7MkJBQXJILFNBQU8sQUFBRDtjQUFvRCxNQUFNLENBQUMsVUFBSSxFQUFDLEVBQUUsQ0FBQzs7O3lCQUF6RSxTQUFPLEFBQUQ7OztVQUF5SSxHQUFHLEFBQUY7O3lCQUFELEdBQUcsQUFBRjs7Ozs7Ozs7O1dBQTVNLE1BQUksQUFBRDtXQUZMLE9BQU0sQUFBRDs0REFDMEMsYUFBTyxFQUFDLE1BQU07O3dCQUFXLFNBQU8sQUFBRDtpQkFBMEQsUUFBUSxFQUFHLEtBQUs7OztzQkFEeEosT0FBTSxBQUFEOzs7OztjQURILFFBQVE7Ozs7Ozs7Ozs7Ozs7T0FPVixNQUFJLEFBQUQ7T0FDRCxNQUFJLEFBQUQsV0FETCxNQUFJLEFBQUQ7T0FDMkQsU0FBTyxBQUFELHFCQUFsRSxNQUFJLEFBQUQ7O1dBQUgsTUFBSSxBQUFEOztPQUNILEdBQUUsQUFBRCxhQURELE1BQUksQUFBRDs4QkFDSCxHQUFFLEFBQUQ7O1dBRkgsTUFBSSxBQUFEOztpRUFFd0Msa0JBQVUsTUFBTSxHQUFHLGVBQVMsRUFBQyxNQUFNLEtBQUksWUFBTTtNQUFHLHlKQUF5SjtNQUFHLGlCQUFXO09BQUcseUlBQXlJO09BQUcsMkNBQTJDLElBQUcsQ0FBQyxxQkFBcUIsS0FBRyxtQ0FBbUMsR0FBRyxFQUFFOzt3QkFEbGMsU0FBTyxBQUFEO2lCQUE0RCxTQUFTLEVBQUcsS0FBSzs7O3NCQURqSixNQUFJLEFBQUQ7Ozs7O2NBREQsU0FBUzs7Ozs7Ozs7O0tBTWIsTUFBSSxBQUFEO0tBQXNCLE1BQU0sQUFBRixXQUE3QixNQUFJLEFBQUQ7NEJBQXNCLE1BQU0sQUFBRjt5QkFBSixNQUFNLEFBQUY7Ozs7T0FBMEcsU0FBTyxBQUFEOzt3QkFBTixTQUFPLEFBQUQ7aUJBQThCLFVBQVUsRUFBRyxJQUFJOzs7c0JBQXJELFNBQU8sQUFBRDs7Ozs7Y0FBbEIsVUFBVTs7Ozs7Ozs7O0tBQW1GLFNBQU8sQUFBRDs7U0FBOU4sTUFBSSxBQUFEOztLQUNILE1BQUksQUFBRCxhQURILE1BQUksQUFBRDt1QkFDSCxNQUFJLEFBQUQ7Ozs7T0FDa0IsTUFBTSxBQUFGOztzQkFBSixNQUFNLEFBQUY7Ozs7O09BQzhJLE1BQU0sQUFBRjtPQUFFLENBQUMsV0FBUCxNQUFNLEFBQUY7Ozs7V0FBSixNQUFNLEFBQUY7a0RBQUUsQ0FBQyw4QkFBbUIsYUFBYTs7Ozs7O09BQ25DLE1BQU0sQUFBRjtPQUFFLEdBQUUsQUFBRCxXQUFQLE1BQU0sQUFBRjs7OztXQUFKLE1BQU0sQUFBRjtrREFBRSxHQUFFLEFBQUQsOEJBQW1CLGFBQWE7Ozs7OztPQUNoSSxNQUFNLEFBQUY7T0FBRSxHQUFFLEFBQUQsV0FBUCxNQUFNLEFBQUY7Ozs7V0FBSixNQUFNLEFBQUY7a0RBQUUsR0FBRSxBQUFELDhCQUFtQixhQUFhOzs7Ozs7OEJBSHJILEtBQUssR0FBSyxLQUFLLDJEQUNWLEtBQUssR0FBSyxPQUFPLDhEQUNqQixLQUFLLEdBQUssY0FBYzs7Ozs7Ozs7O1NBSGpDLE1BQUksQUFBRDtTQWpFTCxHQUFHO1NBREwsT0FBTzs7OzttQkFDTCxHQUFHLG9CQUFrQyxjQUFRLFdBQUksWUFBWTttQkFHekQsTUFBTSx5QkFBOEMsUUFBUTtnQ0FBaUQsYUFBTyxFQUFDLE1BQU07bUJBRzlFLFFBQU8sQUFBRCxrQkFBZSxDQUFDLGVBQVMsV0FBSSxRQUFRO0dBQW1ELFFBQU8sQUFBRCxrQkFBVyxRQUFRO21CQUF6QixRQUFPLEFBQUQsa0JBQW1DLGVBQVMsS0FBSSxDQUFDLGNBQVE7bUJBQ3BKLFFBQU8sQUFBRCxrQkFBc0QsQ0FBQyxpQkFBVyxLQUFJLENBQUMsWUFBTTtHQUF1RSxRQUFPLEFBQUQsa0JBQTRELFFBQVE7bUJBQTFFLFFBQU8sQUFBRCx3QkFBb0YsV0FBVztHQUF3RSxRQUFPLEFBQUQsa0JBQW9FLFFBQVE7bUJBQWxGLFFBQU8sQUFBRCx3QkFBNEYsTUFBTTtvQ0F5RDliLGFBQU8sRUFBQyxNQUFNO21CQUFpSyxTQUFPLEFBQUQseUJBQXNGLFNBQVM7O1NBQTNQLGVBQVMsRUFBQyxJQUFJLENBQUMsRUFBQyxLQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxTQUFTLEdBQUcsRUFBRTs7O3NCQTdENUcsTUFBTTtlQUF1RSxRQUFRLEVBQUcsQ0FBQyxjQUFROzs7O0VBQ2pHLEtBQUs7V0FBdUcsR0FBVTtnQkFBRSxLQUFLOztXQUFqQixHQUFVO1NBQUUsS0FBSzs7Ozs7RUFDN0gsUUFBTyxBQUFEO1dBQWlDLEdBQVU7Z0JBQUUsSUFBSTs7V0FBaEIsR0FBVTtTQUFFLElBQUk7Ozs7c0JBQ1YsUUFBTyxBQUFEO2VBQXNELFNBQVMsRUFBRyxLQUFLOzs7c0JBQWlCLFFBQU8sQUFBRDtlQUEwRSxTQUFTLEVBQUcsSUFBSTs7O3NCQUNyTCxRQUFPLEFBQUQscUJBQThGLENBQUM7RUFBQyxpQkFBVyxFQUFHLEtBQUssRUFBQztFQUFDLFlBQU0sRUFBRyxLQUFLLEVBQUM7Q0FBQyxDQUFDOztzQkFBYyxRQUFPLEFBQUQscUJBQWdILENBQUM7RUFBQyxpQkFBVyxFQUFHLElBQUksRUFBQztFQUFDLFlBQU0sRUFBRyxLQUFLLEVBQUM7Q0FBQyxDQUFDOztzQkFBZ0IsUUFBTyxBQUFELHFCQUFtSCxDQUFDO0VBQUMsWUFBTSxFQUFHLElBQUksRUFBQztFQUFDLGlCQUFXLEVBQUcsS0FBSyxFQUFDO0NBQUMsQ0FBQzs7c0JBeUR2VSxTQUFPLEFBQUQ7ZUFBK0MsU0FBUyxFQUFHLENBQUMsZUFBUzs7O29CQWpFdlMsT0FBTzs7O0FBREEsQ0FBQyIsIm5hbWVzIjpbXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiUmlza01hcC5zdmVsdGUiXSwic291cmNlc0NvbnRlbnQiOlsiPHNjcmlwdCBsYW5nPVwidHNcIj5cclxuICBpbXBvcnQgeyBvbk1vdW50IH0gZnJvbSAnc3ZlbHRlJztcclxuICBpbXBvcnQgdHlwZSB7IE1hcCBhcyBNYXBUeXBlLCBHZW9KU09OU291cmNlLCBGaWxsRXh0cnVzaW9uTGF5ZXJTcGVjaWZpY2F0aW9uIH0gZnJvbSAnbWFwbGlicmUtZ2wnO1xyXG4gIGltcG9ydCB0eXBlIHsgQWQsIENvbXBsZXggfSBmcm9tICcuLi9saWIvdHlwZXMnO1xyXG4gIGltcG9ydCB7IHpvbmVMYWJlbCB9IGZyb20gJy4uL2xpYi9zY29yaW5nJztcclxuICBpbXBvcnQgeyBoYXNDb29yZGluYXRlcywgc3VtbWFyaXplTWFwLCBidWlsZGluZ1NoYXBlcywgd29ybGRQb2ludCwgd29ybGRDb29yZGluYXRlcywgcmVsYXRlZE1hcFBsYWNlcywgVU5LTk9XTl9DT0xPUiwgdHlwZSBYUmF5VGhlbWUsIHR5cGUgTWFwR2VvbWV0cnksIHR5cGUgTWFwUmVsYXRpb24gfSBmcm9tICcuLi9saWIvbWFwLW1vZGVsJztcclxuICBpbXBvcnQgJ21hcGxpYnJlLWdsL2Rpc3QvbWFwbGlicmUtZ2wuY3NzJztcclxuICBsZXQgeyBjb21wbGV4ZXMsIGFkcywgZ2VvbWV0cnkgPSBbXSwgcmVsYXRpb25zID0gW10sIGxpdmVSZWdpc3RyeUF2YWlsYWJsZSA9IGZhbHNlLCBvbk9wZW5Eb3NzaWVyLCBvblNob3dSZWxhdGVkUGxhY2VzIH06IHtcclxuICAgIGNvbXBsZXhlczogQ29tcGxleFtdOyBhZHM/OiBBZFtdOyBnZW9tZXRyeT86IE1hcEdlb21ldHJ5W107IHJlbGF0aW9ucz86IE1hcFJlbGF0aW9uW107IGxpdmVSZWdpc3RyeUF2YWlsYWJsZT86IGJvb2xlYW47XHJcbiAgICBvbk9wZW5Eb3NzaWVyPzogKGNvbXBsZXhJZDogc3RyaW5nLCBwaGFzZUlkPzogc3RyaW5nKSA9PiB2b2lkOyBvblNob3dSZWxhdGVkUGxhY2VzPzogKGNvbXBsZXhJZDogc3RyaW5nKSA9PiB2b2lkO1xyXG4gIH0gPSAkcHJvcHMoKTtcclxuICBsZXQgY29udGFpbmVyOiBIVE1MRGl2RWxlbWVudDtcclxuICBsZXQgbWFwOiBNYXBUeXBlIHwgdW5kZWZpbmVkO1xyXG4gIGxldCBsb2FkZWQgPSAkc3RhdGUoZmFsc2UpO1xyXG4gIGxldCBtYXJrZXJzUmVhZHkgPSAkc3RhdGUoZmFsc2UpO1xyXG4gIGxldCBmYWxsYmFjayA9ICRzdGF0ZShmYWxzZSk7XHJcbiAgbGV0IHdhcm5pbmcgPSAkc3RhdGUoJycpO1xyXG4gIGxldCBzYXRlbGxpdGUgPSAkc3RhdGUoZmFsc2UpO1xyXG4gIGxldCBkaW1lbnNpb25hbCA9ICRzdGF0ZShmYWxzZSk7XHJcbiAgbGV0IGNpdHkzZCA9ICRzdGF0ZShmYWxzZSk7XHJcbiAgbGV0IHRoZW1lID0gJHN0YXRlPFhSYXlUaGVtZT4oJ29mZicpO1xyXG4gIGxldCBxdWVyeSA9ICRzdGF0ZSgnJyk7XHJcbiAgbGV0IHpvbmUgPSAkc3RhdGUoJ2FsbCcpO1xyXG4gIGxldCBzZWxlY3RlZElkID0gJHN0YXRlKCcnKTtcclxuICBsZXQgc2VsZWN0ZWRQaGFzZSA9ICRzdGF0ZTxzdHJpbmcgfCB1bmRlZmluZWQ+KCk7XHJcbiAgbGV0IHJlbGF0ZWRJZHMgPSAkc3RhdGU8c3RyaW5nW10gfCBudWxsPihudWxsKTtcclxuICBsZXQgY2FtZXJhID0gJHN0YXRlKHsgbG5nOiA4Mi42MTQsIGxhdDogNDkuOTg0LCB6b29tOiAxMiwgYmVhcmluZzogMCB9KTtcclxuICBsZXQgd2lkdGggPSAkc3RhdGUoODAwKTtcclxuICBsZXQgbGlzdE9wZW4gPSAkc3RhdGUoZmFsc2UpO1xyXG4gIGxldCBhYm91dE9wZW4gPSAkc3RhdGUoZmFsc2UpO1xyXG4gIGxldCBoZWlnaHQgPSAkc3RhdGUoNTIwKTtcclxuICBjb25zdCB0aGVtZXM6IHsgaWQ6IFhSYXlUaGVtZTsgdGl0bGU6IHN0cmluZyB9W10gPSBbeyBpZDogJ29mZicsIHRpdGxlOiAn0JLRi9C60LsnIH0sIHsgaWQ6ICdsZWdhbCcsIHRpdGxlOiAn0J/RgNCw0LLQvtCy0L7QuScgfSwgeyBpZDogJ2NvbnN0cnVjdGlvbicsIHRpdGxlOiAn0KHRgtGA0L7QudC60LAnIH0sIHsgaWQ6ICdhZHZlcnRpc2luZycsIHRpdGxlOiAn0KDQtdC60LvQsNC80LAnIH1dO1xyXG4gIGNvbnN0IHN1bW1hcmllcyA9ICRkZXJpdmVkKGNvbXBsZXhlcy5maWx0ZXIoaGFzQ29vcmRpbmF0ZXMpLm1hcCh6ID0+IHN1bW1hcml6ZU1hcCh6LCB0aGVtZSwgYWRzKSkpO1xyXG4gIGNvbnN0IHZpc2libGUgPSAkZGVyaXZlZChzdW1tYXJpZXMuZmlsdGVyKHogPT4gKHpvbmUgPT09ICdhbGwnIHx8IHouem9uZSA9PT0gem9uZSkgJiYgKCFyZWxhdGVkSWRzIHx8IHJlbGF0ZWRJZHMuaW5jbHVkZXMoei5pZCkpICYmIGAke3oubmFtZX0gJHt6LmFkZHJlc3N9ICR7ei5iaW4gPz8gJyd9YC50b0xvY2FsZUxvd2VyQ2FzZSgpLmluY2x1ZGVzKHF1ZXJ5LnRyaW0oKS50b0xvY2FsZUxvd2VyQ2FzZSgpKSkpO1xyXG4gIGNvbnN0IHNlbGVjdGVkID0gJGRlcml2ZWQoc3VtbWFyaWVzLmZpbmQoeiA9PiB6LmlkID09PSBzZWxlY3RlZElkKSk7XHJcbiAgY29uc3QgZ2VvanNvbiA9ICRkZXJpdmVkKHsgdHlwZTogJ0ZlYXR1cmVDb2xsZWN0aW9uJyBhcyBjb25zdCwgZmVhdHVyZXM6IHZpc2libGUubWFwKHogPT4gKHsgdHlwZTogJ0ZlYXR1cmUnIGFzIGNvbnN0LCBnZW9tZXRyeTogeyB0eXBlOiAnUG9pbnQnIGFzIGNvbnN0LCBjb29yZGluYXRlczogW3oubG5nLCB6LmxhdF0gfSwgcHJvcGVydGllczogeyBpZDogei5pZCwgY29sb3I6IHouY29sb3IgfSB9KSkgfSk7XHJcbiAgY29uc3QgZm9vdHByaW50cyA9ICRkZXJpdmVkKGJ1aWxkaW5nU2hhcGVzKHZpc2libGUsIGdlb21ldHJ5KSk7XHJcbiAgY29uc3Qgc2VsZWN0ZWRCb3ggPSAkZGVyaXZlZChmb290cHJpbnRzLmZlYXR1cmVzLmZpbmQoZj0+Zi5wcm9wZXJ0aWVzLmlkPT09c2VsZWN0ZWRJZCAmJiAoIXNlbGVjdGVkUGhhc2UgfHwgZi5wcm9wZXJ0aWVzLnBoYXNlSWQ9PT1zZWxlY3RlZFBoYXNlKSkpO1xyXG4gIGNvbnN0IHNlbGVjdGVkR2VvbSA9ICRkZXJpdmVkKGdlb21ldHJ5LmZpbmQoZyA9PiBnLmNvbXBsZXhJZD09PXNlbGVjdGVkPy5pZCAmJiAoIXNlbGVjdGVkUGhhc2UgfHwgIWcucGhhc2VJZCB8fCBnLnBoYXNlSWQ9PT1zZWxlY3RlZFBoYXNlKSkpO1xyXG4gIGNvbnN0IGNlbnRlciA9ICRkZXJpdmVkKHdvcmxkUG9pbnQoY2FtZXJhLmxuZywgY2FtZXJhLmxhdCwgTWF0aC5mbG9vcihjYW1lcmEuem9vbSkpKTtcclxuICBjb25zdCB0aWxlcyA9ICRkZXJpdmVkLmJ5KCgpID0+IHtcclxuICAgIGNvbnN0IHpvb20gPSBNYXRoLmZsb29yKGNhbWVyYS56b29tKTsgY29uc3QgY291bnQgPSAyICoqIHpvb207IGNvbnN0IHJlc3VsdCA9IFtdO1xyXG4gICAgZm9yIChsZXQgeCA9IE1hdGguZmxvb3IoKGNlbnRlclswXSAtIHdpZHRoIC8gMikgLyAyNTYpOyB4IDw9IE1hdGguZmxvb3IoKGNlbnRlclswXSArIHdpZHRoIC8gMikgLyAyNTYpOyB4KyspIHtcclxuICAgICAgZm9yIChsZXQgeSA9IE1hdGguZmxvb3IoKGNlbnRlclsxXSAtIGhlaWdodCAvIDIpIC8gMjU2KTsgeSA8PSBNYXRoLmZsb29yKChjZW50ZXJbMV0gKyBoZWlnaHQgLyAyKSAvIDI1Nik7IHkrKykge1xyXG4gICAgICAgIGlmICh5ID49IDAgJiYgeSA8IGNvdW50KSByZXN1bHQucHVzaCh7IGtleTogYCR7em9vbX0vJHt4fS8ke3l9YCwgdXJsOiBgaHR0cHM6Ly90aWxlLm9wZW5zdHJlZXRtYXAub3JnLyR7em9vbX0vJHsoKHggJSBjb3VudCkgKyBjb3VudCkgJSBjb3VudH0vJHt5fS5wbmdgLCB4OiB4ICogMjU2IC0gY2VudGVyWzBdICsgd2lkdGggLyAyLCB5OiB5ICogMjU2IC0gY2VudGVyWzFdICsgaGVpZ2h0IC8gMiB9KTtcclxuICAgICAgfVxyXG4gICAgfVxyXG4gICAgcmV0dXJuIHJlc3VsdDtcclxuICB9KTtcclxuICBjb25zdCBmYWxsYmFja1BvaW50cyA9ICRkZXJpdmVkKHZpc2libGUubWFwKHogPT4geyBjb25zdCBwID0gd29ybGRQb2ludCh6LmxuZywgei5sYXQsIE1hdGguZmxvb3IoY2FtZXJhLnpvb20pKTsgcmV0dXJuIHsgLi4ueiwgeDogcFswXSAtIGNlbnRlclswXSArIHdpZHRoIC8gMiwgeTogcFsxXSAtIGNlbnRlclsxXSArIGhlaWdodCAvIDIgfTsgfSkuZmlsdGVyKHAgPT4gcC54ID49IDAgJiYgcC54IDw9IHdpZHRoICYmIHAueSA+PSAwICYmIHAueSA8PSBoZWlnaHQpKTtcclxuICBmdW5jdGlvbiBzZWxlY3QoaWQ6IHN0cmluZywgcGhhc2U/OiBzdHJpbmcpIHsgc2VsZWN0ZWRJZCA9IGlkOyBzZWxlY3RlZFBoYXNlID0gcGhhc2UgfHwgdW5kZWZpbmVkOyB9XHJcbiAgZnVuY3Rpb24gb3Blbih0YWI/OiBzdHJpbmcpIHtcclxuICAgIGlmICghc2VsZWN0ZWQpIHJldHVybjtcclxuICAgIGlmIChvbk9wZW5Eb3NzaWVyICYmICF0YWIpIG9uT3BlbkRvc3NpZXIoc2VsZWN0ZWQuaWQsIHNlbGVjdGVkUGhhc2UpO1xyXG4gICAgZWxzZSBsb2NhdGlvbi5oYXNoID0gYC9jb21wbGV4ZXMvJHtlbmNvZGVVUklDb21wb25lbnQoc2VsZWN0ZWQuaWQpfSR7c2VsZWN0ZWRQaGFzZSB8fCB0YWIgPyBgPyR7bmV3IFVSTFNlYXJjaFBhcmFtcyh7IC4uLihzZWxlY3RlZFBoYXNlID8geyBwaGFzZTogc2VsZWN0ZWRQaGFzZSB9IDoge30pLCAuLi4odGFiID8geyB0YWIgfSA6IHt9KSB9KX1gIDogJyd9YDtcclxuICB9XHJcbiAgZnVuY3Rpb24gcmVsYXRlZCgpIHtcclxuICAgIGlmICghc2VsZWN0ZWQpIHJldHVybjtcclxuICAgIGNvbnN0IGlkcyA9IHJlbGF0ZWRNYXBQbGFjZXMoc2VsZWN0ZWQuaWQsIHJlbGF0aW9ucywgc3VtbWFyaWVzKTtcclxuICAgIHJlbGF0ZWRJZHMgPSBbc2VsZWN0ZWQuaWQsIC4uLmlkc107XHJcbiAgICBvblNob3dSZWxhdGVkUGxhY2VzPy4oc2VsZWN0ZWQuaWQpO1xyXG4gIH1cclxuICBmdW5jdGlvbiBwYW4oZHg6IG51bWJlciwgZHk6IG51bWJlcikgeyBjb25zdCBwID0gd29ybGRDb29yZGluYXRlcyhjZW50ZXJbMF0gKyBkeCwgY2VudGVyWzFdICsgZHksIE1hdGguZmxvb3IoY2FtZXJhLnpvb20pKTsgY2FtZXJhID0geyAuLi5jYW1lcmEsIGxuZzogcFswXSwgbGF0OiBwWzFdIH07IH1cclxuICBmdW5jdGlvbiBjaGFuZ2Vab29tKGRlbHRhOiBudW1iZXIpIHsgY2FtZXJhID0geyAuLi5jYW1lcmEsIHpvb206IE1hdGgubWF4KDMsIE1hdGgubWluKDE5LCBNYXRoLmZsb29yKGNhbWVyYS56b29tKSArIGRlbHRhKSkgfTsgfVxyXG4gIGZ1bmN0aW9uIHJlbGVhc2VXZWJHTChtZXNzYWdlOiBzdHJpbmcpIHtcclxuICAgIGlmIChtYXApIHsgY29uc3QgYyA9IG1hcC5nZXRDZW50ZXIoKTsgY2FtZXJhID0geyBsbmc6IGMubG5nLCBsYXQ6IGMubGF0LCB6b29tOiBtYXAuZ2V0Wm9vbSgpLCBiZWFyaW5nOiBtYXAuZ2V0QmVhcmluZygpIH07IH1cclxuICAgIGxvYWRlZCA9IGZhbHNlOyBmYWxsYmFjayA9IHRydWU7IGRpbWVuc2lvbmFsID0gZmFsc2U7IHdhcm5pbmcgPSBtZXNzYWdlOyBtYXA/LnJlbW92ZSgpOyBtYXAgPSB1bmRlZmluZWQ7XHJcbiAgfVxyXG4gICRlZmZlY3QoKCkgPT4geyBjb25zdCBkYXRhID0gZ2VvanNvbjsgaWYgKGxvYWRlZCkgeyBtYXJrZXJzUmVhZHkgPSBmYWxzZTsgKG1hcD8uZ2V0U291cmNlKCdjb21wbGV4ZXMnKSBhcyBHZW9KU09OU291cmNlIHwgdW5kZWZpbmVkKT8uc2V0RGF0YShkYXRhKTsgfSB9KTtcclxuICAkZWZmZWN0KCgpID0+IHsgY29uc3QgZGF0YSA9IGZvb3RwcmludHM7IGlmIChsb2FkZWQpIChtYXA/LmdldFNvdXJjZSgnZm9vdHByaW50cycpIGFzIEdlb0pTT05Tb3VyY2UgfCB1bmRlZmluZWQpPy5zZXREYXRhKGRhdGEpOyB9KTtcclxuICBmdW5jdGlvbiBlbnN1cmVTYXRlbGxpdGUoKSB7XHJcbiAgICBpZiAoIW1hcCB8fCBtYXAuZ2V0U291cmNlKCdlc3JpJykpIHJldHVybjtcclxuICAgIHRyeSB7XHJcbiAgICAgIG1hcC5hZGRTb3VyY2UoJ2VzcmknLCB7IHR5cGU6ICdyYXN0ZXInLCB0aWxlczogWydodHRwczovL3NlcnZlci5hcmNnaXNvbmxpbmUuY29tL0FyY0dJUy9yZXN0L3NlcnZpY2VzL1dvcmxkX0ltYWdlcnkvTWFwU2VydmVyL3RpbGUve3p9L3t5fS97eH0nXSwgdGlsZVNpemU6IDI1NiwgYXR0cmlidXRpb246ICdFc3JpIFdvcmxkIEltYWdlcnknIH0pO1xyXG4gICAgICBjb25zdCByYXN0ZXIgPSB7IGlkOiAnc2F0ZWxsaXRlJywgdHlwZTogJ3Jhc3RlcicgYXMgY29uc3QsIHNvdXJjZTogJ2VzcmknIH07XHJcbiAgICAgIHRyeSB7IG1hcC5hZGRMYXllcihyYXN0ZXIsICdjbHVzdGVycycpOyB9IGNhdGNoIHsgbWFwLmFkZExheWVyKHJhc3Rlcik7IH1cclxuICAgIH0gY2F0Y2ggeyAvKiDQodC/0YPRgtC90LjQuiDQvdC10LTQvtGB0YLRg9C/0LXQvSDigJQg0LHQsNC30L7QstCw0Y8g0LrQsNGA0YLQsCDQv9GA0L7QtNC+0LvQttCw0LXRgiDRgNCw0LHQvtGC0LDRgtGMLiAqLyB9XHJcbiAgfVxyXG4gICRlZmZlY3QoKCkgPT4geyBpZiAobG9hZGVkICYmIG1hcCkgeyBpZiAoc2F0ZWxsaXRlKSBlbnN1cmVTYXRlbGxpdGUoKTsgaWYgKG1hcC5nZXRMYXllcignc2F0ZWxsaXRlJykpIG1hcC5zZXRMYXlvdXRQcm9wZXJ0eSgnc2F0ZWxsaXRlJywgJ3Zpc2liaWxpdHknLCBzYXRlbGxpdGUgPyAndmlzaWJsZScgOiAnbm9uZScpOyB9IH0pO1xyXG4gIGZ1bmN0aW9uIGVuc3VyZVRlcnJhaW4oKSB7XHJcbiAgICBpZiAoIW1hcCB8fCBtYXAuZ2V0U291cmNlKCd0ZXJyYWluLWRlbScpKSByZXR1cm47XHJcbiAgICB0cnkge1xyXG4gICAgICBtYXAuYWRkU291cmNlKCd0ZXJyYWluLWRlbScsIHsgdHlwZTogJ3Jhc3Rlci1kZW0nLCB0aWxlczogWydodHRwczovL3MzLmFtYXpvbmF3cy5jb20vZWxldmF0aW9uLXRpbGVzLXByb2QvdGVycmFyaXVtL3t6fS97eH0ve3l9LnBuZyddLCB0aWxlU2l6ZTogMjU2LCBtYXh6b29tOiAxNSwgZW5jb2Rpbmc6ICd0ZXJyYXJpdW0nIH0pO1xyXG4gICAgfSBjYXRjaCB7IC8qINCR0LXQtyDRgNC10LvRjNC10YTQsCDigJQg0LPQvtGA0L7QtCDQvtGB0YLQsNGR0YLRgdGPINC/0LvQvtGB0LrQuNC8LiAqLyB9XHJcbiAgfVxyXG4gIGZ1bmN0aW9uIGVuc3VyZUNpdHkzRCgpIHtcclxuICAgIGlmICghbWFwIHx8IG1hcC5nZXRTb3VyY2UoJ29wZW5tYXB0aWxlcycpKSByZXR1cm47XHJcbiAgICB0cnkge1xyXG4gICAgICBtYXAuYWRkU291cmNlKCdvcGVubWFwdGlsZXMnLCB7IHR5cGU6ICd2ZWN0b3InLCB1cmw6ICdodHRwczovL3RpbGVzLm9wZW5mcmVlbWFwLm9yZy9wbGFuZXQnIH0pO1xyXG4gICAgICBjb25zdCBjaXR5OiBGaWxsRXh0cnVzaW9uTGF5ZXJTcGVjaWZpY2F0aW9uID0geyBpZDogJ2NpdHkzZC1idWlsZGluZ3MnLCB0eXBlOiAnZmlsbC1leHRydXNpb24nLCBzb3VyY2U6ICdvcGVubWFwdGlsZXMnLCAnc291cmNlLWxheWVyJzogJ2J1aWxkaW5nJywgZmlsdGVyOiBbJz4nLCBbJ2NvYWxlc2NlJywgWydnZXQnLCAncmVuZGVyX2hlaWdodCddLCAwXSwgMF0sIHBhaW50OiB7ICdmaWxsLWV4dHJ1c2lvbi1jb2xvcic6ICcjY2NkNmNiJywgJ2ZpbGwtZXh0cnVzaW9uLWhlaWdodCc6IFsnY29hbGVzY2UnLCBbJ2dldCcsICdyZW5kZXJfaGVpZ2h0J10sIDEyXSwgJ2ZpbGwtZXh0cnVzaW9uLWJhc2UnOiBbJ2NvYWxlc2NlJywgWydnZXQnLCAncmVuZGVyX21pbl9oZWlnaHQnXSwgMF0sICdmaWxsLWV4dHJ1c2lvbi1vcGFjaXR5JzogMC44OCwgJ2ZpbGwtZXh0cnVzaW9uLXZlcnRpY2FsLWdyYWRpZW50JzogdHJ1ZSB9IH07XHJcbiAgICAgIHRyeSB7IG1hcC5hZGRMYXllcihjaXR5LCAnYnVpbGRpbmdzJyk7IH0gY2F0Y2ggeyB0cnkgeyBtYXAuYWRkTGF5ZXIoY2l0eSk7IH0gY2F0Y2ggeyAvKiDQndCw0YHRgtC+0Y/RidC40LUgM0Qt0LTQvtC80LAg0L3QtdC00L7RgdGC0YPQv9C90Ysg4oCUINC+0YHRgtCw0Y7RgtGB0Y8g0YPRgdC70L7QstC90YvQtSDQutC+0YDQvtCx0LrQuC4gKi8gfSB9XHJcbiAgICB9IGNhdGNoIHsgLyog0J3QsNGB0YLQvtGP0YnQuNC1IDNELdC00L7QvNCwINC90LXQtNC+0YHRgtGD0L/QvdGLIOKAlCDQvtGB0YLQsNGO0YLRgdGPINGD0YHQu9C+0LLQvdGL0LUg0LrQvtGA0L7QsdC60LguICovIH1cclxuICB9XHJcbiAgJGVmZmVjdCgoKSA9PiB7XHJcbiAgICBpZiAobG9hZGVkICYmIG1hcCkge1xyXG4gICAgICBjb25zdCByZWR1Y2UgPSB3aW5kb3cubWF0Y2hNZWRpYSgnKHByZWZlcnMtcmVkdWNlZC1tb3Rpb246IHJlZHVjZSknKS5tYXRjaGVzO1xyXG4gICAgICB0cnkge1xyXG4gICAgICAgIGlmIChjaXR5M2QpIHtcclxuICAgICAgICAgIC8vINCd0LDRgdGC0L7Rj9GJ0LjQuSAzRC3Qs9C+0YDQvtC0OiDRgNC10LDQu9GM0L3Ri9C1INC00L7QvNCwLCDRgNC10LvRjNC10YQg0Lgg0L3QtdCx0L4uINCi0Y/QttGR0LvRi9C1INGB0LvQvtC4IOKAlCDRgtC+0LvRjNC60L4g0L/QviDQv9C10YDQstC+0LzRgyDQstC60LvRjtGH0LXQvdC40Y4uXHJcbiAgICAgICAgICBlbnN1cmVDaXR5M0QoKTsgZW5zdXJlVGVycmFpbigpO1xyXG4gICAgICAgICAgdHJ5IHsgbWFwLnNldFRlcnJhaW4oeyBzb3VyY2U6ICd0ZXJyYWluLWRlbScsIGV4YWdnZXJhdGlvbjogMS4yIH0pOyB9IGNhdGNoIHsgLyog0KDQtdC70YzQtdGEINC90LXQtNC+0YHRgtGD0L/QtdC9LiAqLyB9XHJcbiAgICAgICAgICB0cnkgeyAobWFwIGFzIHVua25vd24gYXMgeyBzZXRTa3k/OiAoczogb2JqZWN0KSA9PiB2b2lkIH0pLnNldFNreT8uKHsgJ3NreS1jb2xvcic6ICcjOGRiNGRkJywgJ2hvcml6b24tY29sb3InOiAnI2U4ZWVmMCcsICdmb2ctY29sb3InOiAnI2RmZTZlYScsICdza3ktaG9yaXpvbi1ibGVuZCc6IDAuNSwgJ2hvcml6b24tZm9nLWJsZW5kJzogMC41LCAnZm9nLWdyb3VuZC1ibGVuZCc6IDAuNSB9KTsgfSBjYXRjaCB7IC8qINCR0LXQtyDQvdC10LHQsC4gKi8gfVxyXG4gICAgICAgICAgaWYgKG1hcC5nZXRMYXllcignY2l0eTNkLWJ1aWxkaW5ncycpKSBtYXAuc2V0TGF5b3V0UHJvcGVydHkoJ2NpdHkzZC1idWlsZGluZ3MnLCAndmlzaWJpbGl0eScsICd2aXNpYmxlJyk7XHJcbiAgICAgICAgICBtYXAuZWFzZVRvKHsgcGl0Y2g6IDY1LCB6b29tOiBNYXRoLm1heChtYXAuZ2V0Wm9vbSgpLCAxNSksIGR1cmF0aW9uOiByZWR1Y2UgPyAwIDogNjAwIH0pO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICB0cnkgeyBtYXAuc2V0VGVycmFpbihudWxsKTsgfSBjYXRjaCB7IC8qINCg0LXQu9GM0LXRhNCwINC4INC90LUg0LHRi9C70L4uICovIH1cclxuICAgICAgICAgIHRyeSB7IChtYXAgYXMgdW5rbm93biBhcyB7IHNldFNreT86IChzOiBudWxsKSA9PiB2b2lkIH0pLnNldFNreT8uKG51bGwgYXMgbmV2ZXIpOyB9IGNhdGNoIHsgLyog0J3QtdCx0LAg0Lgg0L3QtSDQsdGL0LvQvi4gKi8gfVxyXG4gICAgICAgICAgaWYgKG1hcC5nZXRMYXllcignY2l0eTNkLWJ1aWxkaW5ncycpKSBtYXAuc2V0TGF5b3V0UHJvcGVydHkoJ2NpdHkzZC1idWlsZGluZ3MnLCAndmlzaWJpbGl0eScsICdub25lJyk7XHJcbiAgICAgICAgICBjb25zdCBmbGF0ID0gIWRpbWVuc2lvbmFsO1xyXG4gICAgICAgICAgbWFwLmVhc2VUbyh7IHBpdGNoOiBkaW1lbnNpb25hbCA/IDU1IDogMCwgem9vbTogZmxhdCA/IG1hcC5nZXRab29tKCkgOiBNYXRoLm1heChtYXAuZ2V0Wm9vbSgpLCAxNC41KSwgYmVhcmluZzogZmxhdCA/IDAgOiBtYXAuZ2V0QmVhcmluZygpLCBkdXJhdGlvbjogcmVkdWNlID8gMCA6IDQ1MCB9KTtcclxuICAgICAgICB9XHJcbiAgICAgICAgbWFwLnNldExheW91dFByb3BlcnR5KCdidWlsZGluZ3MnLCAndmlzaWJpbGl0eScsICghZGltZW5zaW9uYWwgJiYgIWNpdHkzZCkgPyAnbm9uZScgOiAndmlzaWJsZScpO1xyXG4gICAgICAgIGNvbnN0IHB0cyA9ICghZGltZW5zaW9uYWwgJiYgIWNpdHkzZCkgPyAndmlzaWJsZScgOiAnbm9uZSc7XHJcbiAgICAgICAgZm9yIChjb25zdCBsYXllciBvZiBbJ3BvaW50cycsICdjbHVzdGVycyddKSBtYXAuc2V0TGF5b3V0UHJvcGVydHkobGF5ZXIsICd2aXNpYmlsaXR5JywgcHRzKTtcclxuICAgICAgICBtYXAuc2V0TGF5b3V0UHJvcGVydHkoJ2Zvb3RwcmludHMtZmxhdCcsICd2aXNpYmlsaXR5JywgKCFkaW1lbnNpb25hbCAmJiAhY2l0eTNkKSA/ICd2aXNpYmxlJyA6ICdub25lJyk7XHJcbiAgICAgIH0gY2F0Y2ggeyAvKiDQmtCw0LzQtdGA0LAg0Lgg0YHQu9C+0Lgg0L7RgdGC0LDRjtGC0YHRjyDQutCw0Log0LHRi9C70LguICovIH1cclxuICAgIH1cclxuICB9KTtcclxuICBvbk1vdW50KCgpID0+IHtcclxuICAgIGxldCBkaXNwb3NlZCA9IGZhbHNlO1xyXG4gICAgY29uc3Qgc3RhcnR1cFRpbWVyID0gd2luZG93LnNldFRpbWVvdXQoKCkgPT4geyBpZiAoIWRpc3Bvc2VkICYmICFtYXJrZXJzUmVhZHkgJiYgIWZhbGxiYWNrKSByZWxlYXNlV2ViR0woJ9Ce0YHQvdC+0LLQvdCw0Y8g0LrQsNGA0YLQsCDQvdC1INC+0YLQstC10YLQuNC70LAg0LLQvtCy0YDQtdC80Y8uINCS0LrQu9GO0YfQtdC90LAg0YTRg9C90LrRhtC40L7QvdCw0LvRjNC90LDRjyAyRC3QutCw0YDRgtCwLicpOyB9LCA4MDAwKTtcclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IHNhdmVkID0gSlNPTi5wYXJzZShzZXNzaW9uU3RvcmFnZS5nZXRJdGVtKCdzYXEtbWFwLXZpZXctdjEnKSA/PyAnbnVsbCcpO1xyXG4gICAgICBpZiAoc2F2ZWQgJiYgQXJyYXkuaXNBcnJheShzYXZlZC5jZW50ZXIpICYmIHNhdmVkLmNlbnRlci5sZW5ndGggPT09IDIgJiYgc2F2ZWQuY2VudGVyLmV2ZXJ5KE51bWJlci5pc0Zpbml0ZSkgJiYgTWF0aC5hYnMoc2F2ZWQuY2VudGVyWzBdKSA8PSAxODAgJiYgTWF0aC5hYnMoc2F2ZWQuY2VudGVyWzFdKSA8PSA4NSAmJiBOdW1iZXIuaXNGaW5pdGUoc2F2ZWQuem9vbSkpIHtcclxuICAgICAgICBjYW1lcmEgPSB7IGxuZzogc2F2ZWQuY2VudGVyWzBdLCBsYXQ6IHNhdmVkLmNlbnRlclsxXSwgem9vbTogTWF0aC5tYXgoMywgTWF0aC5taW4oMTksIHNhdmVkLnpvb20pKSwgYmVhcmluZzogTnVtYmVyLmlzRmluaXRlKHNhdmVkLmJlYXJpbmcpID8gc2F2ZWQuYmVhcmluZyA6IDAgfTtcclxuICAgICAgICB0aGVtZSA9IHRoZW1lcy5zb21lKHQgPT4gdC5pZCA9PT0gc2F2ZWQudGhlbWUpID8gc2F2ZWQudGhlbWUgOiAnb2ZmJztcclxuICAgICAgICB6b25lID0gWydhbGwnLCAnZ3JlZW4nLCAneWVsbG93JywgJ3JlZCddLmluY2x1ZGVzKHNhdmVkLnpvbmUpID8gc2F2ZWQuem9uZSA6ICdhbGwnO1xyXG4gICAgICAgIHF1ZXJ5ID0gdHlwZW9mIHNhdmVkLnF1ZXJ5ID09PSAnc3RyaW5nJyA/IHNhdmVkLnF1ZXJ5LnNsaWNlKDAsIDIwMCkgOiAnJztcclxuICAgICAgICBzZWxlY3RlZElkID0gdHlwZW9mIHNhdmVkLnNlbGVjdGVkSWQgPT09ICdzdHJpbmcnID8gc2F2ZWQuc2VsZWN0ZWRJZCA6ICcnO1xyXG4gICAgICAgIHNlbGVjdGVkUGhhc2UgPSB0eXBlb2Ygc2F2ZWQuc2VsZWN0ZWRQaGFzZSA9PT0gJ3N0cmluZycgPyBzYXZlZC5zZWxlY3RlZFBoYXNlIDogdW5kZWZpbmVkO1xyXG4gICAgICAgIHNhdGVsbGl0ZSA9IHNhdmVkLnNhdGVsbGl0ZSA9PT0gdHJ1ZTsgZGltZW5zaW9uYWwgPSBzYXZlZC5kaW1lbnNpb25hbCA9PT0gdHJ1ZTsgY2l0eTNkID0gc2F2ZWQuY2l0eTNkID09PSB0cnVlICYmIHNhdmVkLmRpbWVuc2lvbmFsICE9PSB0cnVlO1xyXG4gICAgICB9XHJcbiAgICB9IGNhdGNoIHsgLyogU3RvcmFnZSBtYXkgYmUgdW5hdmFpbGFibGU7IHRoZSBtYXAgcmVtYWlucyB1c2FibGUuICovIH1cclxuICAgIGNvbnN0IG9ic2VydmVyID0gbmV3IFJlc2l6ZU9ic2VydmVyKGVudHJpZXMgPT4geyB3aWR0aCA9IGVudHJpZXNbMF0uY29udGVudFJlY3Qud2lkdGg7IGhlaWdodCA9IGVudHJpZXNbMF0uY29udGVudFJlY3QuaGVpZ2h0OyBtYXA/LnJlc2l6ZSgpOyB9KTtcclxuICAgIG9ic2VydmVyLm9ic2VydmUoY29udGFpbmVyKTtcclxuICAgIGZ1bmN0aW9uIHZpc2liaWxpdHkoKSB7IGlmIChkb2N1bWVudC5oaWRkZW4pIG1hcD8uc3RvcCgpOyBlbHNlIG1hcD8ucmVzaXplKCk7IH1cclxuICAgIGRvY3VtZW50LmFkZEV2ZW50TGlzdGVuZXIoJ3Zpc2liaWxpdHljaGFuZ2UnLCB2aXNpYmlsaXR5KTtcclxuICAgIFByb21pc2UuYWxsKFtpbXBvcnQoJ21hcGxpYnJlLWdsJyksIGltcG9ydCgnbWFwbGlicmUtZ2wvZGlzdC9tYXBsaWJyZS1nbC13b3JrZXIubWpzP3dvcmtlciZ1cmwnKV0pLnRoZW4oKFttbCwgd29ya2VyXSkgPT4ge1xyXG4gICAgICBpZiAoZGlzcG9zZWQgfHwgZmFsbGJhY2spIHJldHVybjtcclxuICAgICAgdHJ5IHtcclxuICAgICAgICAvLyBWaXRlIHJlbG9jYXRlcyB0aGUgbWFpbiBtb2R1bGU7IGl0cyBvcmlnaW5hbCByZWxhdGl2ZSB3b3JrZXIgVVJMIGNhbm5vdCBzdXJ2aXZlIHByZWJ1bmRsaW5nLlxyXG4gICAgICAgIG1sLnNldFdvcmtlclVybCh3b3JrZXIuZGVmYXVsdCk7XHJcbiAgICAgICAgbWFwID0gbmV3IG1sLk1hcCh7IGNvbnRhaW5lciwgY2VudGVyOiBbY2FtZXJhLmxuZywgY2FtZXJhLmxhdF0sIHpvb206IGNhbWVyYS56b29tLCBiZWFyaW5nOiBjYW1lcmEuYmVhcmluZywgbWF4UGl0Y2g6IDY4LCBmYWRlRHVyYXRpb246IDEwMCwgbWF4VGlsZUNhY2hlU2l6ZTogODAsIHN0eWxlOiB7XHJcbiAgICAgICAgICB2ZXJzaW9uOiA4LCBzb3VyY2VzOiB7XHJcbiAgICAgICAgICAgIG9zbTogeyB0eXBlOiAncmFzdGVyJywgdGlsZXM6IFsnaHR0cHM6Ly90aWxlLm9wZW5zdHJlZXRtYXAub3JnL3t6fS97eH0ve3l9LnBuZyddLCB0aWxlU2l6ZTogMjU2LCBhdHRyaWJ1dGlvbjogJ8KpIE9wZW5TdHJlZXRNYXAgY29udHJpYnV0b3JzJyB9LFxyXG4gICAgICAgICAgfSwgbGF5ZXJzOiBbeyBpZDogJ29zbScsIHR5cGU6ICdyYXN0ZXInLCBzb3VyY2U6ICdvc20nIH1dLFxyXG4gICAgICAgIH0gfSk7XHJcbiAgICAgICAgbWFwLmFkZENvbnRyb2wobmV3IG1sLk5hdmlnYXRpb25Db250cm9sKHsgdmlzdWFsaXplUGl0Y2g6IHRydWUsIHNob3dDb21wYXNzOiB0cnVlIH0pLCAndG9wLXJpZ2h0Jyk7XHJcbiAgICAgICAgbWFwLm9uKCd3ZWJnbGNvbnRleHRsb3N0JywgKCkgPT4geyBpZiAoIWRpc3Bvc2VkKSByZWxlYXNlV2ViR0woJ1dlYkdMINC90LXQtNC+0YHRgtGD0L/QtdC9LiDQktC60LvRjtGH0LXQvdCwINGE0YPQvdC60YbQuNC+0L3QsNC70YzQvdCw0Y8gMkQt0LrQsNGA0YLQsC4nKTsgfSk7XHJcbiAgICAgICAgbWFwLm9uKCdlcnJvcicsICgpID0+IHsgd2FybmluZyA9ICfQp9Cw0YHRgtGMINC60LDRgNGC0L7Qs9GA0LDRhNC40YfQtdGB0LrQuNGFINC00LDQvdC90YvRhSDQvdC10LTQvtGB0YLRg9C/0L3QsC4g0JzQsNGA0LrQtdGA0Ysg0Lgg0YHQv9C40YHQvtC6INC+0LHRitC10LrRgtC+0LIg0YDQsNCx0L7RgtCw0Y7Rgi4nOyB9KTtcclxuICAgICAgICBtYXAub24oJ21vdmVlbmQnLCAoKSA9PiB7IGlmIChtYXApIHsgY29uc3QgYyA9IG1hcC5nZXRDZW50ZXIoKTsgY2FtZXJhID0geyBsbmc6IGMubG5nLCBsYXQ6IGMubGF0LCB6b29tOiBtYXAuZ2V0Wm9vbSgpLCBiZWFyaW5nOiBtYXAuZ2V0QmVhcmluZygpIH07IH0gfSk7XHJcbiAgICAgICAgbWFwLm9uKCdzb3VyY2VkYXRhJywgZSA9PiB7IGlmIChlLnNvdXJjZUlkID09PSAnY29tcGxleGVzJyAmJiBlLmlzU291cmNlTG9hZGVkKSB7IG1hcmtlcnNSZWFkeSA9IHRydWU7IHdpbmRvdy5jbGVhclRpbWVvdXQoc3RhcnR1cFRpbWVyKTsgfSB9KTtcclxuICAgICAgICBtYXAub24oJ3N0eWxlLmxvYWQnLCAoKSA9PiB7XHJcbiAgICAgICAgICBpZiAoIW1hcCB8fCBkaXNwb3NlZCkgcmV0dXJuO1xyXG4gICAgICAgICAgbWFwLmFkZFNvdXJjZSgnY29tcGxleGVzJywgeyB0eXBlOiAnZ2VvanNvbicsIGRhdGE6IGdlb2pzb24sIGNsdXN0ZXI6IHRydWUsIGNsdXN0ZXJNYXhab29tOiAxNCwgY2x1c3RlclJhZGl1czogNDUgfSk7XHJcbiAgICAgICAgICBtYXAuYWRkU291cmNlKCdmb290cHJpbnRzJywgeyB0eXBlOiAnZ2VvanNvbicsIGRhdGE6IGZvb3RwcmludHMgfSk7XHJcbiAgICAgICAgICBtYXAuYWRkTGF5ZXIoeyBpZDogJ2Zvb3RwcmludHMtZmxhdCcsIHR5cGU6ICdmaWxsJywgc291cmNlOiAnZm9vdHByaW50cycsIGZpbHRlcjpbJz09JyxbJ2dldCcsJ2FwcHJveGltYXRlRm9vdHByaW50J10sZmFsc2VdLCBwYWludDogeyAnZmlsbC1jb2xvcic6IFsnZ2V0JywgJ2NvbG9yJ10sICdmaWxsLW9wYWNpdHknOiAwLjQ1IH0gfSk7XHJcbiAgICAgICAgICBtYXAuYWRkTGF5ZXIoeyBpZDogJ2J1aWxkaW5ncycsIHR5cGU6ICdmaWxsLWV4dHJ1c2lvbicsIHNvdXJjZTogJ2Zvb3RwcmludHMnLCBsYXlvdXQ6IHsgdmlzaWJpbGl0eTogZGltZW5zaW9uYWwgPyAndmlzaWJsZScgOiAnbm9uZScgfSwgcGFpbnQ6IHsgJ2ZpbGwtZXh0cnVzaW9uLWNvbG9yJzogWydnZXQnLCAnY29sb3InXSwgJ2ZpbGwtZXh0cnVzaW9uLWhlaWdodCc6IFsnZ2V0JywgJ2hlaWdodCddLCAnZmlsbC1leHRydXNpb24tb3BhY2l0eSc6IDAuOSwgJ2ZpbGwtZXh0cnVzaW9uLXZlcnRpY2FsLWdyYWRpZW50Jzp0cnVlIH0gfSk7XHJcbiAgICAgICAgICBtYXAuYWRkTGF5ZXIoeyBpZDogJ2NsdXN0ZXJzJywgdHlwZTogJ2NpcmNsZScsIHNvdXJjZTogJ2NvbXBsZXhlcycsIGZpbHRlcjogWydoYXMnLCAncG9pbnRfY291bnQnXSwgcGFpbnQ6IHsgJ2NpcmNsZS1jb2xvcic6ICcjMTgzZTMzJywgJ2NpcmNsZS1yYWRpdXMnOiBbJ3N0ZXAnLCBbJ2dldCcsICdwb2ludF9jb3VudCddLCAxNywgMTAsIDIzXSwgJ2NpcmNsZS1zdHJva2UtY29sb3InOiAnI2ZmZicsICdjaXJjbGUtc3Ryb2tlLXdpZHRoJzogMyB9IH0pO1xyXG4gICAgICAgICAgbWFwLmFkZExheWVyKHsgaWQ6ICdwb2ludHMnLCB0eXBlOiAnY2lyY2xlJywgc291cmNlOiAnY29tcGxleGVzJywgZmlsdGVyOiBbJyEnLCBbJ2hhcycsICdwb2ludF9jb3VudCddXSwgcGFpbnQ6IHsgJ2NpcmNsZS1jb2xvcic6IFsnZ2V0JywgJ2NvbG9yJ10sICdjaXJjbGUtcmFkaXVzJzogOSwgJ2NpcmNsZS1zdHJva2UtY29sb3InOiAnI2ZmZicsICdjaXJjbGUtc3Ryb2tlLXdpZHRoJzogMyB9IH0pO1xyXG4gICAgICAgICAgZm9yIChjb25zdCBsYXllciBvZiBbJ3BvaW50cycsICdmb290cHJpbnRzLWZsYXQnLCAnYnVpbGRpbmdzJ10pIHtcclxuICAgICAgICAgICAgbWFwLm9uKCdjbGljaycsIGxheWVyLCBlID0+IHsgY29uc3QgcCA9IGUuZmVhdHVyZXM/LlswXT8ucHJvcGVydGllczsgaWYgKHR5cGVvZiBwPy5pZCA9PT0gJ3N0cmluZycpIHNlbGVjdChwLmlkLCBwLnBoYXNlSWQpOyB9KTtcclxuICAgICAgICAgICAgbWFwLm9uKCdtb3VzZWVudGVyJywgbGF5ZXIsICgpID0+IHsgaWYgKG1hcCkgbWFwLmdldENhbnZhcygpLnN0eWxlLmN1cnNvciA9ICdwb2ludGVyJzsgfSk7XHJcbiAgICAgICAgICAgIG1hcC5vbignbW91c2VsZWF2ZScsIGxheWVyLCAoKSA9PiB7IGlmIChtYXApIG1hcC5nZXRDYW52YXMoKS5zdHlsZS5jdXJzb3IgPSAnJzsgfSk7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgICBtYXAub24oJ2NsaWNrJywgJ2NsdXN0ZXJzJywgYXN5bmMgZSA9PiB7XHJcbiAgICAgICAgICAgIGNvbnN0IGYgPSBlLmZlYXR1cmVzPy5bMF07IGNvbnN0IGFjdGl2ZSA9IG1hcDsgaWYgKCFhY3RpdmUgfHwgIWYgfHwgZi5nZW9tZXRyeS50eXBlICE9PSAnUG9pbnQnKSByZXR1cm47XHJcbiAgICAgICAgICAgIHRyeSB7IGNvbnN0IHpvb20gPSBhd2FpdCAoYWN0aXZlLmdldFNvdXJjZSgnY29tcGxleGVzJykgYXMgR2VvSlNPTlNvdXJjZSkuZ2V0Q2x1c3RlckV4cGFuc2lvblpvb20oTnVtYmVyKGYucHJvcGVydGllcy5jbHVzdGVyX2lkKSk7IGlmICghZGlzcG9zZWQgJiYgbWFwID09PSBhY3RpdmUpIGFjdGl2ZS5lYXNlVG8oeyBjZW50ZXI6IGYuZ2VvbWV0cnkuY29vcmRpbmF0ZXMgYXMgW251bWJlciwgbnVtYmVyXSwgem9vbSB9KTsgfSBjYXRjaCB7IC8qIE1hcCBtYXkgdW5tb3VudCBkdXJpbmcgY2x1c3RlciBleHBhbnNpb24uICovIH1cclxuICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgbG9hZGVkID0gdHJ1ZTtcclxuICAgICAgICB9KTtcclxuICAgICAgfSBjYXRjaCB7IHJlbGVhc2VXZWJHTCgnV2ViR0wg0L3QtdC00L7RgdGC0YPQv9C10L0uINCS0LrQu9GO0YfQtdC90LAg0YTRg9C90LrRhtC40L7QvdCw0LvRjNC90LDRjyAyRC3QutCw0YDRgtCwLicpOyB9XHJcbiAgICB9KS5jYXRjaCgoKSA9PiB7IGlmICghZGlzcG9zZWQpIHJlbGVhc2VXZWJHTCgn0JrQsNGA0YLQvtCz0YDQsNGE0LjRh9C10YHQutC40Lkg0LzQvtC00YPQu9GMINC90LXQtNC+0YHRgtGD0L/QtdC9LiDQktC60LvRjtGH0LXQvdCwIDJELdC60LDRgNGC0LAuJyk7IH0pO1xyXG4gICAgcmV0dXJuICgpID0+IHtcclxuICAgICAgdHJ5IHsgc2Vzc2lvblN0b3JhZ2Uuc2V0SXRlbSgnc2FxLW1hcC12aWV3LXYxJywgSlNPTi5zdHJpbmdpZnkoeyBjZW50ZXI6IFtjYW1lcmEubG5nLCBjYW1lcmEubGF0XSwgem9vbTogY2FtZXJhLnpvb20sIGJlYXJpbmc6IGNhbWVyYS5iZWFyaW5nLCB0aGVtZSwgem9uZSwgcXVlcnksIHNlbGVjdGVkSWQsIHNlbGVjdGVkUGhhc2UsIHNhdGVsbGl0ZSwgZGltZW5zaW9uYWwsIGNpdHkzZCB9KSk7IH0gY2F0Y2ggeyAvKiBCZXN0LWVmZm9ydCB2aWV3IHBlcnNpc3RlbmNlLCBubyBkb3NzaWVyIGRhdGEuICovIH1cclxuICAgICAgZGlzcG9zZWQgPSB0cnVlOyBvYnNlcnZlci5kaXNjb25uZWN0KCk7IGRvY3VtZW50LnJlbW92ZUV2ZW50TGlzdGVuZXIoJ3Zpc2liaWxpdHljaGFuZ2UnLCB2aXNpYmlsaXR5KTsgbG9hZGVkID0gZmFsc2U7IG1hcD8uc3RvcCgpOyBtYXA/LnJlbW92ZSgpOyBtYXAgPSB1bmRlZmluZWQ7XHJcbiAgICAgIHdpbmRvdy5jbGVhclRpbWVvdXQoc3RhcnR1cFRpbWVyKTtcclxuICAgIH07XHJcbiAgfSk7XHJcbjwvc2NyaXB0PlxyXG48c2VjdGlvbiBjbGFzcz1cIm1hcC1zaGVsbFwiIGFyaWEtbGFiZWw9XCLQmtCw0YDRgtCwINC+0LHRitC10LrRgtC+0LJcIj5cclxuICA8ZGl2IGNsYXNzPVwibWFwLXdyYXBcIiBkYXRhLW1hcC1yZWFkeT17ZmFsbGJhY2sgfHwgbWFya2Vyc1JlYWR5fT5cclxuICAgIDxkaXYgYmluZDp0aGlzPXtjb250YWluZXJ9IGNsYXNzPVwibWFwXCIgYXJpYS1sYWJlbD1cItCa0LDRgNGC0LAg0L7QsdGK0LXQutGC0L7QsiDTqNGB0LrQtdC80LXQvdCwXCI+PC9kaXY+XHJcbiAgICA8ZGl2IGNsYXNzPVwibWFwLXRvb2xzIG1hcC1mbG9hdC10b3BcIj5cclxuICAgICAgPGJ1dHRvbiBjbGFzcz1cInNtYWxsIG1hcC1saXN0LXRvZ2dsZVwiIGFyaWEtZXhwYW5kZWQ9e2xpc3RPcGVufSBvbmNsaWNrPXsoKSA9PiBsaXN0T3BlbiA9ICFsaXN0T3Blbn0+0KHQv9C40YHQvtC6IMK3IHt2aXNpYmxlLmxlbmd0aH08L2J1dHRvbj5cclxuICAgICAgPGlucHV0IGNsYXNzPVwibWFwLXNlYXJjaFwiIGFyaWEtbGFiZWw9XCLQn9C+0LjRgdC6INCW0JosINCR0JjQnSDQuNC70Lgg0LDQtNGA0LXRgdCwINC90LAg0LrQsNGA0YLQtVwiIHBsYWNlaG9sZGVyPVwi0J/QvtC40YHQuiDQltCaLCDQkdCY0J0sINCw0LTRgNC10YHQsFwiIGJpbmQ6dmFsdWU9e3F1ZXJ5fSAvPlxyXG4gICAgICA8c2VsZWN0IGFyaWEtbGFiZWw9XCLQkdCw0LfQvtCy0LDRjyDQt9C+0L3QsCDRgNC40YHQutCwXCIgYmluZDp2YWx1ZT17em9uZX0+PG9wdGlvbiB2YWx1ZT1cImFsbFwiPtCS0YHQtSDQt9C+0L3RiyDRgNC40YHQutCwPC9vcHRpb24+PG9wdGlvbiB2YWx1ZT1cImdyZWVuXCI+0JfQtdC70ZHQvdCw0Y88L29wdGlvbj48b3B0aW9uIHZhbHVlPVwieWVsbG93XCI+0JbRkdC70YLQsNGPPC9vcHRpb24+PG9wdGlvbiB2YWx1ZT1cInJlZFwiPtCa0YDQsNGB0L3QsNGPPC9vcHRpb24+PC9zZWxlY3Q+XHJcbiAgICAgIDxkaXYgY2xhc3M9XCJzZWdtZW50ZWRcIiBhcmlhLWxhYmVsPVwi0J/QvtC00LvQvtC20LrQsFwiPjxidXR0b24gYXJpYS1wcmVzc2VkPXshc2F0ZWxsaXRlIHx8IGZhbGxiYWNrfSBvbmNsaWNrPXsoKSA9PiBzYXRlbGxpdGUgPSBmYWxzZX0+0JrQsNGA0YLQsDwvYnV0dG9uPjxidXR0b24gZGlzYWJsZWQ9e2ZhbGxiYWNrfSBhcmlhLXByZXNzZWQ9e3NhdGVsbGl0ZSAmJiAhZmFsbGJhY2t9IG9uY2xpY2s9eygpID0+IHNhdGVsbGl0ZSA9IHRydWV9PtCh0L/Rg9GC0L3QuNC6PC9idXR0b24+PC9kaXY+XHJcbiAgICAgIDxkaXYgY2xhc3M9XCJzZWdtZW50ZWRcIiBhcmlhLWxhYmVsPVwi0KDQsNC30LzQtdGA0L3QvtGB0YLRjCDQutCw0YDRgtGLXCI+PGJ1dHRvbiB0aXRsZT1cItCf0LvQvtGB0LrQsNGPINC60LDRgNGC0LA6INC80LXRgtC60Lgg0Lgg0LrQvtC90YLRg9GA0YtcIiBhcmlhLXByZXNzZWQ9eyFkaW1lbnNpb25hbCAmJiAhY2l0eTNkfSBvbmNsaWNrPXsoKSA9PiB7IGRpbWVuc2lvbmFsID0gZmFsc2U7IGNpdHkzZCA9IGZhbHNlOyB9fT4yRDwvYnV0dG9uPjxidXR0b24gdGl0bGU9XCIyLjVEOiDRg9GB0LvQvtCy0L3Ri9C1INC+0LHRitGR0LzQvdGL0LUg0LrQvtGA0L7QsdC60Lgg0LrQvtGA0L/Rg9GB0L7QslwiIGRpc2FibGVkPXtmYWxsYmFja30gYXJpYS1wcmVzc2VkPXtkaW1lbnNpb25hbH0gb25jbGljaz17KCkgPT4geyBkaW1lbnNpb25hbCA9IHRydWU7IGNpdHkzZCA9IGZhbHNlOyB9fT4yLjVEPC9idXR0b24+PGJ1dHRvbiB0aXRsZT1cItCd0LDRgdGC0L7Rj9GJ0LjQuSAzRC3Qs9C+0YDQvtC0OiDRgNC10LDQu9GM0L3Ri9C1INC00L7QvNCwLCDRgNC10LvRjNC10YQg0Lgg0L3QtdCx0L5cIiBkaXNhYmxlZD17ZmFsbGJhY2t9IGFyaWEtcHJlc3NlZD17Y2l0eTNkfSBvbmNsaWNrPXsoKSA9PiB7IGNpdHkzZCA9IHRydWU7IGRpbWVuc2lvbmFsID0gZmFsc2U7IH19PjNEPC9idXR0b24+PC9kaXY+XHJcbiAgICAgIDxkaXYgY2xhc3M9XCJzZWdtZW50ZWQgeHJheVwiIGFyaWEtbGFiZWw9XCLQotC10LzQsCBYLVJheVwiPjxzcGFuPlgtUmF5PC9zcGFuPnsjZWFjaCB0aGVtZXMgYXMgdH08YnV0dG9uIGFyaWEtcHJlc3NlZD17dGhlbWUgPT09IHQuaWR9IG9uY2xpY2s9eygpID0+IHRoZW1lID0gdC5pZH0+e3QudGl0bGV9PC9idXR0b24+ey9lYWNofTwvZGl2PlxyXG4gICAgPC9kaXY+XHJcbiAgICB7I2lmIGZhbGxiYWNrfVxyXG4gICAgICA8ZGl2IGNsYXNzPVwiZmFsbGJhY2stbWFwXCIgc3R5bGU6aGVpZ2h0PVwie2hlaWdodH1weFwiIGFyaWEtbGFiZWw9XCLQlNCy0YPQvNC10YDQvdCw0Y8g0LrQsNGA0YLQsCDQsdC10LcgV2ViR0xcIj5cclxuICAgICAgICB7I2VhY2ggdGlsZXMgYXMgdGlsZSAodGlsZS5rZXkpfTxpbWcgY2xhc3M9XCJ0aWxlXCIgc3JjPXt0aWxlLnVybH0gYWx0PVwiXCIgd2lkdGg9XCIyNTZcIiBoZWlnaHQ9XCIyNTZcIiBzdHlsZTpsZWZ0PVwie3RpbGUueH1weFwiIHN0eWxlOnRvcD1cInt0aWxlLnl9cHhcIiBkcmFnZ2FibGU9XCJmYWxzZVwiIC8+ey9lYWNofVxyXG4gICAgICAgIHsjZWFjaCBmYWxsYmFja1BvaW50cyBhcyBwb2ludCAocG9pbnQuaWQpfTxidXR0b24gY2xhc3M9XCJmYWxsYmFjay1wb2ludFwiIHN0eWxlOmxlZnQ9XCJ7cG9pbnQueH1weFwiIHN0eWxlOnRvcD1cIntwb2ludC55fXB4XCIgc3R5bGU6YmFja2dyb3VuZD17cG9pbnQuY29sb3J9IGFyaWEtbGFiZWw9e2Ake3BvaW50Lm5hbWV9OiAke3BvaW50LmxhYmVsfWB9IHRpdGxlPXtgJHtwb2ludC5uYW1lfTogJHtwb2ludC5sYWJlbH1gfSBvbmNsaWNrPXsoKSA9PiBzZWxlY3QocG9pbnQuaWQpfT48L2J1dHRvbj57L2VhY2h9XHJcbiAgICAgICAgPG5hdiBjbGFzcz1cImZhbGxiYWNrLWNvbnRyb2xzXCIgYXJpYS1sYWJlbD1cItCf0LXRgNC10LzQtdGJ0LXQvdC40LUg0LrQsNGA0YLRi1wiPjxidXR0b24gYXJpYS1sYWJlbD1cItCf0YDQuNCx0LvQuNC30LjRgtGMXCIgb25jbGljaz17KCkgPT4gY2hhbmdlWm9vbSgxKX0+KzwvYnV0dG9uPjxidXR0b24gYXJpYS1sYWJlbD1cItCe0YLQtNCw0LvQuNGC0YxcIiBvbmNsaWNrPXsoKSA9PiBjaGFuZ2Vab29tKC0xKX0+4oiSPC9idXR0b24+PGJ1dHRvbiBhcmlhLWxhYmVsPVwi0J3QsCDRgdC10LLQtdGAXCIgb25jbGljaz17KCkgPT4gcGFuKDAsIC0xNjApfT7ihpE8L2J1dHRvbj48YnV0dG9uIGFyaWEtbGFiZWw9XCLQndCwINC30LDQv9Cw0LRcIiBvbmNsaWNrPXsoKSA9PiBwYW4oLTE2MCwgMCl9PuKGkDwvYnV0dG9uPjxidXR0b24gYXJpYS1sYWJlbD1cItCd0LAg0LLQvtGB0YLQvtC6XCIgb25jbGljaz17KCkgPT4gcGFuKDE2MCwgMCl9PuKGkjwvYnV0dG9uPjxidXR0b24gYXJpYS1sYWJlbD1cItCd0LAg0Y7Qs1wiIG9uY2xpY2s9eygpID0+IHBhbigwLCAxNjApfT7ihpM8L2J1dHRvbj48L25hdj5cclxuICAgICAgICA8YSBjbGFzcz1cImF0dHJpYnV0aW9uXCIgaHJlZj1cImh0dHBzOi8vd3d3Lm9wZW5zdHJlZXRtYXAub3JnL2NvcHlyaWdodFwiIHRhcmdldD1cIl9ibGFua1wiIHJlbD1cIm5vcmVmZXJyZXJcIj7CqSBPcGVuU3RyZWV0TWFwIGNvbnRyaWJ1dG9yczwvYT5cclxuICAgICAgPC9kaXY+XHJcbiAgICB7L2lmfVxyXG4gICAgeyNpZiAhbG9hZGVkICYmICFmYWxsYmFja308cCBjbGFzcz1cIm1hcC1zdGF0dXNcIiByb2xlPVwic3RhdHVzXCI+0JfQsNCz0YDRg9C30LrQsCDQutCw0YDRgtGL4oCmPC9wPnsvaWZ9XHJcbiAgICB7I2lmIHdhcm5pbmd9PHAgY2xhc3M9XCJtYXAtc3RhdHVzXCIgcm9sZT1cInN0YXR1c1wiPnt3YXJuaW5nfTwvcD57L2lmfVxyXG4gICAgeyNpZiBzZWxlY3RlZH1cclxuICAgICAgPGFzaWRlIGNsYXNzPVwibWFwLXByZXZpZXdcIiBhcmlhLWxhYmVsPVwi0J/RgNC10LTQv9GA0L7RgdC80L7RgtGAINCW0JpcIj5cclxuICAgICAgICA8ZGl2IGNsYXNzPVwicHJldmlldy10b3BcIj48c3BhbiBjbGFzcz1cInByZXZpZXctZXllYnJvd1wiPntzZWxlY3RlZC5kZW1vID8gJ9CU0LXQvNC+IMK3ICcgOiAnJ317c2VsZWN0ZWRQaGFzZSA/IGDQntGH0LXRgNC10LTRjCAke3NlbGVjdGVkUGhhc2V9YCA6ICfQltC40LvQvtC5INC60L7QvNC/0LvQtdC60YEnfTwvc3Bhbj48YnV0dG9uIGNsYXNzPVwiY2xvc2UtcHJldmlld1wiIGFyaWEtbGFiZWw9XCLQl9Cw0LrRgNGL0YLRjCDQv9GA0LXQtNC/0YDQvtGB0LzQvtGC0YBcIiBvbmNsaWNrPXsoKSA9PiBzZWxlY3RlZElkID0gJyd9PsOXPC9idXR0b24+PC9kaXY+XHJcbiAgICAgICAgPGgzPntzZWxlY3RlZC5uYW1lfTwvaDM+XHJcbiAgICAgICAgPHAgY2xhc3M9XCJwcmV2aWV3LXN1YlwiPntzZWxlY3RlZC5hZGRyZXNzfTwvcD5cclxuICAgICAgICA8ZGl2IGNsYXNzPVwicHJldmlldy1zY29yZVwiIHN0eWxlOmJvcmRlci1sZWZ0LWNvbG9yPXtzZWxlY3RlZC5jb2xvcn0+PHN0cm9uZz57c2VsZWN0ZWQuc2NvcmV9PC9zdHJvbmc+PHNwYW4+e3pvbmVMYWJlbChzZWxlY3RlZC56b25lKX0g0LfQvtC90LA8L3NwYW4+PC9kaXY+XHJcbiAgICAgICAgPGRsIGNsYXNzPVwicHJldmlldy1mYWN0c1wiPlxyXG4gICAgICAgICAgPGRpdj48ZHQ+0JfQsNGB0YLRgNC+0LnRidC40Lo8L2R0PjxkZD57c2VsZWN0ZWQuZGV2ZWxvcGVyfTwvZGQ+PC9kaXY+XHJcbiAgICAgICAgICA8ZGl2PjxkdD7QkdCY0J08L2R0PjxkZD57c2VsZWN0ZWQuYmluID8/ICfQndC1INGD0LrQsNC30LDQvSd9PC9kZD48L2Rpdj5cclxuICAgICAgICAgIDxkaXY+PGR0PtCY0YHRgtC+0YfQvdC40Lo8L2R0PjxkZD57c2VsZWN0ZWQuc291cmNlIHx8ICfQndC1INC30LDRhNC40LrRgdC40YDQvtCy0LDQvSd9PC9kZD48L2Rpdj5cclxuICAgICAgICAgIDxkaXY+PGR0PtCf0YDQvtCy0LXRgNC10L3QvjwvZHQ+PGRkPntzZWxlY3RlZC5kYXRlIHx8ICfigJQnfTwvZGQ+PC9kaXY+XHJcbiAgICAgICAgICA8ZGl2PjxkdD7Qn9GD0LHQu9C40LrQsNGG0LjQuDwvZHQ+PGRkPntzZWxlY3RlZC5wdWJsaWNhdGlvbnMgPz8gJ9C90LXRgiDQtNCw0L3QvdGL0YUnfTwvZGQ+PC9kaXY+XHJcbiAgICAgICAgPC9kbD5cclxuICAgICAgICA8cCBjbGFzcz1cImtleS1mYWN0XCI+PHNwYW4gY2xhc3M9XCJsZWdlbmQtZG90XCIgc3R5bGU6YmFja2dyb3VuZD17c2VsZWN0ZWQuY29sb3J9Pjwvc3Bhbj57c2VsZWN0ZWQubGFiZWx9PC9wPlxyXG4gICAgICAgIHsjaWYgc2VsZWN0ZWRCb3h9XHJcbiAgICAgICAgPGRpdiBjbGFzcz1cInByZXZpZXctbW9kZWxcIj5cclxuICAgICAgICAgIDxzdHJvbmc+e3NlbGVjdGVkQm94LnByb3BlcnRpZXMuYXBwcm94aW1hdGVGb290cHJpbnQgfHwgc2VsZWN0ZWRCb3gucHJvcGVydGllcy5hcHByb3hpbWF0ZUhlaWdodCA/ICfQo9GB0LvQvtCy0L3QsNGPIDNELdC60L7RgNC+0LHQutCwJyA6ICfQnNC+0LTQtdC70Ywg0LfQtNCw0L3QuNGPJ308L3N0cm9uZz5cclxuICAgICAgICAgIDxkbD5cclxuICAgICAgICAgICAgPGRpdj48ZHQ+0JLRi9GB0L7RgtCwPC9kdD48ZGQ+e3NlbGVjdGVkQm94LnByb3BlcnRpZXMuaGVpZ2h0fSDQvHtzZWxlY3RlZEJveC5wcm9wZXJ0aWVzLmFwcHJveGltYXRlSGVpZ2h0ID8gJyDCtyDRg9GB0LvQvtCy0L3QsNGPJyA6ICcgwrcg0LjQt9C80LXRgNC10L3QvdCw0Y8nfTwvZGQ+PC9kaXY+XHJcbiAgICAgICAgICAgIDxkaXY+PGR0PtCa0L7QvdGC0YPRgDwvZHQ+PGRkPntzZWxlY3RlZEJveC5wcm9wZXJ0aWVzLmFwcHJveGltYXRlRm9vdHByaW50ID8gJ9GB0YXQtdC80LAgNjAgw5cgNDQg0LwnIDogJ9C/0YDQvtCy0LXRgNC10L3QvdGL0Lkg0LrQvtC90YLRg9GAJ308L2RkPjwvZGl2PlxyXG4gICAgICAgICAgICA8ZGl2PjxkdD7QmNGB0YLQvtGH0L3QuNC6PC9kdD48ZGQ+e3NlbGVjdGVkR2VvbT8uc291cmNlID8/ICfRgdGF0LXQvNCwINC/0L4g0LrQvtC+0YDQtNC40L3QsNGC0LDQvCd9PC9kZD48L2Rpdj5cclxuICAgICAgICAgIDwvZGw+XHJcbiAgICAgICAgICA8YnV0dG9uIGNsYXNzPVwidGV4dC1idXR0b25cIiBvbmNsaWNrPXsoKSA9PiBvcGVuKCd0aW1lbGluZScpfT7QodC80L7RgtGA0LXRgtGMINC/0YDQvtCz0YDQtdGB0YEg0LIg0YXRgNC+0L3QvtC70L7Qs9C40Lgg4oaSPC9idXR0b24+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgey9pZn1cclxuICAgICAgICB7I2lmIChkaW1lbnNpb25hbCB8fCBjaXR5M2QpICYmIHNlbGVjdGVkQm94ICYmIChzZWxlY3RlZEJveC5wcm9wZXJ0aWVzLmFwcHJveGltYXRlRm9vdHByaW50IHx8IHNlbGVjdGVkQm94LnByb3BlcnRpZXMuYXBwcm94aW1hdGVIZWlnaHQpfTxwIGNsYXNzPVwicHJldmlldy1tZXRhXCI+e3NlbGVjdGVkQm94LnByb3BlcnRpZXMuYXBwcm94aW1hdGVGb290cHJpbnQgPyAn0JrQvtC90YLRg9GAINC4INCy0YvRgdC+0YLQsCDigJQg0YHRhdC10LzQsCwg0L3QtSDQvtCx0LzQtdGALicgOiAn0JLRi9GB0L7RgtCwINGD0YHQu9C+0LLQvdCw0Y8sINC60L7QvdGC0YPRgCDQv9GA0L7QstC10YDQtdC9Lid9PC9wPnsvaWZ9XHJcbiAgICAgICAgPGRpdiBjbGFzcz1cInByZXZpZXctYWN0aW9uc1wiPjxidXR0b24gb25jbGljaz17KCkgPT4gb3BlbigpfT7QntGC0LrRgNGL0YLRjCDQtNC+0YHRjNC1PC9idXR0b24+PGJ1dHRvbiBjbGFzcz1cInNlY29uZGFyeVwiIG9uY2xpY2s9e3JlbGF0ZWR9PtCf0L7QutCw0LfQsNGC0Ywg0YHQstGP0LfQuDwvYnV0dG9uPjwvZGl2PlxyXG4gICAgICAgIHsjaWYgdGhlbWUgPT09ICdjb25zdHJ1Y3Rpb24nfTxidXR0b24gY2xhc3M9XCJ0ZXh0LWJ1dHRvblwiIG9uY2xpY2s9eygpID0+IG9wZW4oJ3RpbWVsaW5lJyl9PtCe0YLQutGA0YvRgtGMINGF0YDQvtC90L7Qu9C+0LPQuNGOIOKGkjwvYnV0dG9uPnsvaWZ9XHJcbiAgICAgICAgeyNpZiB0aGVtZSA9PT0gJ2FkdmVydGlzaW5nJ308YnV0dG9uIGNsYXNzPVwidGV4dC1idXR0b25cIiBvbmNsaWNrPXsoKSA9PiBvcGVuKCd2ZXJpZmljYXRpb24nKX0+0J7RgtC60YDRi9GC0Ywg0L/Rg9Cx0LvQuNC60LDRhtC40Lgg4oaSPC9idXR0b24+ey9pZn1cclxuICAgICAgICB7I2lmIHJlbGF0ZWRJZHN9PHAgY2xhc3M9XCJwcmV2aWV3LW1ldGFcIj7QodCy0Y/Qt9Cw0L3QvdGL0YUg0JbQmjoge3JlbGF0ZWRJZHMubGVuZ3RoIC0gMX0uPC9wPnsvaWZ9XHJcbiAgICAgIDwvYXNpZGU+XHJcbiAgICB7L2lmfVxyXG4gICAgeyNpZiBsaXN0T3Blbn1cclxuICAgICAgPGFzaWRlIGNsYXNzPVwibWFwLWxpc3QtcGFuZWxcIiBhcmlhLWxhYmVsPVwi0KHQv9C40YHQvtC6INC+0LHRitC10LrRgtC+0LJcIj5cclxuICAgICAgICA8ZGl2IGNsYXNzPVwibWFwLWxpc3QtaGVhZFwiPjxzdHJvbmc+0J7QsdGK0LXQutGC0Ysgwrcge3Zpc2libGUubGVuZ3RofTwvc3Ryb25nPjxidXR0b24gY2xhc3M9XCJzbWFsbFwiIGFyaWEtbGFiZWw9XCLQl9Cw0LrRgNGL0YLRjCDRgdC/0LjRgdC+0LpcIiBvbmNsaWNrPXsoKSA9PiBsaXN0T3BlbiA9IGZhbHNlfT7DlzwvYnV0dG9uPjwvZGl2PlxyXG4gICAgICAgIDxkaXYgY2xhc3M9XCJtYXAtbGlzdC1ib2R5XCI+eyNlYWNoIHZpc2libGUgYXMgaXRlbSAoaXRlbS5pZCl9PGJ1dHRvbiBjbGFzczphY3RpdmU9e2l0ZW0uaWQ9PT1zZWxlY3RlZElkfSBvbmNsaWNrPXsoKSA9PiBzZWxlY3QoaXRlbS5pZCl9PjxzcGFuPntpdGVtLm5hbWV9PC9zcGFuPjxzbWFsbD57aXRlbS5sYWJlbH08L3NtYWxsPjwvYnV0dG9uPns6ZWxzZX08cD7QntCx0YrQtdC60YLQvtCyINC/0L4g0LLRi9Cx0YDQsNC90L3Ri9C8INGD0YHQu9C+0LLQuNGP0Lwg0L3QtdGCLjwvcD57L2VhY2h9PC9kaXY+XHJcbiAgICAgIDwvYXNpZGU+XHJcbiAgICB7L2lmfVxyXG4gICAgeyNpZiBhYm91dE9wZW59XHJcbiAgICAgIDxkaXYgY2xhc3M9XCJtYXAtYWJvdXQtZmxvYXRcIiByb2xlPVwiZGlhbG9nXCIgYXJpYS1sYWJlbD1cItCeINC60LDRgNGC0LUg0Lgg0LTQsNC90L3Ri9GFXCI+XHJcbiAgICAgICAgPGRpdiBjbGFzcz1cIm1hcC1saXN0LWhlYWRcIj48c3Ryb25nPtCeINC60LDRgNGC0LUg0Lgg0LTQsNC90L3Ri9GFPC9zdHJvbmc+PGJ1dHRvbiBjbGFzcz1cInNtYWxsXCIgYXJpYS1sYWJlbD1cItCX0LDQutGA0YvRgtGMINGB0LLQtdC00LXQvdC40Y9cIiBvbmNsaWNrPXsoKSA9PiBhYm91dE9wZW4gPSBmYWxzZX0+w5c8L2J1dHRvbj48L2Rpdj5cclxuICAgICAgICA8cCBjbGFzcz1cIm1hcC1kaXNjbG9zdXJlXCI+0JHQtdC3INC60L7QvtGA0LTQuNC90LDRgjoge2NvbXBsZXhlcy5sZW5ndGggLSBzdW1tYXJpZXMubGVuZ3RofS4ge2NpdHkzZCA/ICczRCDigJQg0L3QsNGB0YLQvtGP0YnQuNC5INC+0LHRitGR0LzQvdGL0Lkg0LPQvtGA0L7QtDog0YDQtdCw0LvRjNC90YvQtSDQtNC+0LzQsCwg0YDQtdC70YzQtdGEINC4INC90LXQsdC+LiDQn9C+0LTRgdCy0LXRh9C10L3QvdGL0LUg0LrQvtGA0L/Rg9GB0LAg0YLQtSDQttC1OiDQv9GA0L7QstC10YDQtdC90L3Ri9C1INC60L7QvdGC0YPRgNGLINC40LvQuCDRg9GB0LvQvtCy0L3QsNGPINGB0YXQtdC80LAgNjAgw5cgNDQg0LwsINCy0YvRgdC+0YLQsCAzNiDQvC4nIDogZGltZW5zaW9uYWwgPyAnMi41RDog0L7QsdGK0ZHQvNC90YvQtSDQutC+0YDQvtCx0LrQuCDQstC80LXRgdGC0L4g0YLQvtGH0LXQui4g0J/RgNC+0LLQtdGA0LXQvdC90YvQtSDQutC+0L3RgtGD0YDRiyDQuNGB0L/QvtC70YzQt9GD0Y7RgtGB0Y8g0L/RgNC4INC90LDQu9C40YfQuNC4OyDQvtGB0YLQsNC70YzQvdGL0LUg0LrQvtGA0L7QsdC60Lgg0YPRgdC70L7QstC90YvQtSAoNjAgw5cgNDQg0LwsINCy0YvRgdC+0YLQsCAzNiDQvCkuJyA6ICcyRDog0LzQtdGC0LrQuCDQvtCx0YrQtdC60YLQvtCyINC4INC/0YDQvtCy0LXRgNC10L3QvdGL0LUg0LrQvtC90YLRg9GA0YsuJ30geyFsaXZlUmVnaXN0cnlBdmFpbGFibGUgPyAnTGl2ZS3RgdCy0LXRgNC60LAg0YDQtdC10YHRgtGA0L7QsiDQvdC10LTQvtGB0YLRg9C/0L3QsC4gJyA6ICcnfdCa0L7QvtGA0LTQuNC90LDRgtGLINC/0YDQuNCx0LvQuNC30LjRgtC10LvRjNC90YvQtS4g0JTQsNGC0LAg0YHQv9GD0YLQvdC40LrQvtCy0L7Qs9C+INGB0L3QuNC80LrQsCDQvdC10LjQt9Cy0LXRgdGC0L3QsC4g0J3Rg9C70LXQstC+0Lkg0LHQsNC70Lsg0L3QtSDQv9C+0LTRgtCy0LXRgNC20LTQsNC10YIg0LHQtdC30L7Qv9Cw0YHQvdC+0YHRgtGMLjwvcD5cclxuICAgICAgPC9kaXY+XHJcbiAgICB7L2lmfVxyXG4gICAgPGRpdiBjbGFzcz1cIm1hcC1jYXB0aW9uXCI+PHNwYW4+06jQodCa0JXQnNCV0J0gwrcge3Zpc2libGUubGVuZ3RofSDQvtCx0YrQtdC60YLQvtCye3N1bW1hcmllcy5zb21lKHMgPT4gcy5kZW1vKSA/ICcgwrcgREVNTycgOiAnJ308L3NwYW4+eyNpZiByZWxhdGVkSWRzfTxidXR0b24gY2xhc3M9XCJzbWFsbFwiIG9uY2xpY2s9eygpID0+IHJlbGF0ZWRJZHMgPSBudWxsfT7QktGB0LUg0L7QsdGK0LXQutGC0Ys8L2J1dHRvbj57L2lmfTxidXR0b24gY2xhc3M9XCJzbWFsbCBtYXAtYWJvdXQtdG9nZ2xlXCIgb25jbGljaz17KCkgPT4gYWJvdXRPcGVuID0gIWFib3V0T3Blbn0gYXJpYS1leHBhbmRlZD17YWJvdXRPcGVufT7QniDQtNCw0L3QvdGL0YU8L2J1dHRvbj48L2Rpdj5cclxuICAgIDxkaXYgY2xhc3M9XCJtYXAtbGVnZW5kIG1hcC1sZWdlbmQtZmxvYXRcIiBhcmlhLWxpdmU9XCJwb2xpdGVcIj5cclxuICAgIHsjaWYgdGhlbWUgPT09ICdvZmYnfTxzcGFuPtCR0LDQt9C+0LLQsNGPINC30L7QvdCwOiDQt9C10LvRkdC90LDRjyAvINC20ZHQu9GC0LDRjyAvINC60YDQsNGB0L3QsNGPIOKAlCDQv9C+INC/0L7QtNGC0LLQtdGA0LbQtNGR0L3QvdGL0Lwg0YTQsNC60YLQvtGA0LDQvDwvc3Bhbj5cclxuICAgIHs6ZWxzZSBpZiB0aGVtZSA9PT0gJ2xlZ2FsJ308c3Bhbj48aSBzdHlsZT1cImJhY2tncm91bmQ6IzM4ODA2OFwiPjwvaT4g0J/RgNC+0LLQtdGA0LXQvdC90L7QtSDQvtGB0L3QvtCy0LDQvdC40LU8L3NwYW4+PHNwYW4+PGkgc3R5bGU9XCJiYWNrZ3JvdW5kOiNiZjQ1M2VcIj48L2k+INCf0YDQvtCy0LXRgNC10L3QvdC+0LUg0L7RgtGB0YPRgtGB0YLQstC40LU8L3NwYW4+PHNwYW4+PGkgc3R5bGU6YmFja2dyb3VuZD17VU5LTk9XTl9DT0xPUn0+PC9pPiDQotGA0LXQsdGD0LXRgiDQv9GA0L7QstC10YDQutC4PC9zcGFuPlxyXG4gICAgezplbHNlIGlmIHRoZW1lID09PSAnY29uc3RydWN0aW9uJ308c3Bhbj48aSBzdHlsZT1cImJhY2tncm91bmQ6IzM4ODA2OFwiPjwvaT4g0J/QvtC00YLQstC10YDQttC00ZHQvdC90LDRjyDQs9C+0YLQvtCy0L3QvtGB0YLRjDwvc3Bhbj48c3Bhbj48aSBzdHlsZT1cImJhY2tncm91bmQ6I2I0N2IxMVwiPjwvaT4g0KDQsNC30YDRi9CyIOKJpTIwINC/LtC/Ljwvc3Bhbj48c3Bhbj48aSBzdHlsZTpiYWNrZ3JvdW5kPXtVTktOT1dOX0NPTE9SfT48L2k+INCd0LXRgiDQuNC30LzQtdGA0LXQvdC90L7QuSDQs9C+0YLQvtCy0L3QvtGB0YLQuDwvc3Bhbj5cclxuICAgIHs6ZWxzZX08c3Bhbj48aSBzdHlsZT1cImJhY2tncm91bmQ6I2JmNDUzZVwiPjwvaT4g0J/RgNC+0LLQtdGA0LXQvdC+INC/0YDQtdC00LvQvtC20LXQvdC40LUg0LTQtdC90LXQszwvc3Bhbj48c3Bhbj48aSBzdHlsZTpiYWNrZ3JvdW5kPXtVTktOT1dOX0NPTE9SfT48L2k+INCd0LUg0L/QvtC00YLQstC10YDQttC00LXQvdC+IC8g0L3QtdGCINC00LDQvdC90YvRhTwvc3Bhbj57L2lmfVxyXG4gIDwvZGl2PlxyXG4gIDwvZGl2PlxyXG48L3NlY3Rpb24+XHJcbjxzdHlsZT5cclxuICAubWFwLXNoZWxse21pbi13aWR0aDowfS5tYXAtdG9vbHN7ZGlzcGxheTpmbGV4O2ZsZXgtd3JhcDp3cmFwO2dhcDo4cHg7bWFyZ2luLWJvdHRvbToxMHB4O2FsaWduLWl0ZW1zOmNlbnRlcn0ubWFwLXRvb2xzIGlucHV0e2ZsZXg6MTttaW4td2lkdGg6MTgwcHh9Lm1hcC10b29scyBzZWxlY3R7d2lkdGg6YXV0b30uc2VnbWVudGVke2Rpc3BsYXk6ZmxleDtnYXA6MnB4O3BhZGRpbmc6M3B4O2JvcmRlcjoxcHggc29saWQgI2NlZDhjYztib3JkZXItcmFkaXVzOjdweDtiYWNrZ3JvdW5kOiNmMGYzZWM7YWxpZ24taXRlbXM6Y2VudGVyfS5zZWdtZW50ZWQgYnV0dG9ue2JhY2tncm91bmQ6dHJhbnNwYXJlbnQ7Y29sb3I6IzI5NGI0MDtwYWRkaW5nOjdweCAxMHB4O2ZvbnQtc2l6ZToxMnB4O3doaXRlLXNwYWNlOm5vd3JhcH0uc2VnbWVudGVkIGJ1dHRvblthcmlhLXByZXNzZWQ9dHJ1ZV17YmFja2dyb3VuZDojMjQ0YzNmO2NvbG9yOndoaXRlfS5zZWdtZW50ZWQgYnV0dG9uOmRpc2FibGVke29wYWNpdHk6LjQ7Y3Vyc29yOm5vdC1hbGxvd2VkfS5zZWdtZW50ZWQgc3Bhbntmb250LXNpemU6MTFweDtwYWRkaW5nOjAgN3B4fS5tYXAtd3JhcHtwb3NpdGlvbjpyZWxhdGl2ZTtvdmVyZmxvdzpoaWRkZW59Lm1hcHtoZWlnaHQ6NTIwcHg7d2lkdGg6MTAwJX0ubWFwLXN0YXR1c3twb2ludGVyLWV2ZW50czpub25lO3Bvc2l0aW9uOmFic29sdXRlO2xlZnQ6MTJweDt0b3A6MTBweDtyaWdodDoxMDBweDt6LWluZGV4OjI7YmFja2dyb3VuZDojZmZmNGQ5O2NvbG9yOiM2ODRjMTQ7cGFkZGluZzo4cHg7Ym9yZGVyLXJhZGl1czo1cHg7Zm9udC1zaXplOjEycHg7bWFyZ2luOjB9Lm1hcC1wcmV2aWV3e3Bvc2l0aW9uOmFic29sdXRlO3JpZ2h0OjE2cHg7Ym90dG9tOjU1cHg7ei1pbmRleDozO2JhY2tncm91bmQ6I2ZmZmZmZmY1O2JvcmRlcjoxcHggc29saWQgI2NkZDdjNztib3JkZXItcmFkaXVzOjEwcHg7d2lkdGg6bWluKDM0MHB4LGNhbGMoMTAwJSAtIDMycHgpKTtwYWRkaW5nOjE4cHg7Ym94LXNoYWRvdzowIDhweCAyNHB4ICMxODNlMzMyNjttYXgtaGVpZ2h0OmNhbGMoMTAwJSAtIDEwNXB4KTtvdmVyZmxvdzphdXRvfS5tYXAtcHJldmlldyBoM3ttYXJnaW46NXB4IDI1cHggOHB4IDA7Zm9udC1zaXplOjIwcHh9Lm1hcC1wcmV2aWV3IHB7Zm9udC1zaXplOjEycHg7bWFyZ2luOjdweCAwfS5tYXAtcHJldmlldyAucHJldmlldy1tZXRhe2ZvbnQtc2l6ZToxMXB4O2NvbG9yOiM1ODY4NTg7bGluZS1oZWlnaHQ6MS41fS5wcmV2aWV3LWV5ZWJyb3d7Zm9udC1zaXplOjEwcHg7bGV0dGVyLXNwYWNpbmc6MXB4O2NvbG9yOiM1NjcxNWV9LmNsb3NlLXByZXZpZXd7cG9zaXRpb246YWJzb2x1dGU7cmlnaHQ6OHB4O3RvcDo4cHg7cGFkZGluZzoycHggOXB4O2JhY2tncm91bmQ6dHJhbnNwYXJlbnQ7Y29sb3I6IzI5NGI0MDtmb250LXNpemU6MjJweH0ucHJldmlldy1hY3Rpb25ze2Rpc3BsYXk6ZmxleDtnYXA6NnB4O2ZsZXgtd3JhcDp3cmFwO21hcmdpbi10b3A6MTJweH0ucHJldmlldy1hY3Rpb25zIGJ1dHRvbntmb250LXNpemU6MTJweDtwYWRkaW5nOjhweCAxMHB4fS5rZXktZmFjdHtkaXNwbGF5OmZsZXg7Z2FwOjdweDthbGlnbi1pdGVtczpjZW50ZXJ9LmxlZ2VuZC1kb3R7d2lkdGg6MTBweDtoZWlnaHQ6MTBweDtmbGV4LXNocmluazowO2JvcmRlci1yYWRpdXM6NTAlfS50ZXh0LWJ1dHRvbntiYWNrZ3JvdW5kOm5vbmU7Y29sb3I6IzIzNTc0Mjtmb250LXNpemU6MTJweDtwYWRkaW5nOjdweCAwO3RleHQtZGVjb3JhdGlvbjp1bmRlcmxpbmV9Lm1hcC1jYXB0aW9ue3otaW5kZXg6MTtib3R0b206MjVweDtsZWZ0OjEycHg7bWF4LXdpZHRoOmNhbGMoMTAwJSAtIDI0cHgpO2xldHRlci1zcGFjaW5nOi41cHh9Lm1hcC1sZWdlbmR7ZGlzcGxheTpmbGV4O2dhcDoxMnB4O2ZsZXgtd3JhcDp3cmFwO2ZvbnQtc2l6ZToxMXB4O2NvbG9yOiM0MjUzNDc7cGFkZGluZzo2cHggMH0ubWFwLWxlZ2VuZCBzcGFue2Rpc3BsYXk6ZmxleDtnYXA6NXB4O2FsaWduLWl0ZW1zOmNlbnRlcn0ubWFwLWxlZ2VuZCBpe2hlaWdodDoxMHB4O3dpZHRoOjEwcHg7Ym9yZGVyLXJhZGl1czo1MCU7ZGlzcGxheTppbmxpbmUtYmxvY2t9Lm1hcC1kaXNjbG9zdXJle2ZvbnQtc2l6ZToxMXB4O2NvbG9yOiM1YzZiNWM7bGluZS1oZWlnaHQ6MS42fS5mYWxsYmFjay1tYXB7cG9zaXRpb246YWJzb2x1dGU7aW5zZXQ6MDtvdmVyZmxvdzpoaWRkZW47YmFja2dyb3VuZDojZGZlOGRjfS50aWxle3Bvc2l0aW9uOmFic29sdXRlO21heC13aWR0aDpub25lO3BvaW50ZXItZXZlbnRzOm5vbmV9LmZhbGxiYWNrLXBvaW50e3Bvc2l0aW9uOmFic29sdXRlO3RyYW5zZm9ybTp0cmFuc2xhdGUoLTUwJSwtNTAlKTt3aWR0aDoyM3B4O2hlaWdodDoyM3B4O2JvcmRlcjozcHggc29saWQgd2hpdGU7Ym9yZGVyLXJhZGl1czo1MCU7cGFkZGluZzowO2JveC1zaGFkb3c6MCAxcHggNHB4ICMwMDA2fS5mYWxsYmFjay1jb250cm9sc3twb3NpdGlvbjphYnNvbHV0ZTtyaWdodDo4cHg7dG9wOjhweDtkaXNwbGF5OmdyaWQ7Z3JpZC10ZW1wbGF0ZS1jb2x1bW5zOnJlcGVhdCgyLDM0cHgpO2dhcDozcHh9LmZhbGxiYWNrLWNvbnRyb2xzIGJ1dHRvbntwYWRkaW5nOjVweDtiYWNrZ3JvdW5kOndoaXRlO2NvbG9yOiMyMzRhM2R9LmF0dHJpYnV0aW9ue3Bvc2l0aW9uOmFic29sdXRlO3JpZ2h0OjA7Ym90dG9tOjA7cGFkZGluZzoycHggNHB4O2ZvbnQtc2l6ZToxMHB4O2JhY2tncm91bmQ6I2ZmZmQ7Y29sb3I6IzI0NGMzZn1AbWVkaWEobWF4LXdpZHRoOjY0MHB4KXsubWFwe2hlaWdodDo1NjBweH0ubWFwLXByZXZpZXd7cmlnaHQ6OHB4O2JvdHRvbTo1NXB4O3dpZHRoOmNhbGMoMTAwJSAtIDE2cHgpO21heC1oZWlnaHQ6MzMwcHg7cGFkZGluZzoxMnB4fS5tYXAtdG9vbHN7Z2FwOjZweH0ubWFwLXRvb2xzIGlucHV0e21pbi13aWR0aDowO2ZsZXg6MSAxIDE0MHB4O3dpZHRoOmF1dG99LnNlZ21lbnRlZCBidXR0b257cGFkZGluZzo3cHh9LnNlZ21lbnRlZHtmbGV4OjAgMCBhdXRvfS54cmF5e2ZsZXg6MCAwIGF1dG99Lm1hcC1jYXB0aW9ue2ZvbnQtc2l6ZTo5cHh9fVxyXG48L3N0eWxlPlxyXG4iXSwiZmlsZSI6IkM6L1VzZXJzL0JJR3JhL2NvZGVtYXN0ZXJzOC9zcmMvY29tcG9uZW50cy9SaXNrTWFwLnN2ZWx0ZSJ9